import React from 'react';
import { formatDistanceToNow } from 'date-fns';
import { User } from '../types';
import { safeUserId } from './safe';

export {
  THEME_ADAPTIVE_TEXT_CLASS,
  THEME_OVERLAY_COLOR,
  normalizeEditorTextColorForSave,
  normalizeOverlayColorForSave,
  resolveCaptionColorClass,
  resolveEditorTextColorClass,
  resolveOverlayTextStyle,
  themeAdaptiveTextStyle,
  USER_CAPTION_PROSE_CLASS,
  REEL_STAT_LABEL_CLASS,
  REEL_STAT_LABEL_STYLE,
} from './themeText';

/** Opens global profile preview; only userId is required (preview resolves live user from db). */
export function openProfilePreview(user: User | Partial<User>) {
  const userId = safeUserId(user?.id);
  if (!userId) return;
  window.dispatchEvent(
    new CustomEvent('show-profile-preview', { detail: { userId } })
  );
}

export function formatTimeAgo(dateString: string) {
  try {
    return formatDistanceToNow(new Date(dateString), { addSuffix: true });
  } catch {
    return dateString;
  }
}

const CAPTION_LINK_CLASS =
  'text-primary hover:underline cursor-pointer font-medium';

export type FormatMentionsOptions = {
  linkClassName?: string;
};

export function formatMentionsAndTags(
  text: string | null | undefined,
  options?: FormatMentionsOptions
) {
  if (!text || typeof text !== 'string') return null;
  const linkClass = options?.linkClassName ?? CAPTION_LINK_CLASS;
  const words = text.split(/(\s+)/);
  return words.map((word, i) => {
    if (word.startsWith('@')) {
       return (
         <span
           key={i}
           className={linkClass}
           onClick={(e) => {
           e.stopPropagation();
           window.dispatchEvent(new CustomEvent('navigate', { detail: { tab: 'search', searchQuery: word.substring(1), searchTab: 'accounts' } }));
         }}
         >
           {word}
         </span>
       );
    }
    if (word.startsWith('#')) {
       return (
         <span
           key={i}
           className={linkClass}
           onClick={(e) => {
           e.stopPropagation();
           window.dispatchEvent(new CustomEvent('navigate', { detail: { tab: 'search', searchQuery: word.substring(1), searchTab: 'tags' } }));
         }}
         >
           {word}
         </span>
       );
    }
    return (
      <span key={i} className="caption-text-part text-foreground">
        {word}
      </span>
    );
  });
}

export function handleAvatarError(e: React.SyntheticEvent<HTMLImageElement, Event>) {
  e.currentTarget.onerror = null;
  e.currentTarget.src = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop";
}

const FALLBACK_POSTER =
  'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&fit=crop';
const FALLBACK_VIDEO =
  'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4';

function applyVideoPosterBackground(
  target: HTMLVideoElement,
  poster: string
) {
  target.poster = poster;
  const parent = target.parentElement;
  if (parent) {
    parent.style.backgroundImage = `url(${poster})`;
    parent.style.backgroundSize = 'cover';
    parent.style.backgroundPosition = 'center';
  }
}

export function handleMediaError(e: React.SyntheticEvent<HTMLImageElement | HTMLVideoElement, Event>) {
  const target = e.currentTarget;
  if (!target) return;

  const isVideo =
    target.tagName === 'VIDEO' ||
    target.nodeName === 'VIDEO' ||
    (typeof HTMLVideoElement !== 'undefined' && target instanceof HTMLVideoElement);

  if (isVideo) {
    const video = target as HTMLVideoElement;
    const src = video.currentSrc || video.src || '';
    if (src.startsWith('data:') || src.startsWith('blob:')) {
      video.onerror = null;
      video.pause();
      video.removeAttribute('src');
      video.load();
      video.style.display = 'none';
      return;
    }
    const poster =
      video.getAttribute('data-poster') ||
      video.poster ||
      FALLBACK_POSTER;
    applyVideoPosterBackground(video, poster);

    const retry = video.getAttribute('data-media-fallback');
    if (retry === 'done') {
      video.onerror = null;
      video.removeAttribute('src');
      video.style.display = 'none';
      return;
    }

    if (retry === '1') {
      video.setAttribute('data-media-fallback', 'done');
      video.onerror = null;
      video.removeAttribute('src');
      video.style.display = 'none';
      return;
    }

    video.setAttribute('data-media-fallback', '1');
    video.onerror = null;

    if (video.src && !video.src.includes('ForBiggerJoyrides.mp4')) {
      video.src = FALLBACK_VIDEO;
      try {
        video.muted = true;
        video.defaultMuted = true;
        video.load();
        video.play().catch(() => {
          video.style.display = 'none';
        });
      } catch {
        video.style.display = 'none';
      }
      return;
    }

    video.style.display = 'none';
    return;
  }

  const img = target as HTMLImageElement;
  if (img.getAttribute('data-media-fallback') === '1') {
    img.onerror = null;
    return;
  }
  img.setAttribute('data-media-fallback', '1');
  img.onerror = null;
  img.src = FALLBACK_POSTER;
}

export function fileToBase64(file: File | Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!(file instanceof File) && !(file instanceof Blob)) {
      reject(new Error('Invalid file type'));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(reader.error || new Error('Error reading file'));
    reader.readAsDataURL(file);
  });
}

export function getFontClass(font?: string) {
  if (!font) return 'font-sans';
  if (['sans', 'serif', 'mono'].includes(font)) return `font-${font}`;
  return font;
}

export function getAlignClass(alignment?: string) {
  if (!alignment) return 'text-center';
  if (['left', 'center', 'right'].includes(alignment)) return `text-${alignment}`;
  return alignment;
}

export function truncateText(text: string | null | undefined, maxLength: number) {
  const safe = typeof text === 'string' ? text : '';
  if (safe.length <= maxLength) return { text: safe, showMore: false };
  return { text: safe.substring(0, maxLength) + '...', showMore: true };
}

