import React from 'react';
import { Gamepad2 } from 'lucide-react';

export function LocalGamesScreen() {
  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h2 className="text-2xl font-black mb-8 flex items-center gap-3">
        <Gamepad2 className="w-8 h-8 text-primary" />
        Local Games
      </h2>
      <div className="grid grid-cols-2 gap-4">
        {['Tic Tac Toe', 'Puzzle Mania', 'Memory Match', 'Snake'].map((game) => (
          <button key={game} className="p-6 bg-card border border-border rounded-xl hover:border-primary transition-colors text-sm font-bold flex flex-col items-center gap-3">
            <Gamepad2 className="w-8 h-8" />
            {game}
          </button>
        ))}
      </div>
    </div>
  );
}
