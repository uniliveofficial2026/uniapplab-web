import React from 'react';
import { Globe } from 'lucide-react';

export function ThirdPartyGamesScreen() {
  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h2 className="text-2xl font-black mb-8 flex items-center gap-3">
        <Globe className="w-8 h-8 text-blue-500" />
        Third Party Games
      </h2>
      <div className="grid grid-cols-2 gap-4">
        {['WebGL Racer', 'Arena Battle', 'Space Shooter', 'Card Duel'].map((game) => (
          <button key={game} className="p-6 bg-card border border-border rounded-xl hover:border-blue-500 transition-colors text-sm font-bold flex flex-col items-center gap-3 text-blue-500">
            <Globe className="w-8 h-8" />
            {game}
          </button>
        ))}
      </div>
    </div>
  );
}
