import React, { useEffect, useState } from 'react';
import { Crown, Check, Wallet, Clock } from 'lucide-react';
import { useDB } from '../../lib/useDB';
import { useToast } from '../../lib/ToastContext';
import { PREMIUM_PACKAGE_LIST } from '../../lib/premiumPackages';
import { ProfilePremiumBadge } from '../common/ProfilePremiumBadge';
import {
  formatPremiumExpiryDate,
  getProfilePremiumAccessStatus,
} from '../../lib/premium';

export function WalletScreen() {
  const db = useDB();
  const { showToast } = useToast();
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const profilePremiumStatus = getProfilePremiumAccessStatus(
    db.currentUser,
    now
  );
  const hasAccess = profilePremiumStatus.active;

  const handlePurchase = (packageId: (typeof PREMIUM_PACKAGE_LIST)[number]['id']) => {
    const result = db.purchasePremiumPackage(packageId);
    if (!result.ok) {
      showToast(result.reason || 'Purchase failed');
      return;
    }
    const pkg = PREMIUM_PACKAGE_LIST.find((p) => p.id === packageId);
    const expiryLabel =
      result.expiresAt != null
        ? formatPremiumExpiryDate(result.expiresAt)
        : null;
    showToast(
      result.extended
        ? `Added ${pkg?.periodLabel ?? 'time'}${expiryLabel ? ` — active until ${expiryLabel}` : ''}`
        : `Profile Premium active${pkg ? ` (${pkg.periodLabel})` : ''}${expiryLabel ? ` — until ${expiryLabel}` : ''}`
    );
    if (!result.extended) {
      db.updateSettings({ hiddenProfileViews: false });
    }
    setNow(Date.now());
  };

  return (
    <div className="w-full max-w-lg mx-auto flex flex-col gap-6 p-6 pb-24">
      <div className="flex flex-col items-center text-center gap-2 pt-4">
        <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center">
          <Wallet className="w-7 h-7 text-primary" />
        </div>
        <h2 className="text-2xl font-black text-foreground">My Wallet</h2>
        <p className="text-sm text-muted-foreground max-w-sm">
          Choose 1 month, 3 months, 6 months, or 1 year of Profile Premium.
        </p>
        {hasAccess ? (
          <ProfilePremiumBadge
            size="md"
            className="mt-1"
            status={profilePremiumStatus}
          />
        ) : null}
      </div>

      {hasAccess && profilePremiumStatus.expiresAt != null ? (
        <div className="flex items-start gap-2 rounded-2xl border border-emerald-500/40 bg-emerald-500/10 px-4 py-3 text-sm text-foreground">
          <Clock className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
          <span className="text-left leading-snug">
            <span className="font-bold block">
              {profilePremiumStatus.periodLabel
                ? `Profile Premium · ${profilePremiumStatus.periodLabel}`
                : 'Profile Premium active'}
            </span>
            <span className="text-foreground/90">
              {profilePremiumStatus.timeRemainingLabel} · ends{' '}
              {formatPremiumExpiryDate(profilePremiumStatus.expiresAt)}
            </span>
          </span>
        </div>
      ) : null}

      <div className="space-y-4">
        <h3 className="text-xs font-black uppercase tracking-widest text-muted-foreground px-1">
          Profile Premium plans
        </h3>
        {PREMIUM_PACKAGE_LIST.map((pkg) => {
          const isCurrentPlan =
            hasAccess && profilePremiumStatus.lastTierId === pkg.id;

          return (
            <article
              key={pkg.id}
              className={`rounded-2xl border p-5 flex flex-col gap-4 ${
                isCurrentPlan
                  ? 'border-emerald-500/40 bg-emerald-500/5'
                  : 'border-border bg-card shadow-sm'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2 min-w-0">
                  <Crown
                    className={`w-5 h-5 shrink-0 ${isCurrentPlan ? 'text-emerald-500' : 'text-amber-500'}`}
                  />
                  <div className="min-w-0 text-left">
                    <h4 className="font-bold text-foreground truncate">{pkg.name}</h4>
                    <p className="text-xs text-muted-foreground">{pkg.periodLabel}</p>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-lg font-black text-foreground">
                    ${pkg.price.toFixed(2)}
                  </span>
                  <span className="text-[10px] text-muted-foreground block">
                    {pkg.currency}
                  </span>
                </div>
              </div>

              {isCurrentPlan && profilePremiumStatus.expiresAt != null ? (
                <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-300 -mt-1">
                  Current plan · {profilePremiumStatus.timeRemainingLabel}
                </p>
              ) : null}

              <p className="text-sm text-muted-foreground leading-relaxed">{pkg.description}</p>

              <ul className="space-y-2">
                {pkg.features.map((feature) => (
                  <li
                    key={feature}
                    className="flex items-start gap-2 text-sm text-foreground/85"
                  >
                    <Check className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              <button
                type="button"
                onClick={() => handlePurchase(pkg.id)}
                className={`w-full py-3 rounded-xl text-sm font-bold transition-colors ${
                  isCurrentPlan
                    ? 'bg-secondary text-foreground hover:bg-secondary/80 border border-border'
                    : 'bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/20'
                }`}
              >
                {hasAccess
                  ? `Add ${pkg.periodLabel}`
                  : `Get ${pkg.periodLabel} — $${pkg.price.toFixed(2)}`}
              </button>
            </article>
          );
        })}
      </div>
    </div>
  );
}
