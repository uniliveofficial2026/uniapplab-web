import React, { useState, useEffect } from 'react';
import { Story } from '../../types';
import { Plus } from 'lucide-react';
import { ShareModal } from './ShareModal';
import { handleAvatarError } from '../../lib/utils';
import {
  type StoryCreatorStep,
} from '../stories/StoryCreatorFlow';
import {
  STORY_OPEN_CREATE_EVENT,
  type StoryOpenCreateDetail,
} from '../../lib/storyCreateEvents';
import {
  AvatarStatusBadge,
  getAvatarStatusBadgeOutsidePosition,
} from '../common/AvatarStatusBadge';
import { getLiveRingClasses, LIVE_KIND_LABELS } from '../../lib/liveRing';
import { getStoryRingVisualState } from '../../lib/storySegments';
import { safeIndex, resolveUser } from '../../lib/safe';
import { useDB } from '../../lib/useDB';
import { useToast } from '../../lib/ToastContext';
import { pauseAllPlayback, PLAYBACK_PRIORITY } from '../../lib/playbackAudio';
import { acquireMediaOverlayLock } from '../../lib/mediaOverlayLock';
import { useExclusivePlayback } from '../../lib/useExclusivePlayback';
import { isPlayableAudioUrl } from '../../lib/audioMedia';
import { StoryRingPortals } from './StoryRingPortals';

interface StoryRingProps {
  story: Story;
  isCurrentUser?: boolean;
  isOpen?: boolean;
  onClose?: () => void;
  hideRing?: boolean;
  prevUserId?: string | null;
  nextUserId?: string | null;
  onRequestOpenUser?: (userId: string) => void;
}

export function StoryRing({
  story,
  isCurrentUser,
  isOpen = false,
  onClose,
  hideRing = false,
  prevUserId = null,
  nextUserId = null,
  onRequestOpenUser,
}: StoryRingProps) {
  const db = useDB();
  const { showToast } = useToast();
  const storyUser = React.useMemo(
    () => resolveUser(db.users, story?.user, db.currentUser),
    [story?.user, db.users, db.currentUser]
  );
  const [showStory, setShowStory] = useState(isOpen);
  const [showCreateStory, setShowCreateStory] = useState(false);
  const [storyCreateStep, setStoryCreateStep] = useState<StoryCreatorStep>('select');
  const storyCreatorBackRef = React.useRef<() => void>(() => {});
  const storyCreatorShareRef = React.useRef<() => void>(() => {});
  const [showStoryEmpty, setShowStoryEmpty] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (isOpen) {
      setShowStory(true);
    }
  }, [isOpen]);

  useEffect(() => {
    if (!showStory && onClose && isOpen) {
      onClose();
    }
  }, [showStory, onClose, isOpen]);
  const [currentSegmentIndex, setCurrentSegmentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  
  const [messageText, setMessageText] = useState('');
  const [isSent, setIsSent] = useState(false);
  const persistentSegments = db.getUserStorySegments(storyUser.id);
  const createdStory = persistentSegments.length > 0;
  const isMyStoryEmpty = isCurrentUser && !createdStory;

  const ring = getStoryRingVisualState(storyUser.id, {
    getUserStorySegments: db.getUserStorySegments.bind(db),
    hasViewedStory: db.hasViewedStory.bind(db),
    userStatus: storyUser.status,
    liveKind: storyUser.liveKind,
  });

  const {
    isMultiStory,
    hasStoryContent,
    isViewed,
    isLive: isLiveUser,
    liveKind,
  } = ring;

  const liveRingClasses = getLiveRingClasses(liveKind);

  const showAnimatedLiveRing = !isMyStoryEmpty && isLiveUser;
  const showAnimatedMultiStoryRing =
    !isMyStoryEmpty && !isLiveUser && hasStoryContent && !isViewed && isMultiStory;
  const showAnimatedStoryRing =
    !isMyStoryEmpty &&
    !isLiveUser &&
    hasStoryContent &&
    !isViewed &&
    !isMultiStory;
  const showViewedStoryRing =
    !isMyStoryEmpty && !isLiveUser && hasStoryContent && isViewed;
  const showStoryStatusBadge =
    !isMyStoryEmpty && !isLiveUser && hasStoryContent && !isCurrentUser;

  const markStoryAsViewed = () => {
    if (!isCurrentUser && storyUser.id) {
      db.markStoryViewed(storyUser.id);
    }
  };

  const closeStoryViewer = () => {
    markStoryAsViewed();
    setShowStory(false);
    setProgress(0);
    setCurrentSegmentIndex(0);
  };
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const storyVideoRef = React.useRef<HTMLVideoElement>(null);

  const standaloneStoryCreatorOpen = showCreateStory || showStoryEmpty;

  // Pause feed/reels while this ring's story viewer or creator is open (not global create menu — that is per-Post via db.isCreatorEditingActive)
  useEffect(() => {
    const pauseBackground = showStory || standaloneStoryCreatorOpen;
    if (!pauseBackground) return;
    return acquireMediaOverlayLock();
  }, [showStory, standaloneStoryCreatorOpen]);

  useEffect(() => {
    if (!standaloneStoryCreatorOpen && !showStory) return;
    pauseAllPlayback();
  }, [standaloneStoryCreatorOpen, showStory]);
  
  const [likedSegments, setLikedSegments] = useState<Record<number, boolean>>({});
  
  const segments = persistentSegments;
  const safeSegmentIndex = safeIndex(currentSegmentIndex, segments.length, 0);
  const currentSegment = segments[safeSegmentIndex];
  const loopStoryVideo = segments.length <= 1;

  const sendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim()) return;
    setIsSent(true);
    setMessageText('');
    setIsPaused(false);
    setTimeout(() => setIsSent(false), 2000);
  };

  // Auto-progress story
  useEffect(() => {
    if (!showStory || isPaused) return;
    
    // If current segment is a video, let video onTimeUpdate manage progress instead of timer.
    const isVideoSegment = currentSegment?.isVideo === true;
    if (isVideoSegment) return;

    const interval = setInterval(() => {
      setProgress(p => {
        if (p >= 100) return 100;
        return p + 2.5; // Controls the speed (total ~4 seconds per segment)
      });
    }, 100);
    return () => clearInterval(interval);
  }, [showStory, isPaused, currentSegmentIndex, segments]);

  // Handle segment completion
  useEffect(() => {
    if (progress >= 100) {
      if (currentSegmentIndex < segments.length - 1) {
        setCurrentSegmentIndex(c => c + 1);
        setProgress(0);
      } else {
        closeStoryViewer();
      }
    }
  }, [progress, currentSegmentIndex, segments.length, showStory]);

  const storyPlaybackId = `story:${storyUser.id}`;
  const segmentHasSoundtrack =
    !!currentSegment?.backgroundAudio?.url &&
    isPlayableAudioUrl(currentSegment.backgroundAudio.url);
  const storyVideoWantsSound =
    showStory &&
    !isPaused &&
    currentSegment?.isVideo === true &&
    !db.globalMuted &&
    !segmentHasSoundtrack;

  useExclusivePlayback(
    storyPlaybackId,
    PLAYBACK_PRIORITY.STORY,
    storyVideoWantsSound,
    storyVideoRef
  );

  // Muted preview loop only — audible playback goes through the coordinator.
  useEffect(() => {
    const video = storyVideoRef.current;
    if (!video) return;
    if (!showStory || isPaused || !currentSegment?.isVideo) {
      video.pause();
      return;
    }
    if (segmentHasSoundtrack || db.globalMuted || !storyVideoWantsSound) {
      if (video.paused) {
        video.play().catch(() => {});
      }
    }
  }, [
    isPaused,
    currentSegmentIndex,
    showStory,
    db.globalMuted,
    currentSegment?.isVideo,
    segmentHasSoundtrack,
    storyVideoWantsSound,
  ]);

  const openCreateStoryFlow = (skipEmpty = false) => {
    if (!skipEmpty && isMyStoryEmpty) {
      setShowStoryEmpty(true);
      setShowCreateStory(false);
      return;
    }
    setShowStoryEmpty(false);
    setShowCreateStory(true);
  };

  useEffect(() => {
    if (!isCurrentUser) return;
    const onOpenCreate = (event: Event) => {
      const detail = (event as CustomEvent<StoryOpenCreateDetail>).detail;
      if (detail?.viewSegmentIndex !== undefined) {
        setShowStoryEmpty(false);
        setShowCreateStory(false);
        setShowStory(true);
        setCurrentSegmentIndex(detail.viewSegmentIndex);
        setProgress(0);
        setIsPaused(false);
        return;
      }
      const skipEmpty = detail?.skipEmpty ?? createdStory;
      if (skipEmpty) {
        setShowStoryEmpty(false);
        setShowCreateStory(true);
      } else {
        openCreateStoryFlow(false);
      }
    };
    window.addEventListener(STORY_OPEN_CREATE_EVENT, onOpenCreate);
    return () => window.removeEventListener(STORY_OPEN_CREATE_EVENT, onOpenCreate);
  }, [isCurrentUser, createdStory, isMyStoryEmpty]);

  const emitProfileVisitRecord = (context: {
    surface: 'story' | 'live';
    previewUrl?: string;
    liveKind?: typeof liveKind;
  }) => {
    if (isCurrentUser || !storyUser.id) return;
    window.dispatchEvent(
      new CustomEvent('profile-visit-record', {
        detail: {
          profileUserId: storyUser.id,
          context,
        },
      })
    );
  };

  const handleRingClick = () => {
    if (isMyStoryEmpty && story.id === 'current') {
      setShowStoryEmpty(true);
      return;
    }
    if (isLiveUser) {
      emitProfileVisitRecord({
        surface: 'live',
        liveKind: liveKind ?? 'solo',
      });
      window.dispatchEvent(new CustomEvent('navigate', { detail: { tab: 'live' } }));
      return;
    }
    if (!isCurrentUser && !hasStoryContent) {
      return;
    }
    if (segments.length === 0) {
      showToast('No story available');
      return;
    }
    if (!isCurrentUser) {
      const first = segments[0];
      emitProfileVisitRecord({
        surface: 'story',
        previewUrl: first?.url,
      });
    }
    setShowStory(true);
    setCurrentSegmentIndex(0);
    setProgress(0);
    setIsPaused(false);
  };

  useEffect(() => {
    if (!showCreateStory) setStoryCreateStep('select');
  }, [showCreateStory]);

  const handleStoryShared = (newIndex: number) => {
    setStoryCreateStep('select');
    setShowCreateStory(false);
    setShowStory(true);
    setCurrentSegmentIndex(newIndex);
    setProgress(0);
    setIsPaused(false);
  };

  const DOUBLE_PRESS_DELAY = 300;
  const lastTapRef = React.useRef<number>(0);

  const handleTap = (direction: 'left' | 'right') => {
    const now = Date.now();
    if (lastTapRef.current && (now - lastTapRef.current) < DOUBLE_PRESS_DELAY) {
      // Double tap
      setLikedSegments(prev => ({
        ...prev,
        [currentSegmentIndex]: true
      }));
      lastTapRef.current = 0;
    } else {
      // Single tap - wait to see if it's a double tap
      lastTapRef.current = now;
      setTimeout(() => {
        if (lastTapRef.current === now) {
          if (direction === 'left') {
            if (currentSegmentIndex > 0) {
              setCurrentSegmentIndex(i => i - 1);
              setProgress(0);
            } else if (prevUserId && onRequestOpenUser) {
              closeStoryViewer();
              onRequestOpenUser(prevUserId);
            } else {
              setProgress(0);
            }
          } else {
            if (currentSegmentIndex < segments.length - 1) {
              setCurrentSegmentIndex(i => i + 1);
              setProgress(0);
            } else if (nextUserId && onRequestOpenUser) {
              closeStoryViewer();
              onRequestOpenUser(nextUserId);
            } else {
              closeStoryViewer();
            }
          }
        }
      }, DOUBLE_PRESS_DELAY);
    }
  };

  const toggleLike = () => {
    setLikedSegments(prev => ({
      ...prev,
      [currentSegmentIndex]: !prev[currentSegmentIndex]
    }));
  };

  const hasAnimatedRing =
    showAnimatedStoryRing || showAnimatedMultiStoryRing || showAnimatedLiveRing;

  const ringShell = (
    <div
      className={`avatar-ring-shell avatar-ring-shell--feed transition-transform group-hover:scale-105 active:scale-95 ${
        hasAnimatedRing
          ? ''
          : showViewedStoryRing
            ? 'avatar-ring-shell--viewed'
            : 'avatar-ring-shell--no-ring ' +
              (isMyStoryEmpty
                ? 'bg-secondary border border-dashed border-border'
                : 'bg-secondary')
      }`}
    >
      {showAnimatedMultiStoryRing && (
        <>
          <div className="avatar-ring-glow avatar-ring-glow--multi" />
          <div className="avatar-ring-spinner avatar-ring-spinner--multi" />
        </>
      )}
      {showAnimatedStoryRing && (
        <>
          <div className="avatar-ring-glow avatar-ring-glow--story" />
          <div className="avatar-ring-spinner avatar-ring-spinner--story" />
        </>
      )}
      {showAnimatedLiveRing && (
        <>
          <div className={`avatar-ring-glow ${liveRingClasses.glow}`} />
          <div className={`avatar-ring-spinner ${liveRingClasses.spinner}`} />
        </>
      )}
      <div className="avatar-ring-face">
        <img
          src={storyUser.avatarUrl || undefined}
          alt={storyUser.username}
          className="h-full w-full object-cover"
          onError={handleAvatarError}
        />
      </div>

      {(showAnimatedLiveRing ||
        showStoryStatusBadge ||
        (isCurrentUser && createdStory)) && (
        <div className={getAvatarStatusBadgeOutsidePosition('xs')}>
          {showAnimatedLiveRing && <AvatarStatusBadge variant="live" size="xs" />}
          {showStoryStatusBadge && !showAnimatedLiveRing && (
            <AvatarStatusBadge
              variant={
                showViewedStoryRing
                  ? 'story-viewed'
                  : isMultiStory
                    ? 'story-multi'
                    : 'story'
              }
              size="xs"
            />
          )}
          {isCurrentUser && createdStory && !showAnimatedLiveRing && (
            <AvatarStatusBadge
              variant={isMultiStory ? 'story-multi' : 'you'}
              size="xs"
            />
          )}
        </div>
      )}

      {isCurrentUser && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            openCreateStoryFlow(createdStory);
          }}
          className="absolute -bottom-0.5 -right-0.5 z-30 flex h-[18px] w-[18px] items-center justify-center rounded-full border-2 border-background bg-primary text-primary-foreground shadow-md transition-transform hover:scale-110 active:scale-90"
          title={createdStory ? 'Add another story segment' : 'Add your first story'}
          aria-label={createdStory ? 'Add another story segment' : 'Add your first story'}
        >
          <Plus className="h-3 w-3" strokeWidth={3} />
        </button>
      )}
    </div>
  );

  return (
    <>
      {!hideRing && (
        <div
          className="story-strip-item cursor-pointer group overflow-visible"
          onClick={handleRingClick}
        >
          <div className="story-strip-ring-slot">
            <div className="avatar-ring-halo avatar-ring-halo--feed">{ringShell}</div>
          </div>
          <div className="story-strip-labels">
            <span className="story-strip-username text-muted-foreground group-hover:text-foreground transition-colors">
              {isCurrentUser ? (createdStory ? 'Your story' : 'Add story') : storyUser.username}
            </span>
            <span
              className={`story-strip-sublabel text-muted-foreground/90 ${
                showAnimatedLiveRing && liveKind ? '' : 'story-strip-sublabel--hidden'
              }`}
            >
              {showAnimatedLiveRing && liveKind ? LIVE_KIND_LABELS[liveKind] : '\u00a0'}
            </span>
          </div>
        </div>
      )}

      <StoryRingPortals
        storyUser={storyUser}
        db={db}
        showStoryEmpty={showStoryEmpty}
        setShowStoryEmpty={setShowStoryEmpty}
        showCreateStory={showCreateStory}
        setShowCreateStory={setShowCreateStory}
        storyCreateStep={storyCreateStep}
        setStoryCreateStep={setStoryCreateStep}
        storyCreatorBackRef={storyCreatorBackRef}
        storyCreatorShareRef={storyCreatorShareRef}
        showStory={showStory}
        currentSegment={currentSegment}
        currentSegmentIndex={currentSegmentIndex}
        segments={segments}
        progress={progress}
        setProgress={setProgress}
        setCurrentSegmentIndex={setCurrentSegmentIndex}
        isPaused={isPaused}
        setIsPaused={setIsPaused}
        storyVideoRef={storyVideoRef}
        playbackSpeed={playbackSpeed}
        setPlaybackSpeed={setPlaybackSpeed}
        loopStoryVideo={loopStoryVideo}
        likedSegments={likedSegments}
        handleTap={handleTap}
        toggleLike={toggleLike}
        closeStoryViewer={closeStoryViewer}
        messageText={messageText}
        setMessageText={setMessageText}
        isSent={isSent}
        sendMessage={sendMessage}
        setShowShareModal={setShowShareModal}
        handleStoryShared={handleStoryShared}
        storyPlaybackId={storyPlaybackId}
        prevUserId={prevUserId}
        nextUserId={nextUserId}
        onRequestOpenUser={onRequestOpenUser}
      />

      <ShareModal
        isOpen={showShareModal}
        onClose={() => {
          setShowShareModal(false);
          setIsPaused(false);
        }}
        shareUrl={`https://instacollab.app/s/${storyUser.username}?seg=${currentSegmentIndex}`}
        itemTitle="Share Story"
        shareText={`Shared @${storyUser.username}'s story segment`}
      />
    </>
  );
}

