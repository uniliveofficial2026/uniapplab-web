import React from 'react';
import { motion } from 'motion/react';
import { User } from '../../types';
import { Grid, ChevronLeft } from 'lucide-react';
import { useDB } from '../../lib/useDB';
import { Avatar } from '../common/Avatar';
import { ProfilePremiumBadgeForUser } from '../common/ProfilePremiumBadge';
import { handleMediaError } from '../../lib/utils';
import { safeMediaUrl } from '../../lib/safe';
import { useToast } from '../../lib/ToastContext';
import { useUserById } from '../../lib/useDB';
import { postUserId } from '../../lib/safe';
import { resolvePost } from '../../lib/entityResolve';
import { FollowListModal } from './FollowListModal';
import { StoryStrip } from '../feed/StoryStrip';
import { ProfilePrivateContentGate } from './ProfilePrivateContentGate';
import { useFollowActionState } from '../../lib/useFollowActionState';
import { followToggleToastMessage, getFollowButtonHoverLabel } from '../../lib/followPrivacy';

export function UserProfilePreview({
  userId,
  user: userSnapshot,
  onClose,
}: {
  userId: string;
  user?: User;
  onClose: () => void;
}) {
  const db = useDB();
  const { showToast } = useToast();
  const liveUser = useUserById(userId, userSnapshot);
  const userPosts = (db.posts ?? []).filter(
    (p) => postUserId(p) === liveUser.id && !p.isArchived
  );
  const [followHover, setFollowHover] = React.useState(false);
  const [followListMode, setFollowListMode] = React.useState<'followers' | 'following' | null>(
    null
  );

  const isSelf = liveUser.id === db.currentUser?.id;
  const followAction = useFollowActionState(isSelf ? undefined : liveUser.id);
  const canViewProfileContent = isSelf || (followAction?.canViewContent ?? true);

  React.useEffect(() => {
    if (!isSelf && liveUser.id) {
      if (liveUser.status === 'live') {
        db.recordProfileVisit(liveUser.id, {
          surface: 'live',
          liveKind: liveUser.liveKind ?? 'solo',
        });
      } else {
        db.recordProfileVisit(liveUser.id, { surface: 'profile' });
      }
    }
  }, [liveUser.id, liveUser.status, liveUser.liveKind, isSelf, db]);

  const handleFollowToggle = () => {
    db.toggleFollow(liveUser.id);
    const after = db.getFollowActionState(liveUser.id);
    const label = liveUser.username || liveUser.displayName || 'user';
    showToast(followToggleToastMessage(after, label));
    setFollowHover(false);
  };

  return (
    <>
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 sm:p-6 pb-20 pointer-events-none">
              <div className="absolute inset-0 bg-white/95 dark:bg-zinc-950/95 backdrop-blur-md pointer-events-auto" onClick={onClose} />
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="w-full max-w-sm bg-card rounded-[32px] border border-border shadow-2xl relative z-10 pointer-events-auto overflow-hidden flex flex-col max-h-[80vh]"
      >
        <div className="p-4 border-b border-border flex items-center justify-between sticky top-0 bg-card z-10">
           <div className="flex items-center gap-4">
              <button onClick={onClose} className="p-2 hover:bg-secondary rounded-full -ml-2 transition-colors"><ChevronLeft className="w-6 h-6" /></button>
              <h3 className="font-bold text-lg flex items-center gap-2 min-w-0">
                <span className="truncate">{liveUser.username}</span>
                <ProfilePremiumBadgeForUser user={liveUser} size="sm" />
              </h3>
           </div>
           <button 
             onClick={() => {
               onClose();
               window.dispatchEvent(new CustomEvent('navigate', { detail: { tab: 'profile', userId: liveUser.id } }));
             }}
             className="text-xs font-bold text-primary hover:underline hover:text-primary/80 transition-colors"
           >
             View Profile
           </button>
        </div>
        
        <div className="overflow-y-auto no-scrollbar p-6">
          <StoryStrip
            compact
            className="mb-2 -mx-1"
            showAddStory={liveUser.id === db.currentUser?.id}
            onlyUserId={liveUser.id}
          />
          <div 
            onClick={() => {
              onClose();
              window.dispatchEvent(new CustomEvent('navigate', { detail: { tab: 'profile', userId: liveUser.id } }));
            }}
            className="flex items-center gap-6 mb-6 cursor-pointer group/avatar"
          >
             <div className="w-20 h-20 shrink-0 shadow-sm group-hover/avatar:opacity-80 transition-opacity">
               <Avatar user={liveUser} className="w-20 h-20" />
             </div>
             <div className="flex gap-4 flex-1 justify-center">
                <div className="flex flex-col items-center">
                   <span className="font-bold text-lg">{userPosts.length}</span>
                   <span className="text-[12px] text-muted-foreground font-bold font-sans">Posts</span>
                </div>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setFollowListMode('followers');
                  }}
                  className="flex flex-col items-center hover:opacity-70"
                >
                   <span className="font-bold text-lg">{(liveUser.followers ?? 0).toLocaleString()}</span>
                   <span className="text-[12px] text-muted-foreground font-bold font-sans">Followers</span>
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setFollowListMode('following');
                  }}
                  className="flex flex-col items-center hover:opacity-70"
                >
                   <span className="font-bold text-lg">{(liveUser.following ?? 0).toLocaleString()}</span>
                   <span className="text-[12px] text-muted-foreground font-bold font-sans">Following</span>
                </button>
             </div>
          </div>
          
          <div className="mb-6">
             <div className="font-bold text-[15px] flex items-center gap-2 flex-wrap">
               <span>{liveUser.displayName}</span>
               <ProfilePremiumBadgeForUser user={liveUser} size="sm" />
             </div>
             <div className="text-[14px] text-foreground/90 mt-1 whitespace-pre-line">{liveUser.bio || 'Digital creator. Living life to the fullest. ✨ #lifestyle'}</div>
          </div>
          
          <div className="flex gap-3 mb-6">
             {liveUser.id !== db.currentUser?.id && (
               <button
                 type="button"
                 onClick={handleFollowToggle}
                 onMouseEnter={() => setFollowHover(true)}
                 onMouseLeave={() => setFollowHover(false)}
                 aria-pressed={!!followAction?.isFollowing}
                 className={`flex-1 py-1.5 font-bold rounded-lg text-sm border transition-all active:scale-95 ${
                   followAction?.isFollowing
                     ? followHover
                       ? 'bg-red-500/15 text-red-600 dark:text-red-400 border-red-500/40'
                       : 'bg-background text-foreground border-border hover:bg-secondary'
                     : followAction?.isRequested
                       ? 'bg-secondary text-foreground border-border'
                       : 'bg-primary text-primary-foreground border-transparent hover:bg-primary/90'
                 }`}
               >
                 {followAction
                   ? getFollowButtonHoverLabel(followAction, followHover)
                   : 'Follow'}
               </button>
             )}
             <button 
               onClick={() => {
                 onClose();
                 window.dispatchEvent(new CustomEvent('navigate', { detail: { tab: 'messages', chatId: liveUser.id } }));
               }}
               className="flex-1 py-1.5 bg-secondary text-foreground font-bold rounded-lg text-sm border border-border transition-colors hover:bg-secondary/70">Message</button>
          </div>
          
          {/* Grid */}
          <div className="border-t border-border pt-4">
             <div className="flex justify-center mb-4 text-foreground"><Grid className="w-6 h-6" /></div>
             {!canViewProfileContent ? (
               <ProfilePrivateContentGate username={liveUser.username || 'this user'} compact />
             ) : (
             <div className="grid grid-cols-3 gap-1">
               {userPosts.map((raw) => {
                 const post = resolvePost(db.posts, raw, db.users);
                 return (
                 <div key={post.id} className="aspect-square bg-secondary relative overflow-hidden group cursor-pointer">
                   <img src={safeMediaUrl(post.imageUrl)} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" onError={handleMediaError} />
                 </div>
                 );
               })}
               {userPosts.length === 0 && (
                 <div className="col-span-3 text-center py-10 text-muted-foreground text-sm font-medium">No posts yet</div>
               )}
             </div>
             )}
          </div>
        </div>
      </motion.div>
    </div>
    {followListMode && (
      <FollowListModal
        profileUserId={liveUser.id}
        mode={followListMode}
        onClose={() => setFollowListMode(null)}
      />
    )}
    </>
  );
}
