import React, { useEffect, useState } from 'react';
import { useDB } from '../../lib/useDB';
import { Settings, Grid, PlaySquare, Bookmark, UserSquare, Heart, MessageCircle, ArrowLeft, Link, CheckCircle2, Copy, X, Play, Eye, SquarePen, Archive } from 'lucide-react';
import { useToast } from '../../lib/ToastContext';
import { Avatar } from '../common/Avatar';
import { ProfilePremiumBadgeForUser } from '../common/ProfilePremiumBadge';

import { PostModal } from '../feed/PostModal';
import { StoryStrip } from '../feed/StoryStrip';
import { FollowListModal } from './FollowListModal';
import { BlockedUsersModal } from './BlockedUsersModal';
import { ProfileVisitorsModal } from './ProfileVisitorsModal';
import { CreatorLevelBadge } from './CreatorLevelBadge';
import { useDbRevision } from '../../lib/useDB';
import { PostArchiveModal } from './PostArchiveModal';
import { ProfileReelModal } from './ProfileReelModal';
import { ProfileTabEmpty } from './ProfileTabEmpty';
import { ProfileEditSettingsModal } from './ProfileEditSettingsModal';
import { ProfileFollowRequestsPanel } from './ProfileFollowRequestsPanel';
import { ProfilePrivateContentGate } from './ProfilePrivateContentGate';
import { useFollowActionState } from '../../lib/useFollowActionState';
import { followToggleToastMessage, getFollowButtonHoverLabel } from '../../lib/followPrivacy';
import { handleAvatarError, handleMediaError, fileToBase64 } from '../../lib/utils';
import { resolveUser, findUserById, postUserId, reelUserId } from '../../lib/safe';
import { resolvePost, resolveReel, buildCommentPayload, isPostTaggingUser, isPostActive } from '../../lib/entityResolve';
import { snapshotPostPlayback } from '../../lib/postPlayback';
import { resolvePublicUserId } from '../../lib/publicUserId';
import type { Post as PostEntity } from '../../types';
import type { ProfileVisitContext } from '../../lib/profileVisits';

export function ProfileScreen({ userId, onBack }: { userId?: string; onBack?: () => void }) {
  const db = useDB();
  const dbRevision = useDbRevision();
  const POSTS = db.posts;
  const currentUser = resolveUser(db.users, db.currentUser);
  const { showToast } = useToast();
  
  const targetUser = userId ? findUserById(db.users, userId, currentUser) : currentUser;
  const isCurrentUser = targetUser.id === currentUser.id;

  const [activeTab, setActiveTab] = useState<'posts' | 'reels' | 'saved' | 'tagged'>('posts');
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [showArchive, setShowArchive] = useState(false);
  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);
  const [selectedReelId, setSelectedReelId] = useState<string | null>(null);
  const [followListMode, setFollowListMode] = useState<'followers' | 'following' | null>(null);
  const [showBlockedUsers, setShowBlockedUsers] = useState(false);
  const [showProfileVisitors, setShowProfileVisitors] = useState(false);
  const [commentText, setCommentText] = useState('');
  const _commentInputRef = React.useRef<HTMLInputElement>(null);
  
  const [localUser, setLocalUser] = useState(targetUser);
  const [followButtonHover, setFollowButtonHover] = useState(false);
  const [settings, setSettings] = useState(db.settings);
  const followAction = useFollowActionState(isCurrentUser ? undefined : targetUser.id);
  const canViewProfileContent = isCurrentUser || (followAction?.canViewContent ?? true);
  const profileVisitorsEnabled = settings.profileVisitorsEnabled !== false;
  const profileVisitorCount =
    isCurrentUser && profileVisitorsEnabled ? db.getProfileVisitorCount(targetUser.id) : 0;

  const creatorProgress = React.useMemo(
    () => db.getCreatorProgress(targetUser.id),
    [
      db,
      dbRevision,
      targetUser.id,
      targetUser.followers,
      POSTS,
      db.reels,
      db.stories,
    ]
  );

  useEffect(() => {
    if (!showEditProfile) {
      setLocalUser(targetUser);
    }
    setSettings(db.settings);
  }, [
    targetUser.id,
    targetUser.isFollowing,
    targetUser.followers,
    targetUser.following,
    targetUser.displayName,
    targetUser.bio,
    targetUser.avatarUrl,
    targetUser.username,
    showEditProfile,
    db.settings,
  ]);

  const handleFollowToggle = () => {
    if (isCurrentUser || !targetUser?.id) return;
    db.toggleFollow(targetUser.id);
    const after = db.getFollowActionState(targetUser.id);
    const label = targetUser.username || targetUser.displayName || 'user';
    showToast(followToggleToastMessage(after, label));
    setFollowButtonHover(false);
  };

  const recordProfileVisitForViewer = React.useCallback(
    (context?: ProfileVisitContext) => {
      if (!isCurrentUser && targetUser?.id) {
        db.recordProfileVisit(targetUser.id, context);
      }
    },
    [isCurrentUser, targetUser?.id, db]
  );

  useEffect(() => {
    recordProfileVisitForViewer({ surface: 'profile' });
  }, [targetUser.id, recordProfileVisitForViewer]);

  useEffect(() => {
    if (isCurrentUser || !targetUser?.id) return;
    if (activeTab === 'posts') {
      recordProfileVisitForViewer({ surface: 'posts' });
    } else if (activeTab === 'reels') {
      recordProfileVisitForViewer({ surface: 'reels' });
    }
  }, [activeTab, isCurrentUser, targetUser?.id, recordProfileVisitForViewer]);

  useEffect(() => {
    if (isCurrentUser || !targetUser?.id) return;
    const handler = (event: Event) => {
      const detail = (event as CustomEvent<{
        profileUserId?: string;
        context?: ProfileVisitContext;
      }>).detail;
      if (detail?.profileUserId !== targetUser.id || !detail.context) return;
      recordProfileVisitForViewer(detail.context);
    };
    window.addEventListener('profile-visit-record', handler);
    return () => window.removeEventListener('profile-visit-record', handler);
  }, [isCurrentUser, targetUser?.id, recordProfileVisitForViewer]);

  const userPosts = (POSTS ?? []).filter(
    (p) => postUserId(p) === targetUser.id && !p.isArchived
  );
  const archivedPostCount = (POSTS ?? []).filter(
    (p) => postUserId(p) === targetUser.id && p.isArchived
  ).length;
  const userReels = (db.reels ?? []).filter((r) => reelUserId(r) === targetUser.id);
  const taggedPosts = (POSTS ?? []).filter(
    (p) =>
      isPostTaggingUser(p, targetUser.id, targetUser.username) && isPostActive(p)
  );
  const savedPosts = (POSTS ?? []).filter((p) => p.isSaved);

  const renderPostGrid = (
    items: PostEntity[],
    emptyTitle: string,
    emptyDescription: string
  ) => {
    if (items.length === 0) {
      return (
        <ProfileTabEmpty
          icon={Grid}
          title={emptyTitle}
          description={emptyDescription}
        />
      );
    }
    return (
      <div className="grid grid-cols-3 gap-1 md:gap-4 lg:gap-8">
        {items.map((raw) => {
          const post = resolvePost(db.posts, raw, db.users);
          return (
            <div
              key={post.id}
              onClick={() => {
                snapshotPostPlayback(post.id, 'modal');
                setSelectedPostId(post.id);
                recordProfileVisitForViewer({
                  surface: 'posts',
                  contentId: post.id,
                  previewUrl: post.imageUrl || post.videoUrl,
                });
              }}
              className="aspect-square bg-secondary group cursor-pointer relative rounded-xl overflow-hidden shadow-sm"
            >
              <img
                src={post.imageUrl || post.videoUrl || undefined}
                className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-500"
                alt=""
                onError={handleMediaError}
              />
              {post.videoUrl && !post.imageUrl && (
                <div className="absolute top-2 right-2 pointer-events-none">
                  <Play className="w-4 h-4 text-white drop-shadow-md fill-white" />
                </div>
              )}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white gap-4 backdrop-blur-[2px]">
                <div className="flex items-center gap-1 font-bold">
                  <Heart className="w-5 h-5 fill-white" /> {post.likes || 0}
                </div>
                <div className="flex items-center gap-1 font-bold">
                  <MessageCircle className="w-5 h-5 fill-white" /> {post.comments || 0}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    );
  };
  const selectedPost = selectedPostId
    ? resolvePost(db.posts, POSTS.find((p) => p.id === selectedPostId), db.users)
    : null;

  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const newAvatarUrl = await fileToBase64(file);
        setLocalUser({ ...localUser, avatarUrl: newAvatarUrl });
        db.updateUser(localUser.id, (u) => ({ ...u, avatarUrl: newAvatarUrl }));
      } catch {
        showToast('Error updating avatar');
      }
    }
  };

  const [showShareModal, setShowShareModal] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showNewCollectionModal, setShowNewCollectionModal] = useState(false);
  const [newCollectionName, setNewCollectionName] = useState('');
  const [_collections, setCollections] = useState(['Design Inspo', 'Moodboard']);

  const handleCreateCollection = () => {
      if (!newCollectionName.trim()) return;
      setCollections(prev => [...prev, newCollectionName]);
      setNewCollectionName('');
      setShowNewCollectionModal(false);
      showToast('Collection created!');
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(`https://instacollab.app/p/${selectedPost?.id}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  
  const _handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim() || !selectedPostId) return;
    db.addPostComment(
      selectedPostId,
      buildCommentPayload(currentUser, commentText)
    );
    setCommentText('');
  };

  const handleCopyUserId = async () => {
    try {
      await navigator.clipboard.writeText(resolvePublicUserId(targetUser));
      showToast('User ID copied');
    } catch {
      showToast('Unable to copy User ID');
    }
  };

  return (
    <div className="w-full max-w-[935px] mx-auto pt-8 px-4 flex flex-col min-h-0 pb-6">
      
      {/* Post Modal View */}
      {showNewCollectionModal && (
        <div className="fixed inset-0 bg-background z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0" onClick={() => setShowNewCollectionModal(false)}></div>
          <div className="bg-card border border-border w-full max-w-sm rounded-[24px] shadow-xl p-6 relative">
            <button onClick={() => setShowNewCollectionModal(false)} className="absolute top-4 right-4 p-2 text-muted-foreground hover:text-foreground"><X className="w-5 h-5"/></button>
            <h3 className="font-bold text-lg mb-4">New Collection</h3>
            <div className="mb-4">
               <input 
                 autoFocus
                 type="text" 
                 value={newCollectionName}
                 onChange={e => setNewCollectionName(e.target.value)}
                 className="w-full bg-secondary outline-none px-4 py-3 rounded-xl text-sm font-medium" 
                 placeholder="Collection Name" 
               />
            </div>
            <button 
              onClick={handleCreateCollection} 
              disabled={!newCollectionName.trim()}
              className="w-full bg-primary text-primary-foreground font-bold py-3 rounded-xl hover:bg-primary/90 disabled:opacity-50"
            >
              Create
            </button>
          </div>
        </div>
      )}

      {selectedPostId && (
        <PostModal postId={selectedPostId} onClose={() => setSelectedPostId(null)} />
      )}
      {selectedReelId && (
        <ProfileReelModal reelId={selectedReelId} onClose={() => setSelectedReelId(null)} />
      )}
      {followListMode && (
        <FollowListModal
          profileUserId={targetUser.id}
          mode={followListMode}
          onClose={() => setFollowListMode(null)}
        />
      )}

      {showBlockedUsers && isCurrentUser && (
        <BlockedUsersModal onClose={() => setShowBlockedUsers(false)} />
      )}

      {showProfileVisitors && isCurrentUser && profileVisitorsEnabled && (
        <ProfileVisitorsModal
          profileUserId={targetUser.id}
          onClose={() => setShowProfileVisitors(false)}
        />
      )}

      {showArchive && isCurrentUser && (
        <PostArchiveModal userId={targetUser.id} onClose={() => setShowArchive(false)} />
      )}

      {showEditProfile && (
        <ProfileEditSettingsModal
          onClose={() => setShowEditProfile(false)}
          onOpenSettings={() => setShowEditProfile(true)}
          targetUser={targetUser}
          isCurrentUser={isCurrentUser}
          localUser={localUser}
          setLocalUser={setLocalUser}
          fileInputRef={fileInputRef}
          handleAvatarChange={handleAvatarChange}
          onOpenBlockedUsers={() => setShowBlockedUsers(true)}
        />
      )}

      {onBack && (
        <button 
          onClick={onBack} 
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground font-semibold text-sm mb-6 transition-colors w-fit -mt-2"
        >
          <ArrowLeft className="w-4 h-4" /> Back
        </button>
      )}

      {/* Profile Header */}
      <div className="flex flex-col md:flex-row mb-12 gap-8 md:gap-24 items-center md:items-start max-w-[800px] w-full mx-auto">
        <div 
          className={`w-[150px] h-[150px] shrink-0 relative overflow-visible ${isCurrentUser ? 'group cursor-pointer' : ''}`} 
          onClick={isCurrentUser ? () => fileInputRef.current?.click() : undefined}
        >
          <Avatar user={targetUser} size="lg" className="w-full h-full" />
          {isCurrentUser && (
            <div className="absolute inset-0 rounded-full overflow-hidden bg-black/50 text-white text-[10px] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity font-bold pointer-events-none">UPDATE</div>
          )}
        </div>
        
        <div className="flex flex-col items-center md:items-start text-center md:text-left flex-1">
          
          <div className="flex flex-col md:flex-row items-center gap-4 mb-5">
            <h1 className="text-[20px] font-normal flex items-center gap-2 flex-wrap justify-center md:justify-start">
              <span>{targetUser.displayName}</span>
              <ProfilePremiumBadgeForUser user={targetUser} size="md" />
            </h1>
            <div className="flex items-center gap-2">
              {isCurrentUser ? (
                <>
                  <button
                    type="button"
                    onClick={() => setShowEditProfile(true)}
                    className="p-2 rounded-lg bg-secondary hover:bg-secondary/80 text-foreground transition-colors"
                    aria-label="Edit profile"
                    title="Edit profile"
                  >
                    <SquarePen className="w-5 h-5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowArchive(true)}
                    className="relative p-2 rounded-lg bg-secondary hover:bg-secondary/80 text-foreground transition-colors"
                    aria-label={
                      archivedPostCount > 0
                        ? `View archive, ${archivedPostCount} posts`
                        : 'View archive'
                    }
                    title={
                      archivedPostCount > 0
                        ? `View archive (${archivedPostCount})`
                        : 'View archive'
                    }
                  >
                    <Archive className="w-5 h-5" />
                    {archivedPostCount > 0 ? (
                      <span className="absolute -top-1 -right-1 min-w-[1.125rem] h-[1.125rem] px-0.5 flex items-center justify-center rounded-full bg-primary text-primary-foreground text-[10px] font-black leading-none">
                        {archivedPostCount > 99 ? '99+' : archivedPostCount}
                      </span>
                    ) : null}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (!profileVisitorsEnabled) {
                        setShowEditProfile(true);
                        showToast('Turn on Profile visitors in Settings & Privacy');
                        return;
                      }
                      setShowProfileVisitors(true);
                    }}
                    className={`relative p-2 rounded-lg transition-colors ${
                      profileVisitorsEnabled
                        ? 'bg-secondary hover:bg-secondary/80 text-foreground'
                        : 'bg-secondary/50 text-muted-foreground hover:bg-secondary/70'
                    }`}
                    aria-label={
                      profileVisitorsEnabled
                        ? `Profile visitors${profileVisitorCount > 0 ? `, ${profileVisitorCount}` : ''}`
                        : 'Profile visitors disabled'
                    }
                    title={
                      profileVisitorsEnabled
                        ? 'Profile visitors'
                        : 'Profile visitors off — enable in settings'
                    }
                  >
                    <Eye className="w-5 h-5" />
                    {profileVisitorsEnabled && profileVisitorCount > 0 ? (
                      <span className="absolute -top-1 -right-1 min-w-[1.125rem] h-[1.125rem] px-0.5 flex items-center justify-center rounded-full bg-primary text-primary-foreground text-[10px] font-black leading-none">
                        {profileVisitorCount > 99 ? '99+' : profileVisitorCount}
                      </span>
                    ) : null}
                  </button>
                  <button onClick={() => setShowEditProfile(true)} className="p-1 hover:opacity-70"><Settings className="w-6 h-6" /></button>
                </>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={handleFollowToggle}
                    onMouseEnter={() => setFollowButtonHover(true)}
                    onMouseLeave={() => setFollowButtonHover(false)}
                    onFocus={() => setFollowButtonHover(true)}
                    onBlur={() => setFollowButtonHover(false)}
                    aria-pressed={!!followAction?.isFollowing}
                    className={`px-6 py-1.5 rounded-lg text-[14px] font-bold transition-all active:scale-95 ${
                      followAction?.isFollowing
                        ? followButtonHover
                          ? 'bg-red-500/15 text-red-600 dark:text-red-400 border border-red-500/40 hover:bg-red-500/20'
                          : 'bg-secondary hover:bg-secondary/80 text-foreground border border-border'
                        : followAction?.isRequested
                          ? 'bg-secondary text-foreground border border-border'
                          : 'bg-primary hover:bg-primary/90 text-primary-foreground border border-transparent'
                    }`}
                  >
                    {followAction
                      ? getFollowButtonHoverLabel(followAction, followButtonHover)
                      : 'Follow'}
                  </button>
                  <button 
                    onClick={() => {
                      window.dispatchEvent(new CustomEvent('navigate', { detail: { tab: 'messages', chatId: targetUser.id } }));
                    }}
                    className="bg-secondary hover:bg-secondary/80 text-foreground px-6 py-1.5 rounded-lg text-[14px] font-bold transition-colors border border-border"
                  >
                    Message
                  </button>
                </>
              )}
            </div>
          </div>

          <div className="flex items-center justify-center md:justify-start gap-8 mb-4">
            <div><span className="font-bold">{userPosts.length}</span> posts</div>
            <button
              type="button"
              onClick={() => setFollowListMode('followers')}
              className="cursor-pointer hover:opacity-70 text-left"
            >
              <span className="font-bold">{(targetUser.followers ?? 0).toLocaleString()}</span> followers
            </button>
            <button
              type="button"
              onClick={() => setFollowListMode('following')}
              className="cursor-pointer hover:opacity-70 text-left"
            >
              <span className="font-bold">{(targetUser.following ?? 0).toLocaleString()}</span> following
            </button>
          </div>

          <CreatorLevelBadge progress={creatorProgress} className="mb-4 items-center md:items-start" />

          <div className="flex flex-col mb-4 items-center md:items-start">
            <span className="font-semibold text-[14px] flex items-center gap-2 font-mono">
              {resolvePublicUserId(targetUser)}
              <button
                type="button"
                onClick={handleCopyUserId}
                className="inline-flex items-center justify-center p-1 rounded-md text-muted-foreground hover:text-foreground hover:bg-secondary/60 transition-colors"
                aria-label="Copy user ID"
                title="Copy user ID"
              >
                <Copy className="w-3.5 h-3.5" />
              </button>
            </span>
            <span className="text-[14px] whitespace-pre-wrap mt-1 leading-relaxed">{targetUser.bio}</span>
          </div>

        </div>
      </div>

      <StoryStrip
        className="w-full"
        showAddStory={isCurrentUser}
        onlyUserId={targetUser.id}
      />

      {isCurrentUser && db.isAccountPrivate(targetUser.id) ? (
        <ProfileFollowRequestsPanel profileUserId={targetUser.id} />
      ) : null}

      {/* Tabs */}
      <div className="border-t border-border flex justify-center gap-12 text-[12px] font-bold text-muted-foreground uppercase tracking-widest h-[52px]">
         <div onClick={() => setActiveTab('posts')} className={`flex items-center gap-2 h-full cursor-pointer transition-colors ${activeTab === 'posts' ? 'border-t-2 border-foreground text-foreground' : 'hover:text-foreground'}`}>
             <Grid className="w-4 h-4" /> POSTS
         </div>
         <div onClick={() => setActiveTab('reels')} className={`flex items-center gap-2 h-full cursor-pointer transition-colors ${activeTab === 'reels' ? 'border-t-2 border-foreground text-foreground' : 'hover:text-foreground'}`}>
             <PlaySquare className="w-4 h-4" /> REELS
         </div>
         {isCurrentUser && (
           <div onClick={() => setActiveTab('saved')} className={`flex items-center gap-2 h-full cursor-pointer transition-colors ${activeTab === 'saved' ? 'border-t-2 border-foreground text-foreground' : 'hover:text-foreground'}`}>
               <Bookmark className="w-4 h-4" /> SAVED
           </div>
         )}
         <div onClick={() => setActiveTab('tagged')} className={`flex items-center gap-2 h-full cursor-pointer transition-colors ${activeTab === 'tagged' ? 'border-t-2 border-foreground text-foreground' : 'hover:text-foreground'}`}>
             <UserSquare className="w-4 h-4" /> TAGGED
         </div>
      </div>

      {!canViewProfileContent ? (
        <ProfilePrivateContentGate username={targetUser.username || 'this user'} />
      ) : null}

      {canViewProfileContent && activeTab === 'posts' &&
        renderPostGrid(
          userPosts,
          'No posts yet',
          isCurrentUser
            ? 'When you share photos and videos, they will show up here.'
            : 'When they share posts, they will appear here.'
        )}

      {canViewProfileContent && activeTab === 'reels' && (
        userReels.length === 0 ? (
          <ProfileTabEmpty
            icon={PlaySquare}
            title="No reels yet"
            description={
              isCurrentUser
                ? 'Create a reel from the + menu and it will appear on your profile.'
                : 'When they share reels, they will appear here.'
            }
          />
        ) : (
          <div className="grid grid-cols-3 gap-1 md:gap-4 lg:gap-8">
            {userReels.map((raw) => {
              const reel = resolveReel(db.reels, raw, db.users);
              return (
                <div
                  key={reel.id}
                  onClick={() => {
                    setSelectedReelId(reel.id);
                    recordProfileVisitForViewer({
                      surface: 'reels',
                      contentId: reel.id,
                      previewUrl: reel.videoUrl,
                    });
                  }}
                  className="aspect-square bg-secondary group cursor-pointer relative rounded-xl overflow-hidden shadow-sm"
                >
                  {reel.videoUrl ? (
                    <video
                      src={reel.videoUrl}
                      className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-500 pointer-events-none"
                      muted
                      playsInline
                      preload="metadata"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-zinc-800">
                      <PlaySquare className="w-10 h-10 text-muted-foreground" />
                    </div>
                  )}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-80 group-hover:opacity-100 transition-opacity">
                    <Play className="w-10 h-10 text-white drop-shadow-lg fill-white/90" />
                  </div>
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white gap-4 backdrop-blur-[2px]">
                    <div className="flex items-center gap-1 font-bold">
                      <Heart className="w-5 h-5 fill-white" /> {(reel.likes || 0).toLocaleString()}
                    </div>
                    <div className="flex items-center gap-1 font-bold">
                      <MessageCircle className="w-5 h-5 fill-white" /> {reel.comments || 0}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )
      )}

      {canViewProfileContent && activeTab === 'saved' && isCurrentUser && (
        <div className="pt-4 px-0">
          <p className="text-muted-foreground mb-4 font-medium text-sm text-center md:text-left px-4">
            Only you can see what you&apos;ve saved.
          </p>
          {renderPostGrid(
            savedPosts,
            'No saved posts yet',
            'Tap the bookmark on a post to save it for later.'
          )}
        </div>
      )}

      {canViewProfileContent && activeTab === 'tagged' &&
        renderPostGrid(
          taggedPosts,
          'No tagged posts',
          isCurrentUser
            ? 'When people tag you in posts, they will show up here.'
            : `Posts that tag @${targetUser.username} will appear here.`
        )}

      {/* Share Modal */}
      {showShareModal && selectedPost && (
         <div className="fixed inset-0 z-[300] flex items-end sm:items-center justify-center pointer-events-none">
           <div className="absolute inset-0 bg-background pointer-events-auto" onClick={() => setShowShareModal(false)}></div>
           <div className="w-full max-w-md bg-card border border-border rounded-t-3xl sm:rounded-3xl p-6 relative z-10 pointer-events-auto shadow-2xl overflow-hidden translate-y-0 opacity-100 transition-all duration-300">
              <div className="w-12 h-1.5 bg-muted rounded-full mx-auto mb-6 sm:hidden"></div>
              <h3 className="text-xl font-bold mb-6 text-center">Share to Messages</h3>
              <div className="flex gap-4 mb-6 overflow-x-auto no-scrollbar pb-2">
                 {db.users.filter(u => u.id !== currentUser.id).map(u => (
                    <div key={u.id} onClick={() => { 
                      setShowShareModal(false); 
                      db.addMessage(u.id, { text: `Shared a post: https://instacollab.app/p/${selectedPost.id}`, isAuthor: true });
                    }} className="flex flex-col items-center gap-2 cursor-pointer group min-w-[72px]">
                      <div className="w-14 h-14 rounded-full border border-border group-hover:border-primary transition-colors overflow-hidden bg-card">
                         <img src={u.avatarUrl || undefined} alt={u.username} className="w-full h-full object-cover" onError={handleAvatarError} />
                      </div>
                      <span className="text-xs font-bold text-center truncate w-full px-1">{u.username}</span>
                    </div>
                 ))}
              </div>
              <div className="flex items-center gap-3 p-3 bg-secondary rounded-xl border border-border">
                 <div className="w-10 h-10 rounded-lg bg-card flex items-center justify-center border border-border shrink-0">
                   <Link className="w-5 h-5 text-muted-foreground" />
                 </div>
                 <div className="flex-1 truncate text-sm font-medium text-muted-foreground">https://instacollab.app/p/{selectedPost.id}</div>
                 <button 
                   onClick={handleCopyLink}
                   className="px-4 py-2 bg-foreground text-background rounded-lg text-sm font-bold shrink-0 hover:opacity-90 transition-opacity flex items-center gap-2"
                 >
                   {copied ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                 </button>
              </div>
           </div>
         </div>
      )}

    </div>
  );
}

