import React from 'react';
import { User } from '../../types';
import { handleAvatarError } from '../../lib/utils';
import { useDB } from '../../lib/useDB';
import { getLiveRingClasses } from '../../lib/liveRing';
import { getStoryRingVisualState } from '../../lib/storySegments';
import { resolveUser } from '../../lib/safe';
import {
  AvatarStatusBadge,
  getAvatarStatusBadgeOutsidePosition,
  getAvatarStatusBadgeSize,
} from './AvatarStatusBadge';

interface AvatarProps {
  user: User;
  size?: 'sm' | 'md' | 'lg';
  /** Keep pulsing glow inside layout (suggestion cards, lists). Default pulls margin for story strip. */
  containGlow?: boolean;
  className?: string;
  onClick?: (e: React.MouseEvent) => void;
}

export function Avatar({
  user,
  size = 'md',
  containGlow = false,
  className = '',
  onClick,
}: AvatarProps) {
  const db = useDB();
  const safeUser = resolveUser(db.users, user, db.currentUser);
  const sizeClasses = {
    sm: 'w-9 h-9',
    md: 'w-12 h-12',
    lg: 'w-16 h-16',
  };

  const ring = getStoryRingVisualState(safeUser.id, {
    getUserStorySegments: db.getUserStorySegments.bind(db),
    hasViewedStory: db.hasViewedStory.bind(db),
    userStatus: safeUser.status,
    liveKind: safeUser.liveKind,
  });
  const { isMultiStory, isLive, hasStoryContent, liveKind } = ring;
  const liveRingClasses = getLiveRingClasses(liveKind);
  const isStory = hasStoryContent && !isLive;
  const hasRing = isLive || isStory;

  const badgeSize = getAvatarStatusBadgeSize(className, size);
  const badgeOutsidePosition = getAvatarStatusBadgeOutsidePosition(badgeSize);
  const compactRingClass = hasRing
    ? size === 'sm'
      ? 'avatar-ring-shell--compact avatar-ring-shell--sm'
      : size === 'md'
        ? 'avatar-ring-shell--compact'
        : 'avatar-ring-shell--lg'
    : '';

  const handleClick = (e: React.MouseEvent) => {
    if (isLive) {
      e.stopPropagation();
      e.preventDefault();
      window.dispatchEvent(new CustomEvent('navigate', { detail: { tab: 'live' } }));
      return;
    }

    if (isStory) {
      e.stopPropagation();
      e.preventDefault();
      window.dispatchEvent(new CustomEvent('open-story', { detail: { userId: safeUser.id } }));
      return;
    }

    if (onClick) {
      onClick(e);
      return;
    }
  };

  const statusBadge = isLive ? (
    <AvatarStatusBadge variant="live" size={badgeSize} />
  ) : isStory ? (
    <AvatarStatusBadge
      variant={isMultiStory ? 'story-multi' : 'story'}
      size={badgeSize}
    />
  ) : null;

  const ringGlowClass = isLive
    ? liveRingClasses.glow
    : isMultiStory
      ? 'avatar-ring-glow--multi'
      : 'avatar-ring-glow--story';
  const ringSpinnerClass = isLive
    ? liveRingClasses.spinner
    : isMultiStory
      ? 'avatar-ring-spinner--multi'
      : 'avatar-ring-spinner--story';

  const haloClass = [
    'avatar-ring-halo',
    containGlow ? 'avatar-ring-halo--contained' : '',
    size === 'sm'
      ? 'avatar-ring-halo--compact avatar-ring-halo--sm'
      : size === 'md'
        ? 'avatar-ring-halo--compact'
        : 'avatar-ring-halo--lg',
  ]
    .filter(Boolean)
    .join(' ');

  const ringShell = (
    <div className={`avatar-ring-shell ${compactRingClass} overflow-visible`}>
      <div className={`avatar-ring-glow ${ringGlowClass}`} />
      <div className={`avatar-ring-spinner ${ringSpinnerClass}`} />
      <div className="avatar-ring-face">
        <img
          src={safeUser.avatarUrl || undefined}
          alt={safeUser.username}
          className="h-full w-full object-cover"
          onError={handleAvatarError}
        />
      </div>
      {statusBadge && (
        <div className={badgeOutsidePosition}>{statusBadge}</div>
      )}
    </div>
  );

  return (
    <div
      className={`${hasRing ? haloClass : `relative ${sizeClasses[size]}`} ${className} shrink-0 cursor-pointer overflow-visible`}
      onClick={handleClick}
    >
      {hasRing ? ringShell : (
        <div className="absolute inset-0 overflow-hidden rounded-full border border-border bg-background">
          <img
            src={safeUser.avatarUrl || undefined}
            alt={safeUser.username}
            className="h-full w-full rounded-full object-cover"
            onError={handleAvatarError}
          />
        </div>
      )}
    </div>
  );
}
