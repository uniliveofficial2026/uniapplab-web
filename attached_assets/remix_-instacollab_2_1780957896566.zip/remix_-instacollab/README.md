<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/249d3a86-745b-4bd7-bcca-26d52b32e36c

## Extending the app

For **any user task on any screen**—likes, saves, follows, comments, messages, stories, create/delete, workspace, settings, and anything you add later—follow **[AGENTS.md](./AGENTS.md)** and the task catalog in **[src/lib/appDataTasks.ts](./src/lib/appDataTasks.ts)**. Every action must use the canonical `db` API and live `resolve*` reads so the entire app stays in sync.

**Live dev testing:** run `npm run dev` (or `npm run dev:live`), open the **Live dev** panel with **Ctrl+Shift+D**, and see every `db` write in real time. See **[docs/LIVE_DEV.md](./docs/LIVE_DEV.md)**.

**Stability before shipping:** run `npm run verify` (types, lint, build, health checks). See **[docs/STABILITY.md](./docs/STABILITY.md)**.

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`
