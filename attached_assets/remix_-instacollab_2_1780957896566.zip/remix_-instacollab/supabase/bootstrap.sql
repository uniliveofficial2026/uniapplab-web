-- InstaCollab — one-shot cloud database bootstrap (idempotent).
-- Supabase Dashboard → SQL Editor → New query → paste this entire file → Run.
-- Project: kgiaflmukkguzjtmcuqd (or your VITE_SUPABASE_URL project)

-- ─── profiles ───────────────────────────────────────────────────────────────

create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  username text not null,
  display_name text not null,
  avatar_url text,
  bio text default '' not null,
  profile_setup_complete boolean default false not null,
  public_user_id text,
  public_user_id_changed_at timestamptz,
  created_at timestamptz default now() not null,
  updated_at timestamptz default now() not null,
  constraint profiles_username_lowercase check (username = lower(username)),
  constraint profiles_username_format check (username ~ '^[a-z0-9_]{3,24}$')
);

alter table public.profiles
  add column if not exists public_user_id text,
  add column if not exists public_user_id_changed_at timestamptz;

update public.profiles
set public_user_id = username
where public_user_id is null or public_user_id = '';

create unique index if not exists profiles_username_key on public.profiles (username);

create unique index if not exists profiles_public_user_id_key
  on public.profiles (public_user_id)
  where public_user_id is not null and public_user_id <> '';

alter table public.profiles drop constraint if exists profiles_public_user_id_format;
alter table public.profiles
  add constraint profiles_public_user_id_format check (
    public_user_id is null
    or (
      public_user_id = lower(public_user_id)
      and public_user_id ~ '^[a-z0-9_]{3,24}$'
    )
  );

alter table public.profiles enable row level security;

drop policy if exists "profiles_select_public" on public.profiles;
create policy "profiles_select_public"
  on public.profiles for select using (true);

drop policy if exists "profiles_insert_own" on public.profiles;
create policy "profiles_insert_own"
  on public.profiles for insert with check (auth.uid() = id);

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own"
  on public.profiles for update
  using (auth.uid() = id)
  with check (auth.uid() = id);

create or replace function public.set_profiles_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists profiles_updated_at on public.profiles;
create trigger profiles_updated_at
  before update on public.profiles
  for each row execute function public.set_profiles_updated_at();

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  meta jsonb;
  uname text;
  dname text;
  avatar text;
  apple_name text;
begin
  meta := coalesce(new.raw_user_meta_data, '{}'::jsonb);
  uname := lower(regexp_replace(
    coalesce(meta->>'username', split_part(coalesce(new.email, ''), '@', 1)),
    '[^a-z0-9_]', '_', 'g'
  ));
  if length(uname) < 3 then
    uname := 'user_' || substr(replace(new.id::text, '-', ''), 1, 8);
  end if;
  apple_name := nullif(trim(both from concat_ws(' ',
    meta#>>'{name,firstName}',
    meta#>>'{name,lastName}'
  )), '');
  dname := coalesce(
    meta->>'display_name',
    meta->>'full_name',
    apple_name,
    meta->>'name',
    uname
  );
  avatar := coalesce(meta->>'avatar_url', meta->>'picture');
  insert into public.profiles (
    id, username, display_name, avatar_url, profile_setup_complete,
    public_user_id, public_user_id_changed_at
  )
  values (new.id, uname, dname, avatar, false, uname, now())
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

alter table public.profiles replica identity full;

-- ─── user_app_state (realtime sync) ─────────────────────────────────────────

create table if not exists public.user_app_state (
  user_id uuid primary key references auth.users (id) on delete cascade,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create index if not exists user_app_state_updated_at_idx on public.user_app_state (updated_at desc);

alter table public.user_app_state enable row level security;

drop policy if exists "user_app_state_select_own" on public.user_app_state;
create policy "user_app_state_select_own"
  on public.user_app_state for select using (auth.uid() = user_id);

drop policy if exists "user_app_state_insert_own" on public.user_app_state;
create policy "user_app_state_insert_own"
  on public.user_app_state for insert with check (auth.uid() = user_id);

drop policy if exists "user_app_state_update_own" on public.user_app_state;
create policy "user_app_state_update_own"
  on public.user_app_state for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create or replace function public.set_user_app_state_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists user_app_state_updated_at on public.user_app_state;
create trigger user_app_state_updated_at
  before update on public.user_app_state
  for each row execute function public.set_user_app_state_updated_at();

alter table public.user_app_state replica identity full;

do $$
begin
  alter publication supabase_realtime add table public.profiles;
exception
  when duplicate_object then null;
  when undefined_object then null;
end $$;

do $$
begin
  alter publication supabase_realtime add table public.user_app_state;
exception
  when duplicate_object then null;
  when undefined_object then null;
end $$;

-- Notify PostgREST to reload schema (fixes "schema cache" after creating tables)
notify pgrst, 'reload schema';
