# @deepar/beauty

DeepAR Beauty is an easy-to-use API for beautification and makeup with DeepAR SDK. 

Available features:
- Skin smoothing (Acne removal).
- Face morphing.
- Face makeup.
- Eye makeup.
- Lip makeup.
- Eye coloring.
- Image filters.
- Background blur and background replacement (green screen).

DeepAR Beauty is available on these platforms:
- Web (BETA).
- Android (coming soon).
- iOS/MacOS (coming soon).

> ❗ DeepAR Beauty is installed and licensed separately from the DeepAR SDK.

# NPM API

Time-limited version of the API is available for testing on NPM, featuring a watermark and a 3-minute usage limit. 
For clients seeking an unrestricted production version, we offer the option to engage in a commercial partnership. 
Once a deal is finalized, we will provide a custom production build of the API, 
tailored to your specific domain requirements, ensuring seamless integration without limitations.

Please contact us to initiate the commercial process and unlock the full potential of the DeepAR Beauty API: 
[here](https://www.deepar.ai/contact#demo-form).


# Beauty Demo

To test out all the features of the DeepAR Beauty here is a demo app: [https://demo.deepar.ai/beauty/](https://demo.deepar.ai/beauty/).

- Try out our looks and presets by clicking the brush icon in top-left.
- See before and after by clicking the eye icon in the top-left.
- Test out all the available Beauty API with the sliders, toggles and color pickers on the right hand tab.
- Open up the Developer Tools Console in your browser and type the API directly to test it.

# Install

## via NPM

Install from NPM.
```shell
npm install @deepar/beauty
```

Import as ES6 module.
```js
import * as Beauty from "@deepar/beauty"
```

# Fetch from CDN

Fetch from jsDelivr.
```html
<script src="https://cdn.jsdelivr.net/npm/@deepar/beauty"></script>
```

Alternatively, you can import DeepAR as an ES6 module.

Via `<script type='module'>`.

```html
<script type='module'>
    import * as Beauty from 'https://cdn.jsdelivr.net/npm/@deepar/beauty/dist/beauty-deepar.esm.js';
</script>
```

Or via dynamic [import](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/import).

```js
const deepar = await import('https://cdn.jsdelivr.net/npm/@deepar/beauty/dist/beauty-deepar.esm.js');
```

# Install DeepAR

DeepAR Beauty works on top of [DeepAR](https://www.npmjs.com/package/deepar).
Please install it and set it up first. There is a free license for development and testing.

# Initialize Beauty API

Initialize DeepAR first.
```js
const deepAR = await deepar.initialize({
    licenseKey: "your_license_key_here",
    previewElement: document.querySelector('#deepar-div')
})
```
Then initialize DeepAR Beauty.
```js
const beauty = await Beauty.initializeBeauty(deepAR, "https://cdn.jsdelivr.net/npm/@deepar/beauty/dist/");
```
You must provide a path to the root directory of
the DeepAR Beauty library. That path will be used to fetch all assets.
The easiest way is to provide a path to jsDelvr DeepAR Beauty package.
Just make sure to pass the correct package version. The other way is to
copy the whole DeepAR Beauty library directory from `node_modules` to `dist`
and pass a relative path to the copied directory.
# Getting started

DeepAR Beauty API is straightforward to use. You can start experimenting with these API calls.
```js
beauty.faceMorphing.eyeSize.set(-50)
beauty.skinSmoothing.set(85)
beauty.faceMakeup.blush.intensity.set(40)
beauty.faceMakeup.blush.color.set({r:226, g:132, b:130, a:255})
beauty.lipMakeup.lipstick.enable.set(true)
beauty.lipMakeup.lipstick.shade.setTemplate("matteNude")
beauty.lipMakeup.lipstick.amount.set(70)
beauty.colorFilters.filter.setTemplate("filmContrast")
beauty.disable(true)
beauty.disable(false)
```

# API explained

Beauty API consists of parameters grouped into namespaces based on functionality. 
For example, the `eyeSize` parameter is contained in the `faceMorphing` namespace. 
A full API call looks like this:
```js
beauty.faceMorphing.eyeSize.set(-50)
```

Each namespace can have more namespaces nested in them. For example, `lipMakeup` 
namespace has two more namespaces nested: `lipstick` and `lipGloss`. 
Each is referenced like this: 
- `lipMakeup.lipstick`
- `lipMakeup.lipGloss`

Each namespace can contain one or more parameters. For example, `lipMakeup.lipstick`
namespace contains 3 parameters: `enable`, `shade` and `amount`.
Example of calling all of them:
```js
beauty.lipMakeup.lipstick.enable.set(true)
beauty.lipMakeup.lipstick.shade.setTemplate("matteNude")
beauty.lipMakeup.lipstick.amount.set(70)
```

### Common parameter API 
Each Beauty parameter has 5 common API calls:
- `set(value, id?)` - Set the value of the parameter (and optionally set the value id).
- `get()` - Get the current value of the parameter.
- `reset()` - Reset the parameter to its default value.
- `disable(boolean)` - Disable/enable the parameter. If parameter is disabled it will use its default value. This is used to implement toggling before/after functionality.
- `getId()` - Get the current id of the parameter.

### Parameter types
Parameters can be of 4 types:
- Number.
- Boolean.
- Color.
- Texture.

Number parameters have a valid range. For example, `faceMoprhing.eyeSize` is a number
parameter with a valid range [-100, 100]. Example usage:
```js
beauty.faceMorphing.eyeSize.set(-50)
```

Boolean parameter example usage:
```js
beauty.lipMakeup.lipstick.enable.set(true)
```

Color parameters are RGBA values in range [0, 255]. Example usage:
```js
beauty.faceMakeup.blush.color.set({r:226, g:132, b:130, a:255})
```

Texture parameters are images. They are most commonly set with template values (read next section).
But they can also be set with custom images. Supported image types are:
- png
- jpeg
- webp 

Example usage:
```js
// Set with template.
beauty.lipMakeup.lipstick.shade.setTemplate("matteNude")
// Set with custom image.
beauty.lipMakeup.lipstick.shade.set("url/to/some/image")
```
### Common namespace API
Each Beauty namespace has two common API calls:
- `reset()` - Reset all child parameters and namespaces to default values.
- `disable(boolean)` - Disable/enable all child parameters and namespaces. Works the same as parameter disable/enable, but just on a namespace level.

Example of resetting few namespaces:
```js
beauty.faceMorphing.reset()
beauty.faceMakeup.blush.reset()
beauty.lipMakeup.lipstick.reset()
beauty.eyeMakeup.reset()
```

Reset all Beauty parameters:
```js
beauty.reset()
```

Temporarily disable all face makeup to compare before and after:
```js
beauty.faceMakeup.disable(true)
// Later re-enable...
beauty.faceMakeup.disable(false)
```

Temporarily disable all beauty to compare before and after:
```js
beauty.disable(true)
// Later re-enable...
beauty.disable(false)
```

### Template values
Some Beauty parameters come with prepackaged values/assets for easier use. For example,
blush and contours comes with few commonly used colors, eyelashes comes with many prepackaged looks,
and lipstick comes with many prepackaged shades.

These prepackaged values/assets are called **templates**. Parameters that have templates
share these 3 additional API calls:
- `setTemplate(template)` - Set parameter template.
- `getTemplateValue(template)` - Returns the underlying value of the given template.
- `getTemplates()` - Returns a full list of templates.

Templates are referenced with a string name or an enum. For example, these two API calls
are equivalent.
```js
beauty.lipMakeup.lipstick.shade.setTemplate("caramel")
beauty.lipMakeup.lipstick.shade.setTemplate(Beauty.LipstickShadeTemplate.caramel)
```

### Looks and presets
DeepAR Beauty comes with ready-made looks and presets. These can be used as-is, or 
they can be a great starting point for making new looks or presets. They are
also used to save and share the creations made with DeepAR Beauty.

> 🎁 Download looks and presets [here](https://s3.eu-west-1.amazonaws.com/sdk.developer.deepar.ai/beauty-plugin/presets/beauty-presets.zip).

What is the difference between looks vs presets? Presets are part of a whole look
and they can be combined to make a completely new look. For example, there are 
presets for each main category: face makeup, eye makeup and lip makeup.

To import a look/preset call:
```js
beauty.importPreset("path/to/preset")
```

To export a look/preset call:
```js
beauty.exportPreset(type)
```
Where type can be:
- `Beauty.ExportType.LOOK` or `"LOOK"`.
- `Beauty.ExportType.PRESET` or `"PRESET"`.
- `Beauty.ExportType.PARAMETER_PRESET` or `"PARAMETER_PRESET"`.

> ⚠️ NOTE: Disabled parameters will not be exported.

### About IDs
Each Beauty parameter has these 2 common API calls:
- `set(value, id?)` - Set the value of the parameter (and optionally set the value id).
- `getId()` - Get the current id of the parameter.

The ID parameter is just a plain string.

What are this IDs used for? They are used to match the exact assets/values for parameters
when they are exported/imported. For example, when you import some look/preset,
you may want to show in the UI value for some parameter. For number parameters, it's
easy, you just show the number of `getValue()` API. But for texture parameters 
it's a bit trickier. You can also call `getValue()` but that will return a image,
and it's hard to compare images. So you can instead call `getId()` which will return a
string that you can easily compare.

### Runtime API
To list all the available parameters and inquire about their info, 
use the API in `runtime` namespace.
Example call:
```js
beauty.runtime.setParameterValue("faceMorphing.eyeSize", -50)
```

Here is a list of all the runtime API methods.

1. #### `getParametersInfo()`
Get a list of all the parameters, their default values, valid ranges and templates.

Returns a list of ParameterInfo:
```typescript
interface ParameterInfo {
    type: "float" | "boolean" | "rgb" | "rgba" | "texture",
    name: string,
    defaultValue: ParameterType,
    templates?: string[],
    validRange?: { min: number, max: number };
}
```

2. #### `setParameterValue(name: string, value: ParameterType, id?: string)`
Set the value of the parameter by the given name.

3. #### `getParameterValue(name: string)`
Get the value of the parameter by the given name.

Returns the current value of the parameter.

4. #### `reset(name: string)`
Reset the parameter/namespace by the given name.

5. #### `disable(name: string)`
Disable/enable the parameter/namespace by the given name.

6. #### `getParameterId(name: string)`
Get the id of the parameter by the given name.

Returns the current id of the parameter.

7. #### `setParameterTemplate(name: string, template: string)`
Set the template for the parameter by the given name.

8. #### `getParameterTemplates: (name: string)`
Get all the templates available of the parameter by the given name.

Returns the list of template names.

9. #### `getParameterTemplateValue: (name: string, template: string)`
Get the value associated with the template of the parameter by the given name.

Returns the template value.
# Parameters
This section lists all the parameters available, their default values and templates.
## Parameters by namespaces
- skinSmoothing (float)
- faceMorphing
    - eyebrowsThickness (float)
    - eyebrowsHeight (float)
    - foreheadSize (float)
    - lipsWidth (float)
    - lipFullness (float)
    - jawlineShape (float)
    - faceShape (float)
    - noseSize (float)
    - mouthPositionVertical (float)
    - eyeSize (float)
    - chinSize (float)
- faceMakeup
    - foundation
        - color (rgba)
        - amount (float)
    - blush
        - applicationArea (texture)
        - color (rgba)
        - intensity (float)
    - highlighter
        - applicationArea (texture)
        - color (rgba)
        - intensity (float)
    - contouring
        - applicationArea (texture)
        - color (rgba)
        - intensity (float)
    - cheekGlitter
        - enable (boolean)
        - color (rgba)
- eyeMakeup
    - eyeliner
        - enable (boolean)
        - look (texture)
    - eyeshadow
        - basic
            - enable (boolean)
            - look (texture)
            - color (rgba)
        - threeColors
            - enable (boolean)
            - color1 (rgba)
            - color2 (rgba)
            - color3 (rgba)
        - special
            - enable (boolean)
            - look (texture)
        - glitter
            - enable (boolean)
            - look (texture)
            - intensity (float)
    - eyelashes
        - enable (boolean)
        - look (texture)
- lipMakeup
    - lipstick
        - enable (boolean)
        - shade (texture)
        - amount (float)
    - lipGloss
        - enable (boolean)
        - gloss (texture)
        - amount (float)
- eyeEnhancements
    - eyeColor
        - enable (boolean)
        - color (rgba)
- colorFilters
    - filter (texture)
    - intensity (float)
- background
    - blur
        - enable (boolean)
        - intensity (float)
    - image
        - enable (boolean)
        - background (texture)
## Parameter details
## `skinSmoothing`
- Type: number
- Default value: `0`
- Valid range: `[0, 100]`
## `faceMorphing.eyebrowsThickness`
- Type: number
- Default value: `0`
- Valid range: `[-100, 100]`
## `faceMorphing.eyebrowsHeight`
- Type: number
- Default value: `0`
- Valid range: `[-100, 100]`
## `faceMorphing.foreheadSize`
- Type: number
- Default value: `0`
- Valid range: `[-100, 100]`
## `faceMorphing.lipsWidth`
- Type: number
- Default value: `0`
- Valid range: `[-100, 100]`
## `faceMorphing.lipFullness`
- Type: number
- Default value: `0`
- Valid range: `[-100, 100]`
## `faceMorphing.jawlineShape`
- Type: number
- Default value: `0`
- Valid range: `[-100, 100]`
## `faceMorphing.faceShape`
- Type: number
- Default value: `0`
- Valid range: `[-100, 100]`
## `faceMorphing.noseSize`
- Type: number
- Default value: `0`
- Valid range: `[-100, 100]`
## `faceMorphing.mouthPositionVertical`
- Type: number
- Default value: `0`
- Valid range: `[-100, 100]`
## `faceMorphing.eyeSize`
- Type: number
- Default value: `0`
- Valid range: `[-100, 100]`
## `faceMorphing.chinSize`
- Type: number
- Default value: `0`
- Valid range: `[-100, 100]`
## `faceMakeup.foundation.color`
- Type: RGBA Color
- Default value: light1 `(r: 255, g: 249, b: 232, a: 255)`
- Templates: 
    - `FoundationColorTemplate.light1` or `"light1"`. Value: `(r: 255, g: 249, b: 232, a: 255)`
    - `FoundationColorTemplate.light2` or `"light2"`. Value: `(r: 247, g: 221, b: 193, a: 255)`
    - `FoundationColorTemplate.light3` or `"light3"`. Value: `(r: 229, g: 183, b: 170, a: 255)`
    - `FoundationColorTemplate.light4` or `"light4"`. Value: `(r: 244, g: 204, b: 163, a: 255)`
    - `FoundationColorTemplate.light5` or `"light5"`. Value: `(r: 252, g: 244, b: 198, a: 255)`
    - `FoundationColorTemplate.light6` or `"light6"`. Value: `(r: 247, g: 211, b: 158, a: 255)`
    - `FoundationColorTemplate.light7` or `"light7"`. Value: `(r: 214, g: 188, b: 137, a: 255)`
    - `FoundationColorTemplate.medium1` or `"medium1"`. Value: `(r: 219, g: 181, b: 147, a: 255)`
    - `FoundationColorTemplate.medium2` or `"medium2"`. Value: `(r: 181, g: 137, b: 104, a: 255)`
    - `FoundationColorTemplate.medium3` or `"medium3"`. Value: `(r: 232, g: 153, b: 99, a: 255)`
    - `FoundationColorTemplate.medium4` or `"medium4"`. Value: `(r: 198, g: 130, b: 89, a: 255)`
    - `FoundationColorTemplate.medium5` or `"medium5"`. Value: `(r: 216, g: 150, b: 104, a: 255)`
    - `FoundationColorTemplate.medium6` or `"medium6"`. Value: `(r: 155, g: 119, b: 73, a: 255)`
    - `FoundationColorTemplate.dark1` or `"dark1"`. Value: `(r: 163, g: 117, b: 91, a: 255)`
    - `FoundationColorTemplate.dark2` or `"dark2"`. Value: `(r: 137, g: 109, b: 84, a: 255)`
    - `FoundationColorTemplate.dark3` or `"dark3"`. Value: `(r: 102, g: 68, b: 38, a: 255)`
    - `FoundationColorTemplate.dark4` or `"dark4"`. Value: `(r: 84, g: 63, b: 38, a: 255)`
    - `FoundationColorTemplate.dark5` or `"dark5"`. Value: `(r: 96, g: 56, b: 38, a: 255)`
## `faceMakeup.foundation.amount`
- Type: number
- Default value: `0`
- Valid range: `[0, 100]`
## `faceMakeup.blush.applicationArea`
- Type: texture
- Default value: long
- Templates: 
    - `BlushApplicationAreaTemplate.long` or `"long"`
    - `BlushApplicationAreaTemplate.heart` or `"heart"`
    - `BlushApplicationAreaTemplate.oval` or `"oval"`
    - `BlushApplicationAreaTemplate.round` or `"round"`
    - `BlushApplicationAreaTemplate.square` or `"square"`
## `faceMakeup.blush.color`
- Type: RGBA Color
- Default value: light `(r: 232, g: 160, b: 130, a: 255)`
- Templates: 
    - `BlushColorTemplate.light` or `"light"`. Value: `(r: 232, g: 160, b: 130, a: 255)`
    - `BlushColorTemplate.red` or `"red"`. Value: `(r: 198, g: 114, b: 124, a: 255)`
    - `BlushColorTemplate.dark` or `"dark"`. Value: `(r: 186, g: 119, b: 109, a: 255)`
    - `BlushColorTemplate.lightRed` or `"lightRed"`. Value: `(r: 226, g: 132, b: 130, a: 255)`
## `faceMakeup.blush.intensity`
- Type: number
- Default value: `0`
- Valid range: `[0, 100]`
## `faceMakeup.highlighter.applicationArea`
- Type: texture
- Default value: wide
- Templates: 
    - `HighlighterApplicationAreaTemplate.wide` or `"wide"`
    - `HighlighterApplicationAreaTemplate.tall` or `"tall"`
    - `HighlighterApplicationAreaTemplate.mid` or `"mid"`
    - `HighlighterApplicationAreaTemplate.upper` or `"upper"`
    - `HighlighterApplicationAreaTemplate.lower` or `"lower"`
## `faceMakeup.highlighter.color`
- Type: RGBA Color
- Default value: white `(r: 244, g: 237, b: 239, a: 255)`
- Templates: 
    - `HighlighterColorTemplate.white` or `"white"`. Value: `(r: 244, g: 237, b: 239, a: 255)`
    - `HighlighterColorTemplate.light` or `"light"`. Value: `(r: 247, g: 229, b: 219, a: 255)`
    - `HighlighterColorTemplate.red` or `"red"`. Value: `(r: 239, g: 188, b: 188, a: 255)`
    - `HighlighterColorTemplate.yellow` or `"yellow"`. Value: `(r: 252, g: 244, b: 196, a: 255)`
    - `HighlighterColorTemplate.purple` or `"purple"`. Value: `(r: 221, g: 214, b: 247, a: 255)`
## `faceMakeup.highlighter.intensity`
- Type: number
- Default value: `0`
- Valid range: `[0, 100]`
## `faceMakeup.contouring.applicationArea`
- Type: texture
- Default value: oblong
- Templates: 
    - `ContouringApplicationAreaTemplate.oblong` or `"oblong"`
    - `ContouringApplicationAreaTemplate.round` or `"round"`
    - `ContouringApplicationAreaTemplate.diamond` or `"diamond"`
    - `ContouringApplicationAreaTemplate.oval` or `"oval"`
    - `ContouringApplicationAreaTemplate.triangle` or `"triangle"`
## `faceMakeup.contouring.color`
- Type: RGBA Color
- Default value: `(r: 204, g: 158, b: 109, a: 255)`
- Templates: 
    - `ContouringColorTemplate.shade1` or `"shade1"`. Value: `(r: 204, g: 158, b: 109, a: 255)`
    - `ContouringColorTemplate.shade2` or `"shade2"`. Value: `(r: 147, g: 114, b: 96, a: 255)`
    - `ContouringColorTemplate.shade3` or `"shade3"`. Value: `(r: 163, g: 119, b: 104, a: 255)`
    - `ContouringColorTemplate.shade4` or `"shade4"`. Value: `(r: 145, g: 96, b: 68, a: 255)`
    - `ContouringColorTemplate.shade5` or `"shade5"`. Value: `(r: 109, g: 76, b: 56, a: 255)`
## `faceMakeup.contouring.intensity`
- Type: number
- Default value: `0`
- Valid range: `[0, 100]`
## `faceMakeup.cheekGlitter.enable`
- Type: boolean
- Default value: `False`
## `faceMakeup.cheekGlitter.color`
- Type: RGBA Color
- Default value: yellow `(r: 232, g: 240, b: 72, a: 255)`
- Templates: 
    - `CheekGlitterColorTemplate.white` or `"white"`. Value: `(r: 255, g: 255, b: 255, a: 255)`
    - `CheekGlitterColorTemplate.pink` or `"pink"`. Value: `(r: 189, g: 102, b: 184, a: 255)`
    - `CheekGlitterColorTemplate.purple` or `"purple"`. Value: `(r: 185, g: 85, b: 213, a: 255)`
    - `CheekGlitterColorTemplate.green` or `"green"`. Value: `(r: 52, g: 163, b: 54, a: 255)`
    - `CheekGlitterColorTemplate.yellow` or `"yellow"`. Value: `(r: 232, g: 240, b: 72, a: 255)`
## `eyeMakeup.eyeliner.enable`
- Type: boolean
- Default value: `False`
## `eyeMakeup.eyeliner.look`
- Type: texture
- Default value: basic
- Templates: 
    - `EyelinerLookTemplate.basic` or `"basic"`
    - `EyelinerLookTemplate.drama` or `"drama"`
    - `EyelinerLookTemplate.smooth` or `"smooth"`
    - `EyelinerLookTemplate.porcelain` or `"porcelain"`
    - `EyelinerLookTemplate.spinx` or `"spinx"`
    - `EyelinerLookTemplate.vivid` or `"vivid"`
    - `EyelinerLookTemplate.subtleWhite` or `"subtleWhite"`
    - `EyelinerLookTemplate.dramaWhite` or `"dramaWhite"`
    - `EyelinerLookTemplate.wingEyes` or `"wingEyes"`
## `eyeMakeup.eyeshadow.basic.enable`
- Type: boolean
- Default value: `False`
## `eyeMakeup.eyeshadow.basic.look`
- Type: texture
- Default value: basic
- Templates: 
    - `BasicLookTemplate.basic` or `"basic"`
    - `BasicLookTemplate.cateye` or `"cateye"`
    - `BasicLookTemplate.smokey` or `"smokey"`
    - `BasicLookTemplate.winged` or `"winged"`
## `eyeMakeup.eyeshadow.basic.color`
- Type: RGBA Color
- Default value: black `(r: 0, g: 0, b: 0, a: 178)`
- Templates: 
    - `BasicColorTemplate.black` or `"black"`. Value: `(r: 0, g: 0, b: 0, a: 178)`
    - `BasicColorTemplate.brown` or `"brown"`. Value: `(r: 43, g: 28, b: 15, a: 165)`
    - `BasicColorTemplate.lightRed` or `"lightRed"`. Value: `(r: 40, g: 0, b: 0, a: 178)`
    - `BasicColorTemplate.darkRed` or `"darkRed"`. Value: `(r: 63, g: 17, b: 12, a: 178)`
    - `BasicColorTemplate.purple` or `"purple"`. Value: `(r: 76, g: 63, b: 94, a: 178)`
    - `BasicColorTemplate.blue` or `"blue"`. Value: `(r: 51, g: 71, b: 119, a: 140)`
    - `BasicColorTemplate.aqua` or `"aqua"`. Value: `(r: 53, g: 79, b: 61, a: 127)`
    - `BasicColorTemplate.pink` or `"pink"`. Value: `(r: 127, g: 79, b: 86, a: 127)`
## `eyeMakeup.eyeshadow.threeColors.enable`
- Type: boolean
- Default value: `False`
## `eyeMakeup.eyeshadow.threeColors.color1`
- Type: RGBA Color
- Default value: purple `(r: 108, g: 6, b: 104, a: 255)`
- Templates: 
    - `ThreeColorsColor1Template.purple` or `"purple"`. Value: `(r: 108, g: 6, b: 104, a: 255)`
    - `ThreeColorsColor1Template.red` or `"red"`. Value: `(r: 204, g: 5, b: 5, a: 255)`
    - `ThreeColorsColor1Template.yellow` or `"yellow"`. Value: `(r: 231, g: 146, b: 96, a: 255)`
## `eyeMakeup.eyeshadow.threeColors.color2`
- Type: RGBA Color
- Default value: yellow `(r: 231, g: 146, b: 96, a: 255)`
- Templates: 
    - `ThreeColorsColor2Template.purple` or `"purple"`. Value: `(r: 108, g: 6, b: 104, a: 255)`
    - `ThreeColorsColor2Template.red` or `"red"`. Value: `(r: 204, g: 5, b: 5, a: 255)`
    - `ThreeColorsColor2Template.yellow` or `"yellow"`. Value: `(r: 231, g: 146, b: 96, a: 255)`
## `eyeMakeup.eyeshadow.threeColors.color3`
- Type: RGBA Color
- Default value: yellow `(r: 231, g: 146, b: 96, a: 255)`
- Templates: 
    - `ThreeColorsColor3Template.purple` or `"purple"`. Value: `(r: 108, g: 6, b: 104, a: 255)`
    - `ThreeColorsColor3Template.red` or `"red"`. Value: `(r: 204, g: 5, b: 5, a: 255)`
    - `ThreeColorsColor3Template.yellow` or `"yellow"`. Value: `(r: 231, g: 146, b: 96, a: 255)`
## `eyeMakeup.eyeshadow.special.enable`
- Type: boolean
- Default value: `False`
## `eyeMakeup.eyeshadow.special.look`
- Type: texture
- Default value: redEyes
- Templates: 
    - `SpecialLookTemplate.redEyes` or `"redEyes"`
    - `SpecialLookTemplate.greenEyes` or `"greenEyes"`
    - `SpecialLookTemplate.blueEyes` or `"blueEyes"`
    - `SpecialLookTemplate.diamondEyes` or `"diamondEyes"`
    - `SpecialLookTemplate.darkMetal` or `"darkMetal"`
    - `SpecialLookTemplate.rainbow` or `"rainbow"`
    - `SpecialLookTemplate.kardashian` or `"kardashian"`
    - `SpecialLookTemplate.redBlueWhite` or `"redBlueWhite"`
    - `SpecialLookTemplate.moody` or `"moody"`
    - `SpecialLookTemplate.blueStrike` or `"blueStrike"`
    - `SpecialLookTemplate.dashingPink` or `"dashingPink"`
    - `SpecialLookTemplate.cateye` or `"cateye"`
    - `SpecialLookTemplate.underBlue` or `"underBlue"`
    - `SpecialLookTemplate.sunsetEyes` or `"sunsetEyes"`
## `eyeMakeup.eyeshadow.glitter.enable`
- Type: boolean
- Default value: `False`
## `eyeMakeup.eyeshadow.glitter.look`
- Type: texture
- Default value: white
- Templates: 
    - `GlitterLookTemplate.white` or `"white"`
    - `GlitterLookTemplate.rainbow` or `"rainbow"`
    - `GlitterLookTemplate.gold` or `"gold"`
    - `GlitterLookTemplate.marble` or `"marble"`
    - `GlitterLookTemplate.blue` or `"blue"`
    - `GlitterLookTemplate.green` or `"green"`
    - `GlitterLookTemplate.softNeon` or `"softNeon"`
    - `GlitterLookTemplate.blueSpark` or `"blueSpark"`
    - `GlitterLookTemplate.fire` or `"fire"`
    - `GlitterLookTemplate.galaxy` or `"galaxy"`
## `eyeMakeup.eyeshadow.glitter.intensity`
- Type: number
- Default value: `100`
- Valid range: `[0, 100]`
## `eyeMakeup.eyelashes.enable`
- Type: boolean
- Default value: `False`
## `eyeMakeup.eyelashes.look`
- Type: texture
- Default value: basic1
- Templates: 
    - `EyelashesLookTemplate.basic1` or `"basic1"`
    - `EyelashesLookTemplate.basic2` or `"basic2"`
    - `EyelashesLookTemplate.basic3` or `"basic3"`
    - `EyelashesLookTemplate.basic4` or `"basic4"`
    - `EyelashesLookTemplate.cateye1` or `"cateye1"`
    - `EyelashesLookTemplate.cateye2` or `"cateye2"`
    - `EyelashesLookTemplate.cateye3` or `"cateye3"`
    - `EyelashesLookTemplate.cateye4` or `"cateye4"`
    - `EyelashesLookTemplate.cateye5` or `"cateye5"`
    - `EyelashesLookTemplate.dense1` or `"dense1"`
    - `EyelashesLookTemplate.dense2` or `"dense2"`
    - `EyelashesLookTemplate.dense3` or `"dense3"`
    - `EyelashesLookTemplate.dense4` or `"dense4"`
    - `EyelashesLookTemplate.dense5` or `"dense5"`
    - `EyelashesLookTemplate.dense6` or `"dense6"`
    - `EyelashesLookTemplate.white1` or `"white1"`
    - `EyelashesLookTemplate.white2` or `"white2"`
    - `EyelashesLookTemplate.goth` or `"goth"`
    - `EyelashesLookTemplate.kardashian` or `"kardashian"`
    - `EyelashesLookTemplate.long` or `"long"`
    - `EyelashesLookTemplate.normal1` or `"normal1"`
    - `EyelashesLookTemplate.normal2` or `"normal2"`
    - `EyelashesLookTemplate.normal3` or `"normal3"`
    - `EyelashesLookTemplate.normal4` or `"normal4"`
    - `EyelashesLookTemplate.stringPink` or `"stringPink"`
    - `EyelashesLookTemplate.subtle1` or `"subtle1"`
    - `EyelashesLookTemplate.subtle2` or `"subtle2"`
    - `EyelashesLookTemplate.subtle3` or `"subtle3"`
    - `EyelashesLookTemplate.subtle4` or `"subtle4"`
    - `EyelashesLookTemplate.subtle5` or `"subtle5"`
## `lipMakeup.lipstick.enable`
- Type: boolean
- Default value: `False`
## `lipMakeup.lipstick.shade`
- Type: texture
- Default value: matteDarkRed
- Templates: 
    - `LipstickShadeTemplate.matteDarkRed` or `"matteDarkRed"`
    - `LipstickShadeTemplate.mattePoppy` or `"mattePoppy"`
    - `LipstickShadeTemplate.matteNude` or `"matteNude"`
    - `LipstickShadeTemplate.mattePeach` or `"mattePeach"`
    - `LipstickShadeTemplate.mattePink` or `"mattePink"`
    - `LipstickShadeTemplate.matteRedViolet` or `"matteRedViolet"`
    - `LipstickShadeTemplate.matteRed` or `"matteRed"`
    - `LipstickShadeTemplate.matteViolet` or `"matteViolet"`
    - `LipstickShadeTemplate.caramel` or `"caramel"`
    - `LipstickShadeTemplate.butterscotchKiss` or `"butterscotchKiss"`
    - `LipstickShadeTemplate.pinkThrill` or `"pinkThrill"`
    - `LipstickShadeTemplate.golden` or `"golden"`
    - `LipstickShadeTemplate.softPink` or `"softPink"`
    - `LipstickShadeTemplate.sunTouched` or `"sunTouched"`
    - `LipstickShadeTemplate.redLust` or `"redLust"`
    - `LipstickShadeTemplate.napkinNoteRed` or `"napkinNoteRed"`
    - `LipstickShadeTemplate.cinnamonSwirl` or `"cinnamonSwirl"`
    - `LipstickShadeTemplate.midnightPlum` or `"midnightPlum"`
    - `LipstickShadeTemplate.angelicRosebud` or `"angelicRosebud"`
    - `LipstickShadeTemplate.blushingBallerina` or `"blushingBallerina"`
    - `LipstickShadeTemplate.smokeyMoonlight` or `"smokeyMoonlight"`
    - `LipstickShadeTemplate.goldenSun` or `"goldenSun"`
    - `LipstickShadeTemplate.criminallyCoral` or `"criminallyCoral"`
    - `LipstickShadeTemplate.flameGame` or `"flameGame"`
    - `LipstickShadeTemplate.nudeScandal` or `"nudeScandal"`
    - `LipstickShadeTemplate.cherryCharm` or `"cherryCharm"`
    - `LipstickShadeTemplate.rosePetalBlush` or `"rosePetalBlush"`
    - `LipstickShadeTemplate.fierySunburst` or `"fierySunburst"`
    - `LipstickShadeTemplate.sunshineSorbet` or `"sunshineSorbet"`
    - `LipstickShadeTemplate.sunlitPlumSparkle` or `"sunlitPlumSparkle"`
    - `LipstickShadeTemplate.neon` or `"neon"`
    - `LipstickShadeTemplate.cottonCandyKiss` or `"cottonCandyKiss"`
    - `LipstickShadeTemplate.rubyRedRouge` or `"rubyRedRouge"`
    - `LipstickShadeTemplate.softSnowflake` or `"softSnowflake"`
## `lipMakeup.lipstick.amount`
- Type: number
- Default value: `100`
- Valid range: `[0, 100]`
## `lipMakeup.lipGloss.enable`
- Type: boolean
- Default value: `False`
## `lipMakeup.lipGloss.gloss`
- Type: texture
- Default value: basic
- Templates: 
    - `LipGlossGlossTemplate.basic` or `"basic"`
    - `LipGlossGlossTemplate.cristalFrost` or `"cristalFrost"`
    - `LipGlossGlossTemplate.auroraBorealis` or `"auroraBorealis"`
    - `LipGlossGlossTemplate.goldenHourglass` or `"goldenHourglass"`
    - `LipGlossGlossTemplate.celestialSpectrum` or `"celestialSpectrum"`
    - `LipGlossGlossTemplate.starlightMirage` or `"starlightMirage"`
    - `LipGlossGlossTemplate.pinkDiamondSparkle` or `"pinkDiamondSparkle"`
    - `LipGlossGlossTemplate.sunshine` or `"sunshine"`
    - `LipGlossGlossTemplate.sunburn` or `"sunburn"`
    - `LipGlossGlossTemplate.dusk` or `"dusk"`
    - `LipGlossGlossTemplate.moonlight` or `"moonlight"`
    - `LipGlossGlossTemplate.poisonApple` or `"poisonApple"`
    - `LipGlossGlossTemplate.oceanDeep` or `"oceanDeep"`
    - `LipGlossGlossTemplate.ivoryDust` or `"ivoryDust"`
    - `LipGlossGlossTemplate.vampireVelvet` or `"vampireVelvet"`
## `lipMakeup.lipGloss.amount`
- Type: number
- Default value: `80`
- Valid range: `[0, 100]`
## `eyeEnhancements.eyeColor.enable`
- Type: boolean
- Default value: `False`
## `eyeEnhancements.eyeColor.color`
- Type: RGBA Color
- Default value: blue `(r: 61, g: 123, b: 131, a: 50)`
- Templates: 
    - `EyeColorColorTemplate.blue` or `"blue"`. Value: `(r: 61, g: 123, b: 131, a: 50)`
    - `EyeColorColorTemplate.pink` or `"pink"`. Value: `(r: 189, g: 102, b: 184, a: 80)`
    - `EyeColorColorTemplate.purple` or `"purple"`. Value: `(r: 185, g: 85, b: 213, a: 80)`
    - `EyeColorColorTemplate.green` or `"green"`. Value: `(r: 52, g: 163, b: 54, a: 25)`
    - `EyeColorColorTemplate.yellow` or `"yellow"`. Value: `(r: 232, g: 240, b: 72, a: 25)`
## `colorFilters.filter`
- Type: texture
- Default value: noFilter
- Templates: 
    - `ColorFiltersFilterTemplate.noFilter` or `"noFilter"`
    - `ColorFiltersFilterTemplate.filmContrast` or `"filmContrast"`
    - `ColorFiltersFilterTemplate.backAndWhite` or `"backAndWhite"`
    - `ColorFiltersFilterTemplate.fall` or `"fall"`
    - `ColorFiltersFilterTemplate.cobaltPink` or `"cobaltPink"`
    - `ColorFiltersFilterTemplate.crispCold` or `"crispCold"`
    - `ColorFiltersFilterTemplate.burntWhites` or `"burntWhites"`
    - `ColorFiltersFilterTemplate.crispWarm` or `"crispWarm"`
    - `ColorFiltersFilterTemplate.fujiFilm1` or `"fujiFilm1"`
    - `ColorFiltersFilterTemplate.fujiFilm2` or `"fujiFilm2"`
    - `ColorFiltersFilterTemplate.fujiFilm3` or `"fujiFilm3"`
    - `ColorFiltersFilterTemplate.fujiFilm4` or `"fujiFilm4"`
    - `ColorFiltersFilterTemplate.fujiFilm5` or `"fujiFilm5"`
    - `ColorFiltersFilterTemplate.greenTea` or `"greenTea"`
    - `ColorFiltersFilterTemplate.kodak1` or `"kodak1"`
    - `ColorFiltersFilterTemplate.kodak2` or `"kodak2"`
    - `ColorFiltersFilterTemplate.kodak3` or `"kodak3"`
    - `ColorFiltersFilterTemplate.lowSaturation` or `"lowSaturation"`
    - `ColorFiltersFilterTemplate.nashville` or `"nashville"`
    - `ColorFiltersFilterTemplate.negativeBlue` or `"negativeBlue"`
    - `ColorFiltersFilterTemplate.negative` or `"negative"`
    - `ColorFiltersFilterTemplate.nightFromDay` or `"nightFromDay"`
    - `ColorFiltersFilterTemplate.paleSkin` or `"paleSkin"`
    - `ColorFiltersFilterTemplate.pastelTones` or `"pastelTones"`
    - `ColorFiltersFilterTemplate.redSkin` or `"redSkin"`
    - `ColorFiltersFilterTemplate.sepiaAmber` or `"sepiaAmber"`
    - `ColorFiltersFilterTemplate.sepiaBlue` or `"sepiaBlue"`
    - `ColorFiltersFilterTemplate.sepiaCandles` or `"sepiaCandles"`
    - `ColorFiltersFilterTemplate.sepiaCrimson` or `"sepiaCrimson"`
    - `ColorFiltersFilterTemplate.sepiaGold` or `"sepiaGold"`
    - `ColorFiltersFilterTemplate.sepiaSunset` or `"sepiaSunset"`
    - `ColorFiltersFilterTemplate.sepiaTurquoise` or `"sepiaTurquoise"`
    - `ColorFiltersFilterTemplate.smokey` or `"smokey"`
    - `ColorFiltersFilterTemplate.softGold` or `"softGold"`
    - `ColorFiltersFilterTemplate.warmSoft` or `"warmSoft"`
## `colorFilters.intensity`
- Type: number
- Default value: `100`
- Valid range: `[0, 100]`
## `background.blur.enable`
- Type: boolean
- Default value: `False`
## `background.blur.intensity`
- Type: number
- Default value: `35`
- Valid range: `[1, 100]`
## `background.image.enable`
- Type: boolean
- Default value: `False`
## `background.image.background`
- Type: texture
- Default value: sunnyBeach
- Templates: 
    - `ImageBackgroundTemplate.sunnyBeach` or `"sunnyBeach"`
    - `ImageBackgroundTemplate.homeOffice` or `"homeOffice"`
    - `ImageBackgroundTemplate.footballStadium` or `"footballStadium"`
