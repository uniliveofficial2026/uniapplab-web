export const requestPipWindow = async (width: number, height: number) => {
  if (!('documentPictureInPicture' in window)) {
    throw new Error('Document Picture-in-Picture API is not supported in this browser.');
  }

  // @ts-ignore
  const pipWindow = await window.documentPictureInPicture.requestWindow({
    width,
    height,
  });

  // Copy stylesheets
  [...document.styleSheets].forEach((styleSheet) => {
    try {
      const cssRules = [...styleSheet.cssRules].map((rule) => rule.cssText).join('');
      const style = document.createElement('style');
      style.textContent = cssRules;
      pipWindow.document.head.appendChild(style);
    } catch (e) {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.type = styleSheet.type;
      link.media = styleSheet.media.mediaText;
      link.href = styleSheet.href;
      pipWindow.document.head.appendChild(link);
    }
  });
  
  // Set dark mode class if applicable
  pipWindow.document.body.className = document.body.className;
  pipWindow.document.body.style.margin = "0";
  pipWindow.document.body.style.padding = "0";
  pipWindow.document.body.style.overflow = "hidden";
  pipWindow.document.body.style.height = "100dvh";
  pipWindow.document.body.style.width = "100vw";

  return pipWindow;
};
