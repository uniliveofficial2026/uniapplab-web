import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  X, CheckSquare, FileSpreadsheet, Play, CheckCircle2, LogOut, User, 
  Sparkles, FileText, Database, Video, ChevronRight, RefreshCw, Send, Star
} from 'lucide-react';
import { 
  googleSignIn, logoutUser, syncUserToFirestore, getPlayerBalance, 
  createGoogleSheetLedger, addGoogleTaskMilestone, createGoogleMeetSpace, 
  createFeedbackGoogleForm, createVipStatusGoogleSlide, auth
} from '../lib/firebase';
import { User as FirebaseUser } from 'firebase/auth';

interface CloudSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  isDarkMode: boolean;
  localBalance: number;
  onBalanceSynced: (newBalance: number) => void;
}

export function CloudSyncModal({ isOpen, onClose, isDarkMode, localBalance, onBalanceSynced }: CloudSyncModalProps) {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [actionResult, setActionResult] = useState<{ type: 'success' | 'error'; message: string; url?: string } | null>(null);
  const [firestoreBalance, setFirestoreBalance] = useState<number | null>(null);

  // Sync auth state on mount
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (user) => {
      setCurrentUser(user);
      if (user) {
        try {
          const bal = await getPlayerBalance(user.uid);
          setFirestoreBalance(bal);
        } catch (e) {
          console.error(e);
        }
      } else {
        setAccessToken(null);
        setFirestoreBalance(null);
      }
    });
    return unsubscribe;
  }, []);

  const handleSignIn = async () => {
    setIsConnecting(true);
    setActionResult(null);
    try {
      // Direct signIn with token popup
      const result = await googleSignIn();
      if (result) {
        setCurrentUser(result.user);
        setAccessToken(result.accessToken);
        setFirestoreBalance(result.user.uid ? await getPlayerBalance(result.user.uid) : null);
        setActionResult({
          type: 'success',
          message: `Successfully connected Google Account: ${result.user.displayName || result.user.email}`
        });
      }
    } catch (err: any) {
      const isPopupClosed = err?.code === 'auth/popup-closed-by-user' || 
                            String(err?.message || '').includes('popup-closed-by-user') ||
                            String(err || '').includes('popup-closed-by-user');
      setActionResult({
        type: 'error',
        message: isPopupClosed 
          ? 'Sign-in cancelled: The login popup was closed. Please try again when you are ready to connect!'
          : (err.message || 'OAuth Connection cancelled or failed.')
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const handleLogout = async () => {
    setActionLoading('logout');
    try {
      await logoutUser();
      setCurrentUser(null);
      setAccessToken(null);
      setFirestoreBalance(null);
      setActionResult({
        type: 'success',
        message: 'Account successfully disconnected.'
      });
    } catch (e) {
      console.error(e);
    } finally {
      setActionLoading(null);
    }
  };

  // Sync Local Coin Balances with Cloud Database (Firestore)
  const handlePushSync = async () => {
    if (!currentUser) return;
    setActionLoading('sync');
    try {
      await syncUserToFirestore(currentUser, localBalance);
      setFirestoreBalance(localBalance);
      setActionResult({
        type: 'success',
        message: `Firestore Database updated successfully! Current synced balance: ${localBalance.toLocaleString()} coins.`
      });
    } catch (err: any) {
      setActionResult({
        type: 'error',
        message: 'Cloud Sync Failed. Check security rules or credentials.'
      });
    } finally {
      setActionLoading(null);
    }
  };

  const handlePullSync = async () => {
    if (!currentUser) return;
    setActionLoading('PullSync');
    try {
      const bal = await getPlayerBalance(currentUser.uid);
      setFirestoreBalance(bal);
      onBalanceSynced(bal);
      setActionResult({
        type: 'success',
        message: `Profile loaded! Restored ${bal.toLocaleString()} coins from Cloud Storage.`
      });
    } catch (err) {
      setActionResult({
        type: 'error',
        message: 'Failed to restore coin state from Cloud.'
      });
    } finally {
      setActionLoading(null);
    }
  };

  // Google Tasks Quest export
  const exportWeeklyQuestToTasks = async () => {
    if (!accessToken) {
      setActionResult({ type: 'error', message: 'Please re-authenticate to refresh your Workspace credentials.' });
      return;
    }
    setActionLoading('tasks');
    setActionResult(null);
    try {
      await addGoogleTaskMilestone(
        accessToken, 
        "🎰 Win 1,000,000 Coins in Food Slot Wheel!", 
        "Complete the multiplier jackpot challenge in Greedy Casino. Reward: Extra VIP Level badge!"
      );
      setActionResult({
        type: 'success',
        message: 'Daily Quest successfully inserted into Google Tasks list!'
      });
    } catch (err: any) {
      setActionResult({ type: 'error', message: 'Failed to insert task. Ensure scopes are authorized.' });
    } finally {
      setActionLoading(null);
    }
  };

  // Google Sheets spreadsheet Ledger export
  const exportLedgerToSheets = async () => {
    if (!accessToken) {
      setActionResult({ type: 'error', message: 'Please re-authenticate to refresh your Workspace credentials.' });
      return;
    }
    setActionLoading('sheets');
    setActionResult(null);
    try {
      const tempMockTxs = [
        { createdAt: new Date().toISOString(), senderName: 'P2P Store', receiverName: currentUser?.displayName || 'User', amount: 5000000, type: 'MINT' },
        { createdAt: new Date(Date.now() - 3600000).toISOString(), senderName: currentUser?.displayName || 'User', receiverName: 'Casino Slot', amount: 50000, type: 'BET_SPIN' },
        { createdAt: new Date(Date.now() - 7200000).toISOString(), senderName: 'Casino Jackpots', receiverName: currentUser?.displayName || 'User', amount: 250000, type: 'WIN_PAYOUT' }
      ];
      const sheetUrl = await createGoogleSheetLedger(accessToken, tempMockTxs);
      setActionResult({
        type: 'success',
        message: 'Accounting Ledger Spreadsheet generated!',
        url: sheetUrl
      });
    } catch (err: any) {
      setActionResult({ type: 'error', message: 'Sheets export failed. Please try again.' });
    } finally {
      setActionLoading(null);
    }
  };

  // Google Meet space creation
  const launchDeveloperMeet = async () => {
    if (!accessToken) {
      setActionResult({ type: 'error', message: 'Please re-authenticate to refresh your Workspace credentials.' });
      return;
    }
    setActionLoading('meet');
    setActionResult(null);
    try {
      const meetUrl = await createGoogleMeetSpace(accessToken);
      setActionResult({
        type: 'success',
        message: '1-Click Google Meet space successfully created!',
        url: meetUrl
      });
    } catch (err: any) {
      setActionResult({ type: 'error', message: 'Meet Space creation blocked.' });
    } finally {
      setActionLoading(null);
    }
  };

  // Google Forms feedback generator
  const openFeedbackForm = async () => {
    if (!accessToken) {
      setActionResult({ type: 'error', message: 'Please re-authenticate to refresh your Workspace credentials.' });
      return;
    }
    setActionLoading('forms');
    setActionResult(null);
    try {
      const formUrl = await createFeedbackGoogleForm(accessToken, currentUser?.email || 'test@example.com');
      setActionResult({
        type: 'success',
        message: 'User feedback and diagnostics Google Form setup completed!',
        url: formUrl
      });
    } catch (err: any) {
      setActionResult({ type: 'error', message: 'Forms builder failed.' });
    } finally {
      setActionLoading(null);
    }
  };

  // Google Slides credential creator
  const createVipCertificate = async () => {
    if (!accessToken) {
      setActionResult({ type: 'error', message: 'Please re-authenticate to refresh your Workspace credentials.' });
      return;
    }
    setActionLoading('slides');
    setActionResult(null);
    try {
      const slideUrl = await createVipStatusGoogleSlide(accessToken, currentUser?.displayName || 'Lucky Player', localBalance);
      setActionResult({
        type: 'success',
        message: 'VIP Status Slideshow successfully deployed!',
        url: slideUrl
      });
    } catch (err: any) {
      setActionResult({ type: 'error', message: 'Failed creating VIP Slide.' });
    } finally {
      setActionLoading(null);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[320] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/65 backdrop-blur-sm" onClick={onClose} />

      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className={`relative w-full max-w-2xl h-[90vh] md:h-auto md:max-h-[85vh] rounded-2xl flex flex-col shadow-2xl overflow-hidden border ${isDarkMode ? 'bg-gray-950 border-sky-500/15 text-white' : 'bg-white border-gray-100 text-gray-900'}`}
      >
        {/* Header */}
        <div className={`p-4 border-b flex justify-between items-center shrink-0 ${isDarkMode ? 'border-gray-800' : 'border-gray-100'}`}>
          <h3 className="font-extrabold text-lg flex items-center gap-2 text-sky-500">
            <Sparkles size={20} className="animate-pulse" /> Google Cloud Integration
          </h3>
          <button 
            type="button" 
            onClick={onClose}
            className={`p-1.5 rounded-lg transition-colors ${isDarkMode ? 'hover:bg-gray-800 text-gray-400' : 'hover:bg-gray-100 text-gray-500'}`}
          >
            <X size={18} />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Setup / Auth State */}
          {!currentUser ? (
            <div className={`p-6 rounded-2xl border text-center ${isDarkMode ? 'bg-gray-900/40 border-gray-800' : 'bg-gray-50 border-gray-200'}`}>
              <Database className="w-12 h-12 text-blue-500 mx-auto mb-3 animate-bounce" />
              <h4 className="font-bold text-base mb-1">Unify Your Casino Experience</h4>
              <p className="text-xs opacity-65 max-w-md mx-auto mb-5 leading-relaxed">
                Connect your Google account using secure Firebase Authentication to persist your high-scores, join real-time leaderboards, and orchestrate automated exports to Google Workspace.
              </p>
              
              <button
                type="button"
                onClick={handleSignIn}
                disabled={isConnecting}
                className="mx-auto flex items-center justify-center gap-3 bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 px-5 rounded-xl shadow-lg shadow-blue-500/20 active:scale-95 transition-all text-sm cursor-pointer"
              >
                {isConnecting ? (
                  <RefreshCw className="w-5 h-5 animate-spin" />
                ) : (
                  <svg className="w-4 h-4 fill-white" viewBox="0 0 48 48">
                    <path d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                    <path d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                    <path d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                    <path d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                  </svg>
                )}
                <span>Connect with Google ID</span>
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {/* User Identity Banner */}
              <div className={`p-4 rounded-xl border flex flex-col sm:flex-row items-center justify-between gap-4 ${isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-gray-50 border-gray-200'}`}>
                <div className="flex items-center gap-3">
                  <img 
                    src={currentUser.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${currentUser.uid}`} 
                    alt="avatar" 
                    referrerPolicy="no-referrer"
                    className="w-12 h-12 rounded-full ring-2 ring-sky-500 shrink-0" 
                  />
                  <div>
                    <h5 className="font-extrabold text-sm flex items-center gap-1.5">
                      {currentUser.displayName} <span className="bg-sky-500/15 text-sky-500 text-[9px] px-2 py-0.5 rounded-full uppercase">Google verified</span>
                    </h5>
                    <p className="text-xs opacity-60 truncate max-w-xs">{currentUser.email}</p>
                    <p className="text-[10px] font-mono opacity-40">ID: {currentUser.uid}</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleLogout}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-red-500 border border-red-500/20 hover:bg-red-500/10 rounded-lg transition-colors cursor-pointer self-stretch sm:self-center justify-center font-bold"
                >
                  <LogOut size={13} /> Disconnect
                </button>
              </div>

              {/* FireStore persistence metrics */}
              <div className={`p-4 rounded-xl border space-y-3 ${isDarkMode ? 'bg-blue-950/20 border-blue-950/40 text-blue-100' : 'bg-blue-50 border-blue-100 text-blue-900'}`}>
                <div className="flex items-center gap-2">
                  <Database size={16} className="text-blue-500 shrink-0" />
                  <span className="font-extrabold text-xs">Real-Time Cloud Save State</span>
                </div>
                <div className="grid grid-cols-2 gap-3 text-center sm:text-left">
                  <div>
                    <div className="text-[10px] opacity-60 uppercase font-mono tracking-wider">Local Coins (This Device)</div>
                    <div className="text-sm font-black text-yellow-500 mt-0.5">{localBalance.toLocaleString()} 💰</div>
                  </div>
                  <div>
                    <div className="text-[10px] opacity-60 uppercase font-mono tracking-wider">Cloud Ledger Balance</div>
                    <div className="text-sm font-black text-green-500 mt-0.5">
                      {firestoreBalance === null ? 'Loading...' : `${firestoreBalance.toLocaleString()} 💰`}
                    </div>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-2 pt-2 border-t border-blue-500/10">
                  <button
                    type="button"
                    onClick={handlePushSync}
                    disabled={actionLoading === 'sync'}
                    className="flex-1 bg-sky-600 hover:bg-sky-700 disabled:opacity-50 text-white font-bold py-1.5 rounded-lg text-xs flex items-center justify-center gap-1.5 shadow"
                  >
                    {actionLoading === 'sync' ? <RefreshCw size={12} className="animate-spin" /> : <RefreshCw size={12} />}
                    Sync Local to Cloud
                  </button>
                  <button
                    type="button"
                    onClick={handlePullSync}
                    disabled={actionLoading === 'PullSync'}
                    className="flex-1 border border-blue-500/20 hover:bg-blue-500/10 font-bold text-xs py-1.5 rounded-lg flex items-center justify-center gap-1.5"
                  >
                    {actionLoading === 'PullSync' ? <RefreshCw size={12} className="animate-spin" /> : <RefreshCw size={12} />}
                    Restore from Cloud Save
                  </button>
                </div>
              </div>

              {/* Google Workspace integrations hub */}
              <div>
                <h5 className="font-extrabold text-xs mb-3 uppercase tracking-wider flex items-center gap-1.5 opacity-65">
                  <Sparkles size={14} className="text-yellow-500" /> Automated Google Workspace Pipelines
                </h5>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Google Tasks */}
                  <button
                    type="button"
                    onClick={exportWeeklyQuestToTasks}
                    disabled={!!actionLoading}
                    className={`p-3.5 rounded-xl border text-left flex gap-3 transition-colors ${isDarkMode ? 'bg-gray-900 border-gray-800 hover:bg-gray-850' : 'bg-gray-50 border-gray-200 hover:bg-gray-100'}`}
                  >
                    <div className="p-2 h-max rounded-lg bg-blue-500/10 text-blue-500 shrink-0">
                      <CheckSquare size={16} />
                    </div>
                    <div>
                      <h6 className="font-bold text-xs">Add Quest to Tasks</h6>
                      <p className="text-[10px] opacity-60 leading-normal mt-1">
                        Insert casino milestone quests to your Google Daily Tasks.
                      </p>
                    </div>
                  </button>

                  {/* Google Sheets */}
                  <button
                    type="button"
                    onClick={exportLedgerToSheets}
                    disabled={!!actionLoading}
                    className={`p-3.5 rounded-xl border text-left flex gap-3 transition-colors ${isDarkMode ? 'bg-gray-900 border-gray-800 hover:bg-gray-850' : 'bg-gray-50 border-gray-200 hover:bg-gray-100'}`}
                  >
                    <div className="p-2 h-max rounded-lg bg-emerald-500/10 text-emerald-500 shrink-0">
                      <FileSpreadsheet size={16} />
                    </div>
                    <div>
                      <h6 className="font-bold text-xs">Spreadsheet Coin Ledger</h6>
                      <p className="text-[10px] opacity-60 leading-normal mt-1">
                        Export your bets and transfers history directly onto a beautiful Google Sheets.
                      </p>
                    </div>
                  </button>

                  {/* Google Slides */}
                  <button
                    type="button"
                    onClick={createVipCertificate}
                    disabled={!!actionLoading}
                    className={`p-3.5 rounded-xl border text-left flex gap-3 transition-colors ${isDarkMode ? 'bg-gray-900 border-gray-800 hover:bg-gray-850' : 'bg-gray-50 border-gray-200 hover:bg-gray-100'}`}
                  >
                    <div className="p-2 h-max rounded-lg bg-amber-500/10 text-amber-500 shrink-0">
                      <FileText size={16} />
                    </div>
                    <div>
                      <h6 className="font-bold text-xs">Google Slides VIP Report</h6>
                      <p className="text-[10px] opacity-60 leading-normal mt-1">
                        Deploy a customized status presentation tracking achievements.
                      </p>
                    </div>
                  </button>

                  {/* Google Meet */}
                  <button
                    type="button"
                    onClick={launchDeveloperMeet}
                    disabled={!!actionLoading}
                    className={`p-3.5 rounded-xl border text-left flex gap-3 transition-colors ${isDarkMode ? 'bg-gray-900 border-gray-800 hover:bg-gray-850' : 'bg-gray-50 border-gray-200 hover:bg-gray-100'}`}
                  >
                    <div className="p-2 h-max rounded-lg bg-teal-500/10 text-teal-500 shrink-0">
                      <Video size={16} />
                    </div>
                    <div>
                      <h6 className="font-bold text-xs">1-Click Google Meet space</h6>
                      <p className="text-[10px] opacity-60 leading-normal mt-1">
                        Create standard workspace meeting spaces to talk coins face-to-face.
                      </p>
                    </div>
                  </button>

                  {/* Google Forms */}
                  <button
                    type="button"
                    onClick={openFeedbackForm}
                    disabled={!!actionLoading}
                    className={`p-3.5 rounded-xl border text-left flex gap-3 sm:col-span-2 transition-colors ${isDarkMode ? 'bg-gray-900 border-gray-800 hover:bg-gray-850' : 'bg-gray-50 border-gray-200 hover:bg-gray-100'}`}
                  >
                    <div className="p-2 h-max rounded-lg bg-purple-500/10 text-purple-500 shrink-0">
                      <FileText size={16} />
                    </div>
                    <div>
                      <h6 className="font-bold text-xs">Diagnostic Feedback Google Form</h6>
                      <p className="text-[10px] opacity-60 leading-normal mt-1">
                        Generate and submit an authorized feedback form connected to this app instance.
                      </p>
                    </div>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Results/Feedback area */}
          {actionResult && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`p-4 rounded-xl text-xs space-y-2 border ${
                actionResult.type === 'success' 
                  ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-500' 
                  : 'bg-red-500/10 border-red-500/20 text-red-500'
              }`}
            >
              <div className="flex items-center gap-2 font-bold">
                <CheckCircle2 size={14} className="shrink-0" />
                <span>{actionResult.message}</span>
              </div>
              {actionResult.url && (
                <a
                  href={actionResult.url}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 bg-emerald-500 hover:bg-emerald-600 font-bold font-mono uppercase text-[10px] text-white px-3 py-1.5 rounded-lg shadow-sm transition-all cursor-pointer"
                >
                  Launch Workspace Stream <ChevronRight size={11} />
                </a>
              )}
            </motion.div>
          )}
        </div>

        {/* Footer */}
        <div className={`p-4 border-t flex justify-between items-center text-[10px] opacity-50 shrink-0 ${isDarkMode ? 'border-gray-800' : 'border-gray-100'}`}>
          <span>Connected Google Cloud project database</span>
          <span className="font-mono">gen-lang-client-0745225976</span>
        </div>
      </motion.div>
    </div>
  );
}
