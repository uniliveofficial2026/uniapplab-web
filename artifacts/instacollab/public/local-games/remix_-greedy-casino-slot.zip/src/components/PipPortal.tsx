import React, { useEffect, useState, ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { requestPipWindow } from '../utils/pip';
import { X } from 'lucide-react';
import { motion } from 'motion/react';

interface PipWindowProps {
  children: ReactNode;
  active: boolean;
  onClose: () => void;
  width?: number;
  height?: number;
}

export const PipPortal: React.FC<PipWindowProps> = ({ children, active, onClose, width = 400, height = 600 }) => {
  const [pipWin, setPipWin] = useState<Window | null>(null);
  const [isNativeSupported, setIsNativeSupported] = useState(true);
  
  useEffect(() => {
    let windowInstance: Window | null = null;
    if (active) {
      if (!('documentPictureInPicture' in window)) {
         setIsNativeSupported(false);
         return;
      }
      
      requestPipWindow(width, height)
        .then(win => {
           windowInstance = win;
           setPipWin(win);
           win.addEventListener('pagehide', () => {
             onClose();
           });
        })
        .catch(err => {
           console.error("Failed to open PIP window", err);
           setIsNativeSupported(false);
        });
    } else {
      if (pipWin) {
         pipWin.close();
      }
    }
    
    return () => {
      if (windowInstance) {
         windowInstance.close();
      }
    };
  }, [active]);

  if (!active) return null;

  if (isNativeSupported && pipWin) {
    return createPortal(children, pipWin.document.body);
  }

  if (!isNativeSupported) {
    // Fallback inner PiP mode (Floating Window)
    return createPortal(
      <motion.div
        drag
        dragMomentum={false}
        className="fixed z-[99999] right-4 bottom-24 shadow-2xl rounded-2xl overflow-hidden border border-gray-400 bg-black flex flex-col"
        style={{ width: `${width}px`, height: `${height}px`, maxWidth: '90vw', maxHeight: '80vh' }}
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.8 }}
      >
        <div className="w-full h-8 bg-gray-800/80 backdrop-blur-sm flex items-center justify-end px-2 cursor-move shrink-0 z-50">
          <button 
            onClick={onClose}
            className="w-6 h-6 rounded-full bg-red-500/20 hover:bg-red-500/40 text-red-100 flex items-center justify-center transition-colors"
          >
            <X size={14} />
          </button>
        </div>
        <div className="w-full flex-1 relative min-h-0" style={{ pointerEvents: 'auto' }}>
          {children}
        </div>
      </motion.div>,
      document.body
    );
  }

  return null;
};
