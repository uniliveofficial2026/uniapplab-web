import React from 'react';

export const ItemIcon = ({ icon, className = "" }: { icon: string, className?: string }) => {
  if (!icon || typeof icon !== 'string') return null;
  const i = icon.trim();
  
  // More robust detection for image paths vs emojis/text
  const isImage = 
    i.startsWith('data:') || 
    i.startsWith('http') || 
    i.startsWith('/') || 
    i.startsWith('./') ||
    i.includes('/') ||
    i.includes('.png') || 
    i.includes('.jpg') || 
    i.includes('.jpeg') || 
    i.includes('.svg') || 
    i.includes('.webp') ||
    i.includes('uploads/');

  if (isImage && i.length > 1) {
    return <img src={i} alt="" className={`object-contain max-w-full max-h-full shrink-0 ${className}`} referrerPolicy="no-referrer" />;
  }
  
  return <span className={className}>{i}</span>;
}
