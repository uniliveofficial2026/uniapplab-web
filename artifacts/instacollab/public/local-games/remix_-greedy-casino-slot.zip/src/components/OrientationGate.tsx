import React, { useState, useEffect } from 'react';
import { Smartphone, RotateCw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const OrientationGate: React.FC = () => {
  const [isLandscapeMobile, setIsLandscapeMobile] = useState(false);

  useEffect(() => {
    const checkOrientation = () => {
      // Specifically target phones by checking max-height in landscape mode
      // Most tablets have a shortest dimension > 600px
      const isPhoneLandscape = window.matchMedia("(max-height: 500px) and (orientation: landscape)").matches;
      setIsLandscapeMobile(isPhoneLandscape);
    };

    checkOrientation();
    window.addEventListener('resize', checkOrientation);
    window.addEventListener('orientationchange', checkOrientation);

    return () => {
      window.removeEventListener('resize', checkOrientation);
      window.removeEventListener('orientationchange', checkOrientation);
    };
  }, []);

  return (
    <AnimatePresence>
      {isLandscapeMobile && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[99999] bg-gray-900 flex flex-col items-center justify-center p-6 text-center"
        >
          <div className="relative mb-8">
            <motion.div
              animate={{ 
                rotate: [0, 90, 90, 0, 0],
              }}
              transition={{ 
                duration: 3,
                repeat: Infinity,
                times: [0, 0.4, 0.6, 0.9, 1]
              }}
              className="p-4 bg-blue-500 rounded-2xl shadow-xl shadow-blue-500/20"
            >
              <Smartphone className="w-12 h-12 text-white" />
            </motion.div>
            <motion.div 
              animate={{ opacity: [0, 1, 0] }}
              transition={{ duration: 3, repeat: Infinity }}
              className="absolute -top-2 -right-2 bg-yellow-400 p-2 rounded-full shadow-lg"
            >
              <RotateCw className="w-4 h-4 text-gray-900" />
            </motion.div>
          </div>

          <motion.h2 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-2xl font-bold text-white mb-2"
          >
            Please Rotate Your Device
          </motion.h2>
          
          <motion.p 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-gray-400 max-w-[280px]"
          >
            This application is optimized for portrait mode. Please turn your phone for the best experience.
          </motion.p>

          <div className="mt-12 flex space-x-2">
            {[0, 1, 2].map((i) => (
              <motion.div
                key={`orientation-gate-dot-${i}`}
                animate={{ scale: [1, 1.5, 1] }}
                transition={{ duration: 1, repeat: Infinity, delay: i * 0.2 }}
                className="w-2 h-2 rounded-full bg-blue-500/50"
              />
            ))}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
