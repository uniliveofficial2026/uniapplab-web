import React from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Trophy,
  X,
  Sparkles,
  Gift,
  CheckCircle2,
  Lock,
  RefreshCw,
  Flame,
  Award,
} from "lucide-react";

interface DailyMissionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  progress: {
    spins: number;
    steakWon: boolean;
    veggieWon: boolean;
    maxProfit: number;
    claimed: string[];
    lastDate: string;
  };
  onClaim: (missionId: string, rewardAmount: number) => void;
  onResetMissions: () => void;
  isDarkMode: boolean;
}

interface MissionDef {
  id: string;
  title: string;
  description: string;
  icon: string;
  targetText: string;
  reward: number;
  type: 'spins' | 'veggie' | 'steak' | 'profit';
  targetValue: number;
}

const MISSIONS: MissionDef[] = [
  {
    id: "mission_spins_2",
    title: "Daily Warmup",
    description: "Participate in 2 game spins with active bets today.",
    icon: "🎯",
    targetText: "2 Spins",
    reward: 500,
    type: "spins",
    targetValue: 2,
  },
  {
    id: "mission_veggie",
    title: "Lucky Green",
    description: "Strike any winning bet on Veggies (Carrot, Corn, Cabbage, Tomato, or Salad).",
    icon: "🥗",
    targetText: "1 Veggie Win",
    reward: 800,
    type: "veggie",
    targetValue: 1,
  },
  {
    id: "mission_steak",
    title: "Steak Connoisseur",
    description: "Land a winning bet of any amount on Steak (🥩, 45x high premium prize)!",
    icon: "🥩",
    targetText: "1 Steak Win",
    reward: 2000,
    type: "steak",
    targetValue: 1,
  },
  {
    id: "mission_profit_5k",
    title: "Feast Master",
    description: "Hit a total win payout of 5,000 Coins or more in a single spin event.",
    icon: "🏆",
    targetText: "5,000 Coins Profit",
    reward: 1500,
    type: "profit",
    targetValue: 5000,
  },
];

export const DailyMissionsModal: React.FC<DailyMissionsModalProps> = ({
  isOpen,
  onClose,
  progress,
  onClaim,
  onResetMissions,
  isDarkMode,
}) => {
  if (!isOpen) return null;

  // Compute status details
  const getMissionProgress = (mission: MissionDef) => {
    switch (mission.type) {
      case "spins":
        return {
          current: progress.spins,
          percent: Math.min(100, Math.round((progress.spins / mission.targetValue) * 100)),
          isComplete: progress.spins >= mission.targetValue,
          display: `${progress.spins} / ${mission.targetValue}`,
        };
      case "veggie": {
        const val = progress.veggieWon ? 1 : 0;
        return {
          current: val,
          percent: val ? 100 : 0,
          isComplete: progress.veggieWon,
          display: `${val} / ${mission.targetValue}`,
        };
      }
      case "steak": {
        const val = progress.steakWon ? 1 : 0;
        return {
          current: val,
          percent: val ? 100 : 0,
          isComplete: progress.steakWon,
          display: `${val} / ${mission.targetValue}`,
        };
      }
      case "profit":
        return {
          current: progress.maxProfit,
          percent: Math.min(100, Math.round((progress.maxProfit / mission.targetValue) * 100)),
          isComplete: progress.maxProfit >= mission.targetValue,
          display: `${progress.maxProfit.toLocaleString()} / ${mission.targetValue.toLocaleString()}`,
        };
      default:
        return { current: 0, percent: 0, isComplete: false, display: "0/0" };
    }
  };

  const totalMissions = MISSIONS.length;
  const completedCount = MISSIONS.filter((m) => getMissionProgress(m).isComplete).length;
  const claimedCount = MISSIONS.filter((m) => progress.claimed.includes(m.id)).length;

  return (
    <div className="fixed inset-0 z-[250] flex items-center justify-center p-4">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/70 backdrop-blur-md cursor-pointer"
      />

      {/* Modal Container */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ type: "spring", duration: 0.4 }}
        className={`relative w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl border flex flex-col max-h-[90vh] ${
          isDarkMode
            ? "bg-gray-900 border-gray-800 text-white shadow-black/60"
            : "bg-[#FAF9F6] border-slate-300 text-slate-900 shadow-slate-900/10"
        }`}
      >
        {/* Banner header decoration */}
        <div className="bg-gradient-to-r from-yellow-500/10 via-orange-500/15 to-rose-500/10 p-5 pb-4 border-b dark:border-gray-800 border-slate-200 relative shrink-0">
          <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-500/5 rounded-full blur-2xl pointer-events-none" />
          
          <div className="flex justify-between items-start">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-yellow-400 to-amber-600 flex items-center justify-center shadow-lg shadow-amber-500/20 text-white shrink-0">
                <Trophy size={24} className="animate-pulse" />
              </div>
              <div>
                <h2 className="font-black text-lg tracking-tight uppercase flex items-center gap-1.5 leading-none">
                  Daily Missions <Flame size={16} className="text-orange-500 fill-orange-500" />
                </h2>
                <p className="text-[10px] font-bold uppercase tracking-wider opacity-60 text-amber-500 mt-1">
                  Resets every 24 hours ({progress.lastDate})
                </p>
              </div>
            </div>
            
            <button
              onClick={onClose}
              className={`p-2 rounded-xl transition-colors ${
                isDarkMode ? "bg-gray-800 hover:bg-gray-750 text-gray-400" : "bg-white hover:bg-gray-100 text-gray-500 border"
              }`}
            >
              <X size={16} />
            </button>
          </div>

          {/* Quick Info Meter */}
          <div className="mt-4 flex items-center gap-3 bg-white/50 dark:bg-black/30 p-2.5 rounded-2xl border dark:border-white/5 border-slate-200">
            <div className="flex items-center gap-1 font-black text-xs shrink-0 text-amber-500">
              <Award size={14} />
              <span>{completedCount}/{totalMissions} COMPLETED</span>
            </div>
            <div className="flex-1 bg-gray-200 dark:bg-gray-800 h-2 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-amber-400 to-orange-500 h-full transition-all duration-500"
                style={{ width: `${(completedCount / totalMissions) * 100}%` }}
              />
            </div>
            <span className="text-[10px] font-mono leading-none font-bold opacity-75">
              {claimedCount} CLAIMED
            </span>
          </div>
        </div>

        {/* Missions content body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 shrink-1">
          {MISSIONS.map((m, idx) => {
            const stats = getMissionProgress(m);
            const isClaimed = progress.claimed.includes(m.id);
            const isClickable = stats.isComplete && !isClaimed;

            return (
              <div
                key={`mission_${m.id}_${idx}`}
                className={`p-3.5 rounded-2xl border transition-all ${
                  isClaimed
                    ? isDarkMode
                      ? "bg-gray-800/40 border-gray-800/50 opacity-60"
                      : "bg-gray-100/50 border-gray-200/60 opacity-60"
                    : stats.isComplete
                    ? isDarkMode
                      ? "bg-gradient-to-r from-amber-500/10 via-yellow-500/5 to-transparent border-amber-500/30 shadow-lg shadow-amber-500/5"
                      : "bg-gradient-to-r from-amber-500/5 via-yellow-500/5 to-transparent border-amber-300 shadow-md shadow-amber-500/5"
                    : isDarkMode
                    ? "bg-gray-850/60 border-gray-800 hover:border-gray-700"
                    : "bg-white border-slate-200 hover:border-slate-300"
                }`}
              >
                <div className="flex items-start gap-3.5">
                  {/* Mission Icon */}
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg shadow-inner shrink-0 ${
                      isClaimed
                        ? "bg-gray-300 text-gray-500 dark:bg-gray-800"
                        : stats.isComplete
                        ? "bg-gradient-to-br from-yellow-300 to-amber-500 text-white animate-bounce"
                        : isDarkMode
                        ? "bg-gray-800 text-gray-300 border border-gray-700"
                        : "bg-slate-50 text-gray-700 border"
                    }`}
                  >
                    {isClaimed ? "✓" : m.icon}
                  </div>

                  {/* Mission Description & Progress Block */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <h4
                        className={`text-xs font-extrabold tracking-tight truncate ${
                          isClaimed ? "line-through opacity-50" : ""
                        }`}
                      >
                        {m.title}
                      </h4>
                      <span className="text-[10px] font-mono font-black text-amber-500 tracking-tighter shrink-0">
                        +{m.reward} COINS
                      </span>
                    </div>
                    
                    <p className="text-[10px] font-medium leading-relaxed opacity-65 mt-1">
                      {m.description}
                    </p>

                    {/* Progress indicators wrapper */}
                    <div className="mt-2.5 flex items-center gap-2">
                      <div className="flex-1 bg-gray-200 dark:bg-gray-800/80 h-1.5 rounded-full overflow-hidden">
                        <div
                          className={`h-full transition-all duration-300 ${
                            isClaimed
                              ? "bg-gray-400"
                              : stats.isComplete
                              ? "bg-gradient-to-r from-green-400 to-emerald-500"
                              : "bg-gradient-to-r from-amber-400 to-yellow-500"
                          }`}
                          style={{ width: `${stats.percent}%` }}
                        />
                      </div>
                      <span className="text-[9px] font-mono font-extrabold shrink-0 opacity-80">
                        {stats.display} ({stats.percent}%)
                      </span>
                    </div>
                  </div>
                </div>

                {/* Claiming Actions */}
                <div className="mt-3.5 pt-2.5 border-t dark:border-white/5 border-slate-100 flex items-center justify-between">
                  <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">
                    REWARD: <span className="font-extrabold text-yellow-500">💰 {m.reward} COINS</span>
                  </span>

                  {isClaimed ? (
                    <div className="flex items-center gap-1 text-[10px] font-black uppercase text-emerald-500">
                      <CheckCircle2 size={12} /> Claimed
                    </div>
                  ) : stats.isComplete ? (
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => onClaim(m.id, m.reward)}
                      className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white text-[10px] font-black uppercase px-3 py-1.5 rounded-lg shadow-md shadow-emerald-500/20 tracking-wider flex items-center gap-1"
                    >
                      <Gift size={11} /> Claim Reward
                    </motion.button>
                  ) : (
                    <div className="text-[10px] font-bold uppercase text-slate-400 dark:text-gray-500 flex items-center gap-1 bg-gray-100 dark:bg-gray-800/65 px-2 py-1 rounded-md">
                      <Lock size={10} /> Locked
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer info/Sandbox test actions */}
        <div className="p-4 border-t dark:border-gray-850 border-slate-200 bg-white/30 dark:bg-black/20 shrink-0 text-center flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest text-left">
            Complete active goals daily to secure extra credits.
          </p>

          <button
            type="button"
            onClick={onResetMissions}
            className="text-[9px] font-black text-amber-500 dark:text-amber-400 hover:text-orange-500 uppercase flex items-center gap-1 transition-colors border border-amber-500/20 hover:border-amber-500 bg-amber-500/5 hover:bg-amber-500/10 px-2 py-1 rounded-lg"
            title="Sandbox reset triggers a mock new-day cycle for user playtesting"
          >
            <RefreshCw size={10} className="animate-spin-slow" /> Reset Progress (Demo)
          </button>
        </div>
      </motion.div>
    </div>
  );
};
