import React, { useState } from "react";
import { Shield } from "lucide-react";

interface SecurityShieldProps {
  children: React.ReactNode;
}

export function SecurityShield({ children }: SecurityShieldProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(
    localStorage.getItem('admin_authenticated') === 'true'
  );
  const [password, setPassword] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === "admin123") {
      setIsAuthenticated(true);
      localStorage.setItem('admin_authenticated', 'true');
    } else {
      alert("Invalid password");
    }
  };

  console.log("SecurityShield rendering. isAuthenticated:", isAuthenticated);
  
  if (isAuthenticated) {
    return <>{children}</>;
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100" style={{ backgroundColor: 'red' }}>
      <form onSubmit={handleLogin} className="p-8 bg-white rounded-xl shadow-md">
        <div className="flex items-center gap-3 mb-6">
          <Shield className="w-8 h-8 text-blue-600" />
          <h2 className="text-xl font-bold">Admin Login</h2>
        </div>
        <p>isAuthenticated: {String(isAuthenticated)}</p>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full p-2 mb-4 border rounded"
          placeholder="Enter password"
        />
        <button type="submit" className="w-full p-2 text-white bg-blue-600 rounded">
          Login
        </button>
      </form>
    </div>
  );
}
