import React, { useState, useEffect } from 'react';
import { X, Store, CheckCircle, Clock, ShieldCheck, DollarSign, Users, Search, AlertCircle, TrendingUp, UserCheck, Lock, CreditCard, MessageCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { socket } from '../socket';
import { ChatBox } from './ChatBox';

interface CoinSellerModalProps {
  isOpen: boolean;
  onClose: () => void;
  isDarkMode: boolean;
  initialStage?: 'intro' | 'login' | 'apply' | 'dashboard';
}

export const CoinSellerModal: React.FC<CoinSellerModalProps> = ({ isOpen, onClose, isDarkMode, initialStage = 'intro' }) => {
  const [authStage, setAuthStage] = useState<'intro' | 'login' | 'apply' | 'dashboard'>(() => {
    const saved = localStorage.getItem('seller_auth_stage');
    if (saved && (saved === 'intro' || saved === 'login' || saved === 'apply' || saved === 'dashboard')) {
      return saved as 'intro' | 'login' | 'apply' | 'dashboard';
    }
    return initialStage;
  });

  // Reset stage when modal opens if initialStage changes
  React.useEffect(() => {
    if (isOpen) {
      setAuthStage(initialStage);
      setApplySuccess(false);
      setApplyError('');
      setUsername('');
      setPassword('');
    }
  }, [isOpen, initialStage]);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [applyForm, setApplyForm] = useState({ name: '', email: '', motivation: '', volume: 'Under 10,000 Coins', password: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [applySuccess, setApplySuccess] = useState(false);
  const [applyError, setApplyError] = useState('');
  const [sellerData, setSellerData] = useState<any>(() => {
    const saved = localStorage.getItem('seller_data');
    return saved ? JSON.parse(saved) : null;
  });
  
  // Transfer form state
  const [transferUserId, setTransferUserId] = useState('');
  const [transferAmountType, setTransferAmountType] = useState('custom');
  const [transferCustomAmount, setTransferCustomAmount] = useState('');
  const [allPlayers, setAllPlayers] = useState<any[]>([]);
  const [suggestedPlayers, setSuggestedPlayers] = useState<any[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  
  // Dashboard state
  const [dashboardTransactions, setDashboardTransactions] = useState<any[]>([]);
  const [revenueTimeFilter, setRevenueTimeFilter] = useState<'today' | 'month' | 'year'>('month');
  const [dashboardStock, setDashboardStock] = useState<number>(1000000);
  const [isReloadModalOpen, setIsReloadModalOpen] = useState(false);
  const [reloadAmountSelection, setReloadAmountSelection] = useState<number>(500000);
  const [isReloading, setIsReloading] = useState(false);

  // Chat State
  const [chatMessages, setChatMessages] = useState<any[]>([]);

  useEffect(() => {
    socket.on('initial_state', (state: any) => {
      if (state.chatMessages) {
        setChatMessages(state.chatMessages);
      }
    });

    socket.on('chat_message_received', (newMsg: any) => {
      setChatMessages(prev => {
        if (prev.some(m => m.id === newMsg.id)) return prev;
        return [...prev, newMsg];
      });
    });
    return () => {
      socket.off('initial_state');
      socket.off('chat_message_received');
    };
  }, []);

  const handleSendMessage = (text: string, mediaList: any[]) => {
    if (!sellerData) return;
    const messageObj = {
      id: `sell_msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      sender: sellerData.name,
      senderId: sellerData.id,
      text,
      mediaList: mediaList || [],
      avatar: sellerData.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${sellerData.name}`,
      timestamp: new Date().toLocaleTimeString()
    };
    socket.emit('send_chat_message', messageObj);
  };

  // Interactive Payment System States
  const [payCardNumber, setPayCardNumber] = useState('4222 8888 7777 6666');
  const [payExpiry, setPayExpiry] = useState('08/29');
  const [payCvc, setPayCvc] = useState('345');
  const [payName, setPayName] = useState('COIN SELLER MERCHANT');
  const [cvcFocused, setCvcFocused] = useState(false);
  const [paymentStep, setPaymentStep] = useState<'idle' | 'encrypting' | 'routing' | 'verifying' | 'success'>('idle');
  const [paymentStepText, setPaymentStepText] = useState('');

  const bgColor = isDarkMode ? 'bg-gray-900 border-gray-700 text-white' : 'bg-white border-gray-200 text-gray-900';
  const overlayBgColor = 'bg-black/60 backdrop-blur-sm';
  const inputColor = isDarkMode ? 'bg-gray-800 border-gray-700 text-white focus:ring-green-500' : 'bg-gray-50 border-gray-300 text-gray-900 focus:ring-green-500';

  const fetchDashboardData = async (sellerId: string) => {
    try {
      const res = await fetch(`/api/seller/dashboard?sellerId=${encodeURIComponent(sellerId)}`);
      if (res.ok) {
        const data = await res.json();
        setDashboardTransactions(data.transactions);
        if (typeof data.stock === 'number') {
          setDashboardStock(data.stock);
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchAllPlayers = async () => {
    try {
      const res = await fetch('/api/seller/players');
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.players)) {
          setAllPlayers(data.players);
        }
      }
    } catch (err) {
      console.error("Failed to fetch players", err);
    }
  };

  const handlePlayerInputChange = (val: string) => {
    setTransferUserId(val);
    if (!val.trim()) {
      setSuggestedPlayers([]);
      setShowSuggestions(false);
      return;
    }
    const filtered = allPlayers.filter(p => 
      (p.id && p.id.toLowerCase().includes(val.toLowerCase())) || 
      (p.name && p.name.toLowerCase().includes(val.toLowerCase()))
    );
    setSuggestedPlayers(filtered);
    setShowSuggestions(true);
  };

  useEffect(() => {
    if (authStage === 'dashboard' && sellerData) {
      fetchDashboardData(sellerData.name);
      fetchAllPlayers();
      
      const handleTxUpdate = () => {
        fetchDashboardData(sellerData.name);
        fetchAllPlayers();
      };
      socket.on('transactions_update', handleTxUpdate);
      return () => {
        socket.off('transactions_update', handleTxUpdate);
      };
    }
  }, [authStage, sellerData]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (username && password) {
      setIsSubmitting(true);
      try {
        const playerName = localStorage.getItem('playerName') || 'Guest';
        const res = await fetch('/api/seller/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password, activePlayerName: playerName })
        });
        const data = await res.json();
        if (res.ok && data.success) {
          setSellerData(data.seller);
          setAuthStage('dashboard');
          localStorage.setItem('seller_data', JSON.stringify(data.seller));
          localStorage.setItem('seller_auth_stage', 'dashboard');
        } else {
          alert('Login failed: ' + (data.error || 'Invalid credentials or not approved yet.'));
        }
      } catch (err) {
        alert('Login failed');
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  const handleTransfer = async () => {
    if (!transferUserId) return alert("Please enter User ID");
    let amount = transferAmountType === 'custom' ? parseInt(transferCustomAmount) : parseInt(transferAmountType);
    if (!amount || amount <= 0) return alert("Invalid amount");

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/seller/transfer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sellerId: sellerData.name, targetUserId: transferUserId, amount })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        alert("Transfer successful!");
        setTransferUserId('');
        setTransferCustomAmount('');
        // Refresh dashboard stock immediately on transfer success
        if (sellerData) {
          fetchDashboardData(sellerData.name);
        }
      } else {
        alert("Transfer failed: " + (data.error || 'Unknown error'));
      }
    } catch (err) {
      alert("Transfer exception");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLogout = () => {
    setSellerData(null);
    setAuthStage('intro');
    localStorage.removeItem('seller_data');
    localStorage.removeItem('seller_auth_stage');
  };

  const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

  const handleReloadStock = async (amount: number) => {
    const cleanCard = payCardNumber.replace(/\s+/g, '');
    const cleanName = payName.trim().toUpperCase();
    const cleanExpiry = payExpiry.trim();
    const cleanCvc = payCvc.trim();

    if (
      cleanCard === '4111222233334444' ||
      cleanName === 'SYSTEM ADMINISTRATOR' ||
      cleanExpiry === '00/00' ||
      cleanCvc === '999'
    ) {
      alert("Error: These master administrative credentials are strict-restricted and can ONLY be verified inside the secure System Administrator Panel! They are rejected for public and seller stock reloading operations.");
      return;
    }

    setIsReloading(true);
    
    // Simulate multi-phase secure PCI-DSS authorization protocol
    setPaymentStep('encrypting');
    setPaymentStepText('Encrypting credentials using AES-256 TLS 1.3... (🔒 Fully Secure)');
    await delay(900);

    setPaymentStep('routing');
    setPaymentStepText('Routing tokenized handshake to secure financial vault...');
    await delay(900);

    setPaymentStep('verifying');
    setPaymentStepText('Authorizing peer-to-peer card gateway signature for stock contract...');
    await delay(1000);

    setPaymentStep('success');
    setPaymentStepText('Signature authorized! Crediting wholesale coin stock...');
    await delay(700);

    try {
      const res = await fetch('/api/seller/reload-stock', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sellerId: sellerData.name || sellerData.id, amount })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setDashboardStock(data.stock);
        setPaymentStepText(`Successfully credited ${amount.toLocaleString()} coins to your inventory!`);
        await delay(1200);
        setIsReloadModalOpen(false);
      } else {
        alert("Stock reload failed: " + (data.error || 'Server error'));
      }
    } catch (err) {
      console.error(err);
      alert("Failed to reload stock. Network error.");
    } finally {
      setIsReloading(false);
      setPaymentStep('idle');
      setPaymentStepText('');
    }
  };

  const calculateRevenue = () => {
    const now = new Date();
    let filtered = dashboardTransactions;
    if (revenueTimeFilter === 'today') {
      filtered = dashboardTransactions.filter(t => new Date(t.date).toDateString() === now.toDateString());
    } else if (revenueTimeFilter === 'month') {
      filtered = dashboardTransactions.filter(t => new Date(t.date).getMonth() === now.getMonth() && new Date(t.date).getFullYear() === now.getFullYear());
    } else if (revenueTimeFilter === 'year') {
      filtered = dashboardTransactions.filter(t => new Date(t.date).getFullYear() === now.getFullYear());
    }
    
    // Calculate total coins sold, then convert to USD estimate (assuming $10 per 1000 coins for display)
    const totalCoins = filtered.reduce((acc, t) => acc + t.amount, 0);
    return (totalCoins / 100).toFixed(2);
  };


  const handleApply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (applyForm.name && applyForm.email) {
      setIsSubmitting(true);
      setApplyError('');
      try {
        const playerName = localStorage.getItem('playerName') || 'Guest';
        const playerAvatar = localStorage.getItem('playerAvatar') || undefined;
        const res = await fetch('/api/seller-applications', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...applyForm, username: playerName, avatar: playerAvatar })
        });
        const data = await res.json();
        if (res.ok) {
          setApplySuccess(true);
        } else {
          setApplyError(data.error || 'Failed to submit application. Please check your credentials.');
        }
      } catch (err) {
        console.error("Apply failed", err);
        setApplyError('Network error. Please try again.');
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center p-0 md:p-4">
      <div className={`absolute inset-0 ${overlayBgColor}`} onClick={onClose} />
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 15 }} 
        animate={{ opacity: 1, scale: 1, y: 0 }} 
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className={`relative w-full h-full md:max-w-4xl md:max-h-[85vh] md:rounded-3xl flex flex-col shadow-2xl overflow-hidden border border-green-500/15 ${bgColor}`}
      >
        <div className={`p-4 border-b flex justify-between items-center shrink-0 ${isDarkMode ? 'border-gray-800' : 'border-gray-100'}`}>
          <h3 className="font-extrabold text-lg flex items-center gap-2 text-green-500">
            <Store size={22} /> Coin Seller Hub
          </h3>
          <button onClick={onClose} className={`p-2 rounded-xl transition-colors ${isDarkMode ? 'hover:bg-gray-800' : 'hover:bg-gray-100'}`}>
            <X size={20} />
          </button>
        </div>

        <div className={`flex-1 overflow-y-auto p-4 md:p-6 transition-all duration-300 border-t ${isDarkMode ? 'bg-gradient-to-b from-gray-900 via-gray-950 to-black border-gray-800' : 'bg-gradient-to-b from-[#FAF9F6] to-[#F2EFE8] border-gray-100'}`}>
          <AnimatePresence mode="wait">
            
            {/* Intro Stage */}
            {authStage === 'intro' && (
              <motion.div key="intro" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} className="h-full flex flex-col justify-center max-w-md mx-auto space-y-6">
                <div className="text-center space-y-2">
                  <div className="w-16 h-16 bg-green-500/20 text-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <ShieldCheck size={32} />
                  </div>
                  <h2 className="text-2xl font-black">Authorized Reseller Network</h2>
                  <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                    Join our verified P2P network to sell coins directly to players securely and earn commissions.
                  </p>
                </div>
                
                <div className="space-y-4 pt-4">
                  <button onClick={() => setAuthStage('login')} className="w-full py-3.5 bg-green-500 hover:bg-green-600 shadow-lg shadow-green-500/30 rounded-xl text-white font-bold transition-all active:scale-95 flex items-center justify-center gap-2">
                    <UserCheck size={18} /> Login to Dashboard
                  </button>
                  <button onClick={() => setAuthStage('apply')} className={`w-full py-3.5 border-2 rounded-xl font-bold transition-all active:scale-95 flex items-center justify-center gap-2 ${isDarkMode ? 'border-gray-700 hover:bg-gray-800 text-gray-300' : 'border-gray-200 hover:bg-gray-50 text-gray-600'}`}>
                    Apply for Verification
                  </button>
                </div>
              </motion.div>
            )}

            {/* Login Stage */}
            {authStage === 'login' && (
              <motion.div key="login" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} className="h-full flex flex-col justify-center max-w-sm mx-auto">
                <div className="mb-8">
                  <button onClick={() => setAuthStage('intro')} className={`text-sm mb-4 inline-flex items-center gap-1 ${isDarkMode ? 'text-gray-400 hover:text-white' : 'text-gray-500 hover:text-gray-900'}`}>
                    &larr; Back
                  </button>
                  <h2 className="text-2xl font-black mb-1">Seller Login</h2>
                  <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Enter your credentials to access the panel.</p>
                </div>
                
                <form onSubmit={handleLogin} className="space-y-4">
                  <div>
                    <label className={`block text-xs font-bold mb-1.5 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Seller ID or Email</label>
                    <input 
                      type="text" 
                      required
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className={`w-full px-4 py-3 rounded-xl border focus:outline-none focus:ring-2 transition-all ${inputColor}`}
                      placeholder="e.g. seller_1102"
                    />
                  </div>
                  <div>
                    <label className={`block text-xs font-bold mb-1.5 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Password / OTP</label>
                    <input 
                      type="password" 
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className={`w-full px-4 py-3 rounded-xl border focus:outline-none focus:ring-2 transition-all ${inputColor}`}
                      placeholder="••••••••"
                    />
                  </div>
                  <button type="submit" className="w-full py-3.5 bg-green-500 hover:bg-green-600 rounded-xl text-white font-bold transition-all active:scale-95 mt-4">
                    Access Dashboard
                  </button>
                </form>
              </motion.div>
            )}

            {/* Apply Stage */}
            {authStage === 'apply' && (
              <motion.div key="apply" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} className="max-w-md mx-auto">
                <div className="mb-6">
                  <button onClick={() => setAuthStage('intro')} className={`text-sm mb-4 inline-flex items-center gap-1 ${isDarkMode ? 'text-gray-400 hover:text-white' : 'text-gray-500 hover:text-gray-900'}`}>
                    &larr; Back
                  </button>
                  <h2 className="text-2xl font-black mb-1">Seller Application</h2>
                  <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Please provide your details. Approval takes 1-2 business days.</p>
                </div>
                
                {applySuccess ? (
                  <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col items-center justify-center py-10 text-center space-y-4">
                    <div className="w-16 h-16 bg-green-500/20 text-green-500 rounded-full flex items-center justify-center">
                      <CheckCircle size={32} />
                    </div>
                    <h3 className="text-xl font-black text-green-500">Application Submitted!</h3>
                    <p className={`text-sm max-w-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>We've received your request. Our team will review it and notify you via email shortly.</p>
                    <button onClick={onClose} className={`px-6 py-2.5 rounded-lg font-bold border transition-colors mt-4 ${isDarkMode ? 'border-gray-700 hover:bg-gray-800' : 'border-gray-200 hover:bg-gray-50'}`}>
                      Back to Game
                    </button>
                  </motion.div>
                ) : (
                  <form onSubmit={handleApply} className="space-y-4">
                    {applyError && (
                      <div className="p-3.5 rounded-xl border border-red-500/20 bg-red-500/10 text-red-500 text-xs font-semibold flex items-start gap-2 animate-bounce">
                        <AlertCircle size={18} className="shrink-0 mt-0.5" />
                        <span>{applyError}</span>
                      </div>
                    )}
                    <div>
                      <label className={`block text-xs font-bold mb-1.5 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Full Name / Business Name</label>
                      <input 
                        type="text" 
                        required
                        value={applyForm.name}
                        onChange={(e) => setApplyForm({...applyForm, name: e.target.value})}
                        className={`w-full px-4 py-3 rounded-xl border focus:outline-none focus:ring-2 transition-all ${inputColor}`}
                        placeholder="John Doe"
                      />
                    </div>
                    <div>
                      <label className={`block text-xs font-bold mb-1.5 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Contact Email</label>
                      <input 
                        type="email" 
                        required
                        value={applyForm.email}
                        onChange={(e) => setApplyForm({...applyForm, email: e.target.value})}
                        className={`w-full px-4 py-3 rounded-xl border focus:outline-none focus:ring-2 focus:ring-green-500/50 border-green-500/30 font-semibold transition-all shadow-sm ${inputColor}`}
                        placeholder="john@example.com"
                      />
                      <p className="text-[10px] text-green-500 mt-1 font-medium">✓ Securely filtered: Tied to your active player account and email in real-time.</p>
                    </div>
                    <div>
                      <label className={`block text-xs font-bold mb-1.5 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Desired Password (for Login)</label>
                      <input 
                        type="password" 
                        required
                        value={applyForm.password}
                        onChange={(e) => setApplyForm({...applyForm, password: e.target.value})}
                        className={`w-full px-4 py-3 rounded-xl border focus:outline-none focus:ring-2 focus:ring-blue-500/50 border-blue-500/30 transition-all font-mono tracking-widest ${inputColor}`}
                        placeholder="Create a password"
                      />
                      <p className="text-[10px] text-blue-500 mt-1 font-medium">✓ Protected setup: Fully encrypted transfer protocols enabled.</p>
                    </div>
                    <div>
                      <label className={`block text-xs font-bold mb-1.5 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Estimated Monthly Volume</label>
                      <select 
                        value={applyForm.volume}
                        onChange={(e) => setApplyForm({...applyForm, volume: e.target.value})}
                        className={`w-full px-4 py-3 rounded-xl border focus:outline-none focus:ring-2 transition-all ${inputColor}`}>
                        <option value="Under 10,000 Coins">Under 10,000 Coins</option>
                        <option value="10,000 - 50,000 Coins">10,000 - 50,000 Coins</option>
                        <option value="50,000+ Coins">50,000+ Coins</option>
                      </select>
                    </div>
                    <div>
                      <label className={`block text-xs font-bold mb-1.5 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Why do you want to become a seller?</label>
                      <textarea 
                        required
                        rows={3}
                        value={applyForm.motivation}
                        onChange={(e) => setApplyForm({...applyForm, motivation: e.target.value})}
                        className={`w-full px-4 py-3 rounded-xl border focus:outline-none focus:ring-2 transition-all ${inputColor} resize-none`}
                        placeholder="Provide brief details..."
                      />
                    </div>
                    <div className={`p-3 rounded-xl border flex gap-3 items-start ${isDarkMode ? 'border-yellow-900/30 bg-yellow-900/10 text-yellow-500' : 'border-yellow-200 bg-yellow-50 text-yellow-700'}`}>
                      <AlertCircle size={18} className="shrink-0 mt-0.5" />
                      <p className="text-xs">Security deposit of $500 is required upon approval before you can start trading.</p>
                    </div>
                    <button type="submit" disabled={isSubmitting} className={`w-full py-3.5 rounded-xl text-white font-bold transition-all active:scale-95 mt-2 ${isSubmitting ? 'bg-green-600/50 cursor-not-allowed' : 'bg-green-500 hover:bg-green-600'}`}>
                      {isSubmitting ? 'Submitting...' : 'Submit Application'}
                    </button>
                  </form>
                )}
              </motion.div>
            )}

            {/* Dashboard Stage */}
            {authStage === 'dashboard' && (
              <motion.div key="dashboard" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6 pb-6">
                <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-black flex items-center gap-2">
                      Overview <span className="px-2 py-0.5 text-xs bg-green-500/20 text-green-500 rounded-lg">Verified</span>
                    </h2>
                    <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Welcome back, verified seller.</p>
                  </div>
                  <button onClick={handleLogout} className={`px-4 py-2 rounded-lg text-sm font-bold border transition-colors ${isDarkMode ? 'border-gray-700 hover:bg-gray-800' : 'border-gray-200 hover:bg-gray-50'}`}>
                    Log Out
                  </button>
                </div>
                
                {/* Send Coins to User */}
                <div className={`p-4 rounded-xl border ${isDarkMode ? 'bg-gray-800/80 border-gray-700' : 'bg-gray-50 border-gray-200'}`}>
                  <h3 className="font-bold text-base mb-3 flex items-center gap-2">
                    <DollarSign size={18} className="text-blue-500" /> Send Coins
                  </h3>
                  <div className="flex flex-col sm:flex-row gap-3 relative">
                    <div className="flex-1 relative">
                      <input 
                        type="text" 
                        placeholder="User ID / Username" 
                        value={transferUserId}
                        onChange={e => handlePlayerInputChange(e.target.value)}
                        onFocus={() => {
                          if (transferUserId.trim()) {
                            setShowSuggestions(true);
                          }
                        }}
                        className={`w-full px-3 py-2 text-sm rounded-lg border focus:outline-none focus:ring-2 transition-all ${inputColor}`}
                      />
                      {showSuggestions && suggestedPlayers.length > 0 && (
                        <div className={`absolute left-0 right-0 mt-1 max-h-48 overflow-y-auto rounded-lg border shadow-lg z-50 ${isDarkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-white border-gray-200 text-gray-900'}`}>
                          {suggestedPlayers.map((p, idx) => (
                            <button
                              key={`player_${p.id}_${idx}`}
                              type="button"
                              onClick={() => {
                                setTransferUserId(p.id);
                                setShowSuggestions(false);
                              }}
                              className={`w-full px-3 py-2 flex items-center justify-between text-left text-xs transition-colors hover:bg-opacity-80 border-b last:border-0 ${
                                isDarkMode 
                                  ? 'hover:bg-gray-700/50 border-gray-700/30' 
                                  : 'hover:bg-gray-50 border-gray-100'
                              }`}
                            >
                              <div className="flex items-center gap-2">
                                <img src={p.avatar} alt="avatar" className="w-5 h-5 rounded-full object-cover shrink-0" />
                                <div className="truncate">
                                  <span className="font-extrabold">{p.name || p.id}</span>
                                  <span className="text-[10px] opacity-55 font-mono ml-1">({p.id})</span>
                                </div>
                              </div>
                              <span className="font-bold text-yellow-500 font-mono text-[10px] shrink-0">{p.balance.toLocaleString()} 💰</span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                    <select 
                      value={transferAmountType}
                      onChange={e => setTransferAmountType(e.target.value)}
                      className={`flex-1 px-3 py-2 text-sm rounded-lg border focus:outline-none focus:ring-2 transition-all ${inputColor}`}>
                      <option value="custom">Custom Amount</option>
                      <option value="5000">5,000 Coins Package ($50)</option>
                      <option value="10000">10,000 Coins Package ($100)</option>
                      <option value="25000">25,000 Coins Package ($250)</option>
                      <option value="50000">50,000 Coins Package ($500)</option>
                    </select>
                    {transferAmountType === 'custom' && (
                      <input 
                        type="number" 
                        placeholder="Amount"
                        value={transferCustomAmount}
                        onChange={e => setTransferCustomAmount(e.target.value)}
                        className={`flex-1 px-3 py-2 text-sm rounded-lg border focus:outline-none focus:ring-2 transition-all ${inputColor}`}
                      />
                    )}
                    <button onClick={handleTransfer} disabled={isSubmitting} className={`px-5 py-2 rounded-lg text-white font-bold transition-all shadow-sm whitespace-nowrap ${isSubmitting ? 'bg-blue-600/50 cursor-not-allowed' : 'bg-blue-500 hover:bg-blue-600'}`}>
                      {isSubmitting ? 'Transferring...' : 'Transfer'}
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4" id="seller-status-dashboard">
                  <div id="seller-stock-card" className={`p-4 border rounded-xl flex flex-col justify-between transition-all duration-300 ${isDarkMode ? 'border-gray-800 bg-gray-800/50' : 'border-gray-100 bg-gray-50'}`}>
                    <div>
                      <div className="flex justify-between items-start mb-2">
                        <p className={`text-xs font-bold uppercase tracking-wider ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Available Stock</p>
                        <DollarSign size={16} className="text-emerald-500" />
                      </div>
                      <p className="text-3xl font-black text-emerald-500">{dashboardStock.toLocaleString()}</p>
                      <div className="flex items-center gap-1.5 mt-1">
                        <p className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Coins ready to sell</p>
                        {dashboardStock <= 10000 && (
                          <span className="animate-pulse text-[10px] bg-red-400/20 text-red-500 px-1.5 py-0.5 rounded font-extrabold uppercase shrink-0">Low Stock</span>
                        )}
                      </div>
                    </div>
                    <button 
                      id="seller-reload-stock-btn"
                      onClick={() => setIsReloadModalOpen(true)}
                      className="mt-4 w-full py-2 bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white font-extrabold text-xs rounded-lg transition-all shadow-md shadow-emerald-500/10 cursor-pointer flex items-center justify-center gap-1.5 hover:scale-[1.02] active:scale-95 duration-200"
                    >
                      <Store size={14} /> Reload Stock from Shop
                    </button>
                  </div>
                  <div className={`p-4 border rounded-xl ${isDarkMode ? 'border-gray-800 bg-gray-800/50' : 'border-gray-100 bg-gray-50'}`}>
                    <div className="flex justify-between items-start mb-2">
                      <p className={`text-xs font-bold uppercase tracking-wider ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Transactions</p>
                      <Users size={16} className="text-yellow-500" />
                    </div>
                    <p className="text-3xl font-black text-yellow-500">{dashboardTransactions.length}</p>
                    <p className={`text-xs mt-2 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Completed orders</p>
                  </div>
                  <div className={`p-4 border rounded-xl relative ${isDarkMode ? 'border-gray-800 bg-gray-800/50' : 'border-gray-100 bg-gray-50'}`}>
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex flex-col">
                        <select 
                          value={revenueTimeFilter}
                          onChange={(e) => setRevenueTimeFilter(e.target.value as 'today'|'month'|'year')}
                          className={`text-xs font-bold uppercase tracking-wider bg-transparent outline-none cursor-pointer ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                          <option value="today">Today's Revenue</option>
                          <option value="month">Month's Revenue</option>
                          <option value="year">Year's Revenue</option>
                        </select>
                      </div>
                      <TrendingUp size={16} className="text-green-500" />
                    </div>
                    <p className="text-3xl font-black text-green-500 mt-1">${calculateRevenue()}</p>
                    <p className={`text-xs mt-2 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Estimated value</p>
                  </div>
                </div>

                <div>
                  <h3 className="font-bold text-lg mb-3">Recent P2P Orders</h3>
                  <div className={`border rounded-xl overflow-hidden ${isDarkMode ? 'border-gray-800' : 'border-gray-200'}`}>
                    <table className="w-full text-left text-sm">
                      <thead className={`text-xs uppercase bg-opacity-50 ${isDarkMode ? 'bg-gray-800 text-gray-400' : 'bg-gray-50 text-gray-500'}`}>
                        <tr>
                          <th className="px-4 py-3 font-medium">Buyer</th>
                          <th className="px-4 py-3 font-medium">Prize (Coins)</th>
                          <th className="px-4 py-3 font-medium">Cash (USD)</th>
                          <th className="px-4 py-3 font-medium">Status</th>
                          <th className="px-4 py-3 font-medium text-right">Date</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-inherit">
                        {dashboardTransactions.length > 0 ? dashboardTransactions.map((tx, idx) => (
                          <tr key={`${tx.id || "tx"}_${idx}`}>
                            <td className="px-4 py-3 font-medium">
                              <div className="flex items-center gap-2">
                                <img src={tx.userAvatar} alt="avatar" className="w-6 h-6 rounded-full bg-black/10" />
                                <span>{tx.userName}</span>
                              </div>
                            </td>
                            <td className="px-4 py-3 font-bold text-yellow-500">{tx.amount.toLocaleString()} Coins</td>
                            <td className="px-4 py-3 text-green-500 font-bold">${(tx.amount / 100).toFixed(2)}</td>
                            <td className="px-4 py-3"><span className="px-2 py-1 rounded bg-green-500/20 text-green-600 text-xs font-bold">Completed</span></td>
                            <td className="px-4 py-3 text-right">
                              <span className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>{new Date(tx.date).toLocaleDateString()}</span>
                            </td>
                          </tr>
                        )) : (
                          <tr><td colSpan={5} className="px-4 py-8 text-center opacity-70">No recent orders found</td></tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="mt-8 border-t pt-6">
                  <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                    <MessageCircle className="text-blue-500" /> Live Support & P2P Chat
                  </h3>
                  <div className={`rounded-2xl border overflow-hidden shadow-lg h-[450px] ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
                    <ChatBox
                      messages={chatMessages.map((msg, idx) => ({
                        id: msg.id || `msg_${idx}`,
                        sender: msg.senderId === sellerData?.id ? 'You' : (msg.sender || 'System'),
                        senderId: msg.senderId || 'SYSTEM',
                        text: msg.text,
                        avatar: msg.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${msg.sender || 'User'}`,
                        mediaList: msg.mediaList || [],
                        timestamp: msg.timestamp || new Date().toLocaleTimeString()
                      }))}
                      currentUser={{ 
                        id: sellerData?.id || 'GUEST', 
                        name: sellerData?.name || 'Seller', 
                        avatar: sellerData?.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${sellerData?.name || 'Seller'}` 
                      }}
                      isAdmin={false}
                      isDarkMode={isDarkMode}
                      onSendMessage={handleSendMessage}
                    />
                  </div>
                </div>

              </motion.div>
            )}

          </AnimatePresence>

          {/* Checkout & Stock Reload Sub-modal Popover */}
          <AnimatePresence>
            {isReloadModalOpen && (
              <div className="fixed inset-0 z-[350] bg-black/75 backdrop-blur-md flex items-center justify-center p-4">
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95, y: 15 }} 
                  animate={{ opacity: 1, scale: 1, y: 0 }} 
                  exit={{ opacity: 0, scale: 0.95, y: 15 }} 
                  className={`w-full max-w-md max-h-[80vh] overflow-y-auto p-6 rounded-2xl border-2 shadow-2xl relative transition-all duration-300 hover:shadow-emerald-500/5 backdrop-blur-md ${isDarkMode ? 'bg-gray-950/95 border-emerald-500/20 text-white shadow-black/60' : 'bg-white/95 border-emerald-500/20 text-gray-900 shadow-emerald-500/5'}`}
                >
                  <button 
                    onClick={() => setIsReloadModalOpen(false)} 
                    className={`absolute top-4 right-4 p-1.5 rounded-lg transition-colors cursor-pointer ${isDarkMode ? 'hover:bg-gray-800 text-gray-400 hover:text-white' : 'hover:bg-gray-100 text-gray-500 hover:text-gray-900'}`}
                  >
                    <X size={18} />
                  </button>
                  
                  <div className="flex items-center gap-2 mb-4 text-emerald-500">
                    <Store size={22} className="animate-pulse" />
                    <h4 className="text-lg font-black tracking-tight">Coin Shop - Stock Reload</h4>
                  </div>
                  
                  <p className={`text-xs mb-4 leading-relaxed ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                    Pre-purchase coin packages instantly to restore your inventory. All wholesale payments are securely processed and credited.
                  </p>
                  
                  <div className="space-y-3 mb-5">
                    {[
                      { amount: 100000, price: '10.00', label: 'Starter Stock Pack', coins: '100,000' },
                      { amount: 500000, price: '45.00', label: 'Standard Wholesale', coins: '500,000' },
                      { amount: 1000000, price: '80.00', label: 'Professional Escrow', coins: '1,000,000' },
                      { amount: 5000000, price: '350.00', label: 'Mega Reseller Load', coins: '5,000,000' }
                    ].map((pkg) => (
                      <div 
                        key={pkg.amount}
                        onClick={() => setReloadAmountSelection(pkg.amount)}
                        className={`p-3.5 rounded-xl border-2 cursor-pointer transition-all duration-300 ${
                          reloadAmountSelection === pkg.amount 
                            ? 'border-emerald-500 bg-emerald-500/5' 
                            : isDarkMode ? 'border-gray-800 hover:border-gray-700 hover:bg-gray-800/40' : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2.5">
                            <input 
                              type="radio" 
                              name="reloadPackage" 
                              className="accent-emerald-500 cursor-pointer" 
                              checked={reloadAmountSelection === pkg.amount} 
                              onChange={() => setReloadAmountSelection(pkg.amount)} 
                            />
                            <div>
                              <p className="font-extrabold text-xs">{pkg.label}</p>
                              <p className="text-[11px] text-yellow-500 font-black">+{pkg.coins} Coins Stock</p>
                            </div>
                          </div>
                          <span className="font-extrabold text-xs text-emerald-500">${pkg.price} USD</span>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <div className="space-y-3 mb-6 relative">
                    {paymentStep !== 'idle' ? (
                      <div className="p-4 rounded-xl border border-emerald-500/30 bg-emerald-500/5 backdrop-blur-sm flex flex-col items-center justify-center text-center py-6 min-h-[160px] animate-pulse">
                        <div className="relative mb-3 flex items-center justify-center">
                          <div className="absolute inset-0 w-12 h-12 bg-emerald-500/20 rounded-full animate-ping" />
                          <div className="w-10 h-10 rounded-full bg-emerald-500/10 border border-emerald-500/40 flex items-center justify-center text-emerald-500">
                            <Lock size={18} className="animate-bounce" />
                          </div>
                        </div>
                        <h5 className="text-xs font-extrabold text-emerald-500 uppercase tracking-widest mb-1.5">Secure Transaction Network</h5>
                        <p className={`text-xs font-bold leading-relaxed max-w-[280px] font-mono ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                          {paymentStepText}
                        </p>
                        <div className="mt-4 flex items-center gap-2 justify-center text-[9px] uppercase tracking-wider text-gray-400 font-bold">
                          <ShieldCheck size={11} className="text-emerald-500" />
                          <span>PCI-DSS Compliant Gateway (256-Bit SSL)</span>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="flex justify-between items-center mb-1 bg-black/5 dark:bg-white/5 p-1.5 rounded-lg border border-emerald-500/10">
                          <p className={`text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 ${isDarkMode ? 'text-emerald-400' : 'text-emerald-600'}`}>
                            <ShieldCheck size={13} /> Secure P2P Escrow Gateway
                          </p>
                          <span className="text-[9px] text-emerald-500 bg-emerald-500/15 px-1.5 py-0.5 rounded font-black uppercase font-mono">Verified Card</span>
                        </div>
                        
                        {/* Live Visualizing Credit Card Graphics */}
                        <div className="relative h-32 w-full rounded-xl overflow-hidden bg-gradient-to-br from-emerald-600 via-teal-800 to-cyan-900 border border-emerald-500/30 text-white shadow-xl flex flex-col p-4 justify-between transition-transform duration-500 [transform-style:preserve-3d] [perspective:1000px] hover:scale-[1.01]"
                             style={{ transform: cvcFocused ? 'rotateY(10deg)' : 'none' }}>
                          
                          {/* Secure Overlay background chip */}
                          <div className="absolute inset-0 bg-black/10 backdrop-blur-[1px] pointer-events-none" />
                          
                          {!cvcFocused ? (
                            <>
                              {/* Front of visual card */}
                              <div className="flex justify-between items-start z-10">
                                <div>
                                  <p className="text-[9px] uppercase tracking-widest text-emerald-300 font-extrabold flex items-center gap-1">
                                    <ShieldCheck size={10} /> Escrow Secur-Pay Card
                                  </p>
                                  <div className="w-7 h-5 bg-yellow-400/80 rounded-sm mt-1.5 flex items-center justify-center border border-yellow-300/40 opacity-90 overflow-hidden relative">
                                    <div className="absolute inset-x-1.5 h-full border-x border-black/10" />
                                    <div className="absolute inset-y-1 h-full border-y border-black/10" />
                                  </div>
                                </div>
                                <div className="text-right flex flex-col items-end">
                                  <span className="text-[10px] font-black italic tracking-widest text-[#E0E0E0]">VISA</span>
                                  <span className="text-[6px] tracking-wider text-emerald-300 font-medium select-none">Verified Gateway</span>
                                </div>
                              </div>
                              
                              <div className="my-1.5 text-center text-sm font-bold tracking-[0.2em] font-mono z-10 text-white drop-shadow">
                                {payCardNumber || '•••• •••• •••• ••••'}
                              </div>
                              
                              <div className="flex justify-between items-end z-10">
                                <div>
                                  <p className="text-[6px] uppercase tracking-wider text-emerald-300 font-extrabold">Cardholder Name</p>
                                  <p className="text-[10px] font-bold tracking-wide truncate max-w-[160px] font-mono capitalize">{payName || 'CRYPTO RESELLER'}</p>
                                </div>
                                <div className="text-right">
                                  <p className="text-[6px] uppercase tracking-wider text-emerald-300 font-extrabold">Expires</p>
                                  <p className="text-[10px] font-bold font-mono text-center">{payExpiry || 'MM/YY'}</p>
                                </div>
                              </div>
                            </>
                          ) : (
                            <>
                              {/* Back of visual card */}
                              <div className="absolute top-4 inset-x-0 h-7 bg-black z-10" />
                              <div className="mt-8 flex justify-between items-center z-10 px-1">
                                <div className="w-[70%] h-6 bg-gray-200/90 rounded flex items-center justify-end px-2 select-none">
                                  <span className="text-[8px] italic text-gray-400 tracking-widest">Authorized Reseller Sign</span>
                                </div>
                                <div className="text-right w-[20%]">
                                  <span className="text-[7px] uppercase tracking-wider text-emerald-300 font-extrabold block">CVC</span>
                                  <span className="bg-white text-black font-mono font-bold text-xs px-1.5 py-0.5 rounded shadow-inner inline-block">{payCvc || '•••'}</span>
                                </div>
                              </div>
                              <div className="text-[7px] text-center text-emerald-300/80 z-10 font-medium tracking-tight mt-1">
                                🔒 Non-custodial SSL encrypted instant payout signature
                              </div>
                            </>
                          )}
                        </div>

                        <div className="grid grid-cols-2 gap-2 mt-3">
                          <input 
                            type="text" 
                            required
                            placeholder="Cardholder Name" 
                            value={payName}
                            onChange={(e) => setPayName(e.target.value.substring(0, 26))}
                            className={`px-3 py-2 text-xs rounded-lg border focus:outline-none col-span-2 focus:ring-1 ${inputColor}`}
                          />
                          <input 
                            type="text" 
                            required
                            placeholder="Card Number" 
                            value={payCardNumber}
                            onChange={(e) => {
                              const v = e.target.value.replace(/\D/g, '').substring(0, 16);
                              const formatted = v.match(/.{1,4}/g)?.join(' ') || v;
                              setPayCardNumber(formatted);
                            }}
                            className={`col-span-2 px-3 py-2 text-xs rounded-lg border focus:outline-none focus:ring-1 ${inputColor}`}
                          />
                          <input 
                            type="text" 
                            required
                            placeholder="MM/YY" 
                            value={payExpiry}
                            onChange={(e) => {
                              const v = e.target.value.replace(/\D/g, '').substring(0, 4);
                              const formatted = v.length > 2 ? v.substring(0, 2) + '/' + v.substring(2) : v;
                              setPayExpiry(formatted);
                            }}
                            className={`px-3 py-2 text-xs rounded-lg border focus:outline-none focus:ring-1 ${inputColor}`}
                          />
                          <input 
                            type="password" 
                            required
                            placeholder="CVC" 
                            value={payCvc}
                            onChange={(e) => {
                              const v = e.target.value.replace(/\D/g, '').substring(0, 3);
                              setPayCvc(v);
                            }}
                            onFocus={() => setCvcFocused(true)}
                            onBlur={() => setCvcFocused(false)}
                            maxLength={3}
                            className={`px-3 py-2 text-xs rounded-lg border focus:outline-none focus:ring-1 ${inputColor}`}
                          />
                        </div>

                        {/* Security Disclaimers Footer */}
                        <div className="mt-3 flex gap-2 items-start p-2.5 rounded-lg bg-black/5 dark:bg-white/5 border border-emerald-500/10 text-[10px] text-gray-500 leading-normal">
                          <Lock size={12} className="text-emerald-500 shrink-0 mt-0.5" />
                          <div>
                            <span className="font-bold text-emerald-500 block">End-to-End Encrypted Handshakes</span>
                            Your actual billing credentials are never sent to our servers. Purchases credit instantly via P2P payment providers.
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                  
                  <div className="flex justify-end gap-2">
                    <button 
                      onClick={() => setIsReloadModalOpen(false)} 
                      className={`px-4 py-2 rounded-xl text-xs font-bold border cursor-pointer transition-colors ${isDarkMode ? 'border-gray-800 text-gray-400 hover:bg-gray-800' : 'border-gray-200 text-gray-600 hover:bg-gray-105'}`}
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={() => handleReloadStock(reloadAmountSelection)} 
                      disabled={isReloading} 
                      className="px-5 py-2.5 rounded-xl text-xs text-white font-black bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-600 hover:via-teal-600 hover:to-emerald-700 active:scale-95 transition-all shadow-md shadow-emerald-500/30 cursor-pointer disabled:opacity-50 flex items-center gap-1.5 font-sans"
                    >
                      {isReloading ? (
                        <>
                          <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin shrink-0" />
                          <span>Securing Contract...</span>
                        </>
                      ) : (
                        <>
                          <Lock size={12} />
                          <span>Pay & Reload Stock</span>
                        </>
                      )}
                    </button>
                  </div>
                </motion.div>
              </div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
};
