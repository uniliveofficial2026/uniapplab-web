import React from 'react';
import { ItemIcon } from './ItemIcon';
import { GameItem } from '../types';

interface AdminItemCardProps {
  item: GameItem;
  index: number;
  isDarkMode: boolean;
  getItemChance: (item: GameItem, idx: number) => string;
  getItemWeight: (item: GameItem) => number;
  handleItemChange: (index: number, field: keyof GameItem, value: any) => void;
  handleUploadIcon: (index: number, itemId: string, iconBase64: string) => Promise<void>;
  localItems: GameItem[];
  setLocalItems: React.Dispatch<React.SetStateAction<GameItem[]>>;
}

export const AdminItemCard: React.FC<AdminItemCardProps> = React.memo(({ 
    item, index, isDarkMode, getItemChance, getItemWeight, handleItemChange, handleUploadIcon, localItems, setLocalItems 
}) => {
  return (
    <div className={`border-2 p-5 rounded-3xl flex flex-col gap-4 relative transition-all group overflow-hidden ${isDarkMode ? 'bg-gray-900/50 border-gray-700 hover:border-blue-500/50' : 'bg-gray-50/50 border-gray-100 hover:border-blue-200 hover:bg-white'}`}>
      {/* Status Badge */}
      <div className="absolute top-0 right-0">
         <div className={`px-3 py-1.5 rounded-bl-2xl text-[8px] font-black uppercase tracking-widest ${isDarkMode ? 'bg-blue-500/20 text-blue-400' : 'bg-blue-500 text-white'}`}>
            Asset Component
         </div>
      </div>

      <div className="absolute top-10 right-4 opacity-70 group-hover:opacity-100 transition-opacity">
        <ItemIcon icon={item.icon} className="text-4xl w-14 h-14 flex items-center justify-center filter drop-shadow-xl p-1 bg-white dark:bg-gray-800 rounded-2xl border border-blue-500/20" />
       </div>
       
       <div className="pr-2 max-w-fit">
         <label className={`block text-xs font-bold mb-1 uppercase tracking-wider ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Name</label>
         <input 
           type="text" 
           value={item.name} 
           onChange={(e) => handleItemChange(index, 'name', e.target.value)}
           className={`w-40 border-2 rounded-lg p-2 font-bold focus:ring-2 focus:ring-blue-500 focus:outline-none transition-colors ${isDarkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-white border-gray-200'}`}
         />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
         <div className="max-w-fit">
           <label className={`block text-xs font-bold mb-1 uppercase tracking-wider ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Multiplier</label>
           {['salad', 'pizza'].includes(item.id) ? (
             <div className={`w-full border-2 rounded-lg p-2 font-bold text-gray-500 text-xs flex items-center h-[42px] transition-colors ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-100 border-gray-200'}`}>
               Dynamic Payout
             </div>
           ) : (
             <input 
               type="number" 
               value={item.multiplier} 
               onChange={(e) => handleItemChange(index, 'multiplier', e.target.value)}
               className={`w-20 border-2 rounded-lg p-2 font-bold text-blue-500 focus:ring-2 focus:ring-blue-500 focus:outline-none transition-colors ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} h-[42px]`}
             />
           )}
         </div>
         <div>
            <div className="w-full">
              <div className="flex justify-between items-center mb-1">
                 <label className={`block text-xs font-bold uppercase tracking-wider ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                   Weight
                 </label>
                 <span className={`text-[10px] font-black px-1.5 py-0.5 rounded border ${isDarkMode ? 'bg-green-950/40 text-green-400 border-green-900/30' : 'bg-green-100 text-green-700 border-green-200/50'}`}>
                    {getItemChance(item, index)}% Chance
                 </span>
              </div>
              <div className="flex gap-1.5 items-center h-[42px]">
                 <input 
                   type="range" 
                   min="1" 
                   max="100" 
                   value={getItemWeight(item)}
                   onChange={(e) => handleItemChange(index, 'weight', e.target.value)}
                   className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700 accent-blue-500" 
                 />
                 <input 
                   type="number" 
                   min="1" 
                   max="1000" 
                   value={getItemWeight(item)} 
                   onChange={(e) => handleItemChange(index, 'weight', e.target.value)}
                   className={`w-14 border-2 rounded-lg p-1.5 text-center font-black text-xs text-[#E65100] focus:ring-2 focus:ring-blue-500 focus:outline-none transition-colors ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} h-full`}
                 />
              </div>
            </div>
          </div>

          <div className="md:col-span-2">
           <label className={`block text-xs font-bold mb-1 uppercase tracking-wider whitespace-nowrap ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Icon</label>
           <div className="flex gap-2 h-[42px]">
             {item.icon.startsWith('data:') || item.icon.startsWith('/uploads/') ? (
               <div className={`flex-1 border-2 rounded-lg flex items-center px-3 gap-2 transition-colors ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'} h-full`}>
                 <div className="w-6 h-6 flex items-center justify-center shrink-0">
                   <ItemIcon icon={item.icon} className="max-w-full max-h-full" />
                 </div>
                 <span className={`text-[10px] font-black uppercase tracking-tight ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Permanent Sync: ON</span>
                 <button 
                   type="button"
                   onClick={() => {
                      const updated = [...localItems];
                      const defaults = [
                        { id: 'hotdog', icon: '🌭' }, { id: 'skewer', icon: '🍢' }, { id: 'ham', icon: '🍖' }, 
                        { id: 'steak', icon: '🥩' }, { id: 'carrot', icon: '🥕' }, { id: 'corn', icon: '🌽' }, 
                        { id: 'cabbage', icon: '🥬' }, { id: 'tomato', icon: '🍅' }, { id: 'salad', icon: '🥗' }, 
                        { id: 'pizza', icon: '🍕' }
                      ];
                      const found = defaults.find(d => d.id === item.id);
                      if (found) {
                        updated[index].icon = found.icon;
                        setLocalItems(updated);
                      }
                   }}
                   className={`text-[8px] font-black uppercase tracking-widest px-2 py-1 rounded transition-colors ${isDarkMode ? 'bg-red-500/10 text-red-400 hover:bg-red-500/20' : 'bg-red-50 text-red-600 hover:bg-red-100'}`}
                 >
                    Reset Asset
                 </button>
               </div>
             ) : (
               <input 
                 type="text" 
                 value={item.icon} 
                 onChange={(e) => handleItemChange(index, 'icon', e.target.value)}
                 className={`w-full border-2 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 focus:outline-none transition-colors ${isDarkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-white border-gray-200'} h-full`}
                 placeholder="Emoji"
               />
             )}
             <label className="cursor-pointer bg-blue-100 hover:bg-blue-200 text-blue-700 font-bold px-3 shrink-0 rounded-lg flex items-center justify-center transition-colors shadow-sm active:scale-95 h-full">
                📁
                <input 
                  type="file" 
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = (event) => {
                        if (event.target?.result) {
                          handleUploadIcon(index, item.id, event.target.result as string);
                        }
                      };
                      reader.readAsDataURL(file);
                    }
                  }}
                />
             </label>
           </div>
         </div>
      </div>
    </div>
  );
});
