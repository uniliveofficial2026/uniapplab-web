import React, { useState, useRef, useEffect, ChangeEvent } from 'react';
import { Send, Paperclip, X, User, Maximize2 } from 'lucide-react';
import { socket } from '../socket';
import { motion, AnimatePresence } from 'motion/react';

interface MediaItem {
  type: 'image' | 'video';
  url: string;
}

interface Message {
  id: string;
  sender: string;
  senderId: string;
  avatar?: string;
  text: string;
  mediaList?: MediaItem[];
  timestamp: string;
}

interface ChatBoxProps {
  messages: Message[];
  onSendMessage: (text: string, mediaList?: MediaItem[]) => void;
  currentUser: { id: string; name: string; avatar: string };
  isAdmin: boolean;
  isDarkMode?: boolean;
}

export const ChatBox: React.FC<ChatBoxProps> = ({ messages, onSendMessage, currentUser, isAdmin, isDarkMode: isDarkModeProp }) => {
  const isDark = isDarkModeProp ?? (typeof document !== 'undefined' ? document.documentElement.classList.contains('dark') : false);
  const [text, setText] = useState('');
  const [mediaList, setMediaList] = useState<MediaItem[]>([]);
  const [lightbox, setLightbox] = useState<{ items: MediaItem[], index: number } | null>(null);
  const [typingUsers, setTypingUsers] = useState<Record<string, string>>({});
  const fileInputRef = useRef<HTMLInputElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const typingTimerRef = useRef<NodeJS.Timeout | null>(null);

  const scrollToBottom = (behavior: ScrollBehavior = 'auto') => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTo({
        top: scrollContainerRef.current.scrollHeight,
        behavior
      });
    }
  };

  useEffect(() => {
    socket.on('typing_status_received', (data: { senderId: string, senderName: string, isTyping: boolean }) => {
      if (data.senderId === currentUser.id) return;
      
      setTypingUsers(prev => {
        const next = { ...prev };
        if (data.isTyping) {
          next[data.senderId] = data.senderName;
        } else {
          delete next[data.senderId];
        }
        return next;
      });
    });

    return () => {
      socket.off('typing_status_received');
    };
  }, [currentUser.id]);

  useEffect(() => {
    // Determine if we should auto-scroll
    const el = scrollContainerRef.current;
    if (el) {
      const isNearBottom = el.scrollHeight - el.scrollTop <= el.clientHeight + 150;
      if (isNearBottom) {
        scrollToBottom();
      }
    }
  }, [messages, typingUsers]);

  const handleInputChange = (val: string) => {
    setText(val);
    
    // Emit typing status
    socket.emit('typing_status', {
      senderId: currentUser.id,
      senderName: currentUser.name,
      isTyping: true
    });

    if (typingTimerRef.current) clearTimeout(typingTimerRef.current);
    
    typingTimerRef.current = setTimeout(() => {
      socket.emit('typing_status', {
        senderId: currentUser.id,
        senderName: currentUser.name,
        isTyping: false
      });
    }, 2000);
  };

  const handleSend = () => {
    if (text.trim() || mediaList.length > 0) {
      onSendMessage(text, mediaList);
      setText('');
      setMediaList([]);
      
      // Stop typing status instantly
      if (typingTimerRef.current) clearTimeout(typingTimerRef.current);
      socket.emit('typing_status', {
        senderId: currentUser.id,
        senderName: currentUser.name,
        isTyping: false
      });

      // Force scroll on outgoing message with smooth behavior
      setTimeout(() => scrollToBottom('smooth'), 50);
    }
  };

  const handleMediaUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const newMedia: MediaItem[] = (Array.from(files) as File[]).map(file => ({
        type: file.type.startsWith('video') ? 'video' : 'image',
        url: URL.createObjectURL(file)
      }));
      setMediaList(prev => [...prev, ...newMedia]);
    }
    // Reset input value so the same file can be selected again
    e.target.value = '';
  };

  const handleRemoveMedia = (index: number) => {
    setMediaList(prev => {
      const itemToRemove = prev[index];
      if (itemToRemove && itemToRemove.url.startsWith('blob:')) {
        URL.revokeObjectURL(itemToRemove.url);
      }
      return prev.filter((_, i) => i !== index);
    });
  };

  const handleClearMedia = () => {
    mediaList.forEach(item => {
      if (item.url.startsWith('blob:')) {
        URL.revokeObjectURL(item.url);
      }
    });
    setMediaList([]);
  };

  // Cleanup all remaining object URLs on unmount
  useEffect(() => {
    return () => {
      mediaList.forEach(item => {
        if (item.url.startsWith('blob:')) {
          URL.revokeObjectURL(item.url);
        }
      });
    };
  }, []);

  return (
    <div className={`flex flex-col h-full rounded-2xl overflow-hidden relative border ${isDark ? 'bg-gray-900 border-gray-800 text-gray-100' : 'bg-white border-gray-200 text-gray-800'}`}>
      {lightbox && (
        <div className="fixed inset-0 bg-black/95 z-[9999] flex items-center justify-center p-4" onClick={() => setLightbox(null)}>
          <button className="absolute top-4 right-4 text-white p-2" onClick={() => setLightbox(null)}><X /></button>
          
          {lightbox.items.length > 1 && (
            <>
              <button 
                className="absolute left-4 top-1/2 -translate-y-1/2 text-white p-2 bg-black/50 rounded-full"
                onClick={(e) => { e.stopPropagation(); setLightbox({ ...lightbox, index: (lightbox.index - 1 + lightbox.items.length) % lightbox.items.length }); }}
              >{"<"}</button>
              <button 
                className="absolute right-4 top-1/2 -translate-y-1/2 text-white p-2 bg-black/50 rounded-full"
                onClick={(e) => { e.stopPropagation(); setLightbox({ ...lightbox, index: (lightbox.index + 1) % lightbox.items.length }); }}
              >{">"}</button>
            </>
          )}

          <div onClick={(e) => e.stopPropagation()} className="max-h-[90vh] max-w-[90vw] flex items-center justify-center">
            {lightbox.items[lightbox.index].type === 'image' ? (
              <img src={lightbox.items[lightbox.index].url} className="max-h-[90vh] max-w-[90vw] object-contain" />
            ) : (
              <video src={lightbox.items[lightbox.index].url} controls className="max-h-[90vh] max-w-[90vw]" autoPlay muted />
            )}
          </div>
        </div>
      )}
      <div className={`flex-1 overflow-y-auto p-4 space-y-4 ${isDark ? 'bg-gray-900' : 'bg-gray-50/50'}`} ref={scrollContainerRef}>
        {messages.map((msg, idx) => (
          <div key={`chat_msg_${msg.id || 'gen'}_${idx}_${msg.timestamp}`} className={`flex gap-3 ${msg.senderId === currentUser.id ? 'flex-row-reverse' : ''}`}>
             <div className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center shrink-0 overflow-hidden">
               {msg.avatar ? <img src={msg.avatar} alt={msg.sender} className="w-full h-full object-cover" /> : <User size={16} />}
            </div>
            <div className={`max-w-[75%] p-3 rounded-2xl ${msg.senderId === currentUser.id ? 'bg-blue-600 text-white rounded-tr-none' : (isDark ? 'bg-gray-800 text-gray-100 rounded-tl-none' : 'bg-white text-gray-900 rounded-tl-none shadow-sm border border-gray-100/60')}`}>
              <p className="text-[10px] opacity-70 mb-1 font-bold">{msg.sender} <span className="opacity-50 font-normal">#{msg.senderId.slice(-4)}</span></p>
              {msg.text && <p className="text-sm">{msg.text}</p>}
              {msg.mediaList && msg.mediaList.length > 0 && (
                <div className="mt-2 grid grid-cols-3 gap-1.5 max-w-[180px]">
                  {msg.mediaList.map((media, i) => (
                    <div key={`chat_media_${msg.id || `msg_${idx}`}_${i}_${idx}`} className="relative w-14 h-14 rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700 group cursor-pointer" onClick={() => setLightbox({ items: msg.mediaList as MediaItem[], index: i })}>
                      {media.type === 'image' ? <img src={media.url} onLoad={() => scrollToBottom()} className="w-full h-full object-cover" /> : <video src={media.url} className="w-full h-full object-cover" />}
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center"><Maximize2 className="text-white w-3 h-3" /></div>
                    </div>
                  ))}
                </div>
              )}
              <p className="text-[8px] opacity-50 mt-1 uppercase text-right">{msg.timestamp}</p>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
        
        <AnimatePresence>
          {Object.entries(typingUsers).map(([id, name]) => (
            <motion.div
              key={`typing_${id}`}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="flex items-center gap-2 text-[10px] text-gray-500 font-medium italic pl-11"
            >
              <div className="flex gap-1">
                <motion.div animate={{ opacity: [0.4, 1, 0.4] }} transition={{ repeat: Infinity, duration: 1.2 }} className="w-1 h-1 bg-gray-400 rounded-full" />
                <motion.div animate={{ opacity: [0.4, 1, 0.4] }} transition={{ repeat: Infinity, duration: 1.2, delay: 0.2 }} className="w-1 h-1 bg-gray-400 rounded-full" />
                <motion.div animate={{ opacity: [0.4, 1, 0.4] }} transition={{ repeat: Infinity, duration: 1.2, delay: 0.4 }} className="w-1 h-1 bg-gray-400 rounded-full" />
              </div>
              {name} is typing...
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
      
      <div className={`p-3 border-t ${isDark ? 'border-gray-800 bg-gray-950/80' : 'border-gray-200/60 bg-gray-50'}`}>
        {mediaList.length > 0 && (
           <div className="mb-2 p-2 bg-blue-50 dark:bg-blue-900/20 rounded-lg flex flex-wrap gap-2 text-xs text-blue-800 dark:text-blue-200">
              {mediaList.map((m, i) => (
                 <div key={`${m.url}_${i}`} className="relative w-12 h-12 rounded overflow-hidden border border-blue-200">
                    {m.type === 'image' ? <img src={m.url} className="w-full h-full object-cover" /> : <div className="w-full h-full bg-gray-200 flex items-center justify-center text-[8px]">VID</div>}
                    <button 
                      onClick={() => handleRemoveMedia(i)}
                      className="absolute top-0 right-0 p-0.5 bg-red-600 text-white rounded-bl"
                    ><X size={10} /></button>
                 </div>
              ))}
              <button onClick={handleClearMedia} className="font-bold underline ml-auto self-start">Clear</button>
           </div>
        )}
        <div className="flex items-center gap-2">
            <input type="file" ref={fileInputRef} onChange={handleMediaUpload} accept="image/*,video/*" multiple className="hidden" />
            <button onClick={() => fileInputRef.current?.click()} className="text-gray-500 hover:text-blue-500"><Paperclip size={18} /></button>
            <input type="text" value={text} onChange={(e) => handleInputChange(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSend()} placeholder="Type a message..." className={`flex-1 px-3 py-2 rounded-xl text-sm border focus:outline-none focus:ring-2 focus:ring-blue-500/50 ${isDark ? 'bg-gray-800 border-gray-700 text-gray-100 placeholder-gray-500' : 'bg-white border-gray-200 text-gray-900 placeholder-gray-400'}`} />
            <button onClick={handleSend} className="bg-blue-600 text-white p-2 rounded-xl hover:bg-blue-700"><Send size={18} /></button>
        </div>
      </div>
    </div>
  );
};

