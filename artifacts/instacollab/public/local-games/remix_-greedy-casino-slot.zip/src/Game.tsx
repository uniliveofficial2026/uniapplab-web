import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  BET_AMOUNTS,
  BETTING_TIME,
  SPINNING_TIME,
  RESULT_TIME,
} from "./constants";
import { GameState, ItemId, Bets, GameItem, HistoryItem } from "./types";
import { ChatBox } from "./components/ChatBox";
import { PipPortal } from "./components/PipPortal";
import {
  Home,
  Music,
  VolumeX,
  HelpCircle,
  Clock,
  Settings,
  Moon,
  Sun,
  Lock,
  Coins,
  CreditCard,
  CheckCircle2,
  ShieldCheck,
  Menu,
  X,
  Store,
  ChevronDown,
  ChevronUp,
  ChevronLeft,
  ChevronRight,
  User,
  Sparkles,
  MessageSquare,
  Paperclip,
  Wallet,
  Copy,
  Check,
  Fingerprint,
  RefreshCw,
  Trophy,
  Plus,
  Pencil,
  ShoppingCart,
  Smartphone,
  PictureInPicture2,
  Gift,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { ItemIcon } from "./components/ItemIcon";
import { socket } from "./socket";
import { SecurePaymentGateway } from "./components/SecurePaymentGateway";
import { DailyMissionsModal } from "./components/DailyMissionsModal";

const formatAmount = (num: number) => {
  if (typeof num !== "number") return "0";
  const sign = num < 0 ? "-" : "";
  const absNum = Math.abs(num);

  if (absNum >= 1e12) {
    return sign + (absNum / 1e12).toFixed(1).replace(/\.0$/, "") + "t";
  }
  if (absNum >= 1e9) {
    return sign + (absNum / 1e9).toFixed(1).replace(/\.0$/, "") + "b";
  }
  if (absNum >= 1e6) {
    return sign + (absNum / 1e6).toFixed(1).replace(/\.0$/, "") + "m";
  }
  if (absNum >= 1e3) {
    return sign + (absNum / 1e3).toFixed(1).replace(/\.0$/, "") + "k";
  }
  return sign + absNum.toString();
};

socket.on("connect_error", (err) => {
  console.warn("Socket connection error handled:", err.message);
});

socket.on("connect_failed", () => {
  console.warn("Socket connection failed after multiple attempts");
});

const FAQAccordionItem = ({
  question,
  answer,
  isDarkMode,
}: {
  question: string;
  answer: string;
  isDarkMode: boolean;
}) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div
      className={`border rounded-xl overflow-hidden ${isDarkMode ? "border-gray-700 bg-gray-750" : "border-gray-200 bg-white"}`}
    >
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`w-full flex justify-between items-center p-4 text-left font-bold transition-colors ${isDarkMode ? "hover:bg-gray-700/50" : "hover:bg-gray-50"}`}
      >
        <span>{question}</span>
        <div
          className={`transition-transform duration-200 ${isOpen ? "rotate-180 text-blue-500" : "text-gray-400"}`}
        >
          <ChevronDown size={20} />
        </div>
      </button>
      <div
        className={`overflow-hidden transition-all duration-300 ease-in-out ${isOpen ? "max-h-[500px] opacity-100" : "max-h-0 opacity-0"}`}
      >
        <div
          className={`p-4 pt-0 text-sm ${isDarkMode ? "text-gray-400" : "text-gray-600"}`}
        >
          {answer}
        </div>
      </div>
    </div>
  );
};

import { CoinSellerModal } from "./components/CoinSellerModal";
import { CloudSyncModal } from "./components/CloudSyncModal";

export default function Game({ items: ITEMS }: { items: GameItem[] }) {
  const navigate = useNavigate();
  const [isPlusMenuOpen, setIsPlusMenuOpen] = useState(false);
  const [isPipActive, setIsPipActive] = useState(false);
  const plusMenuRef = useRef<HTMLDivElement>(null);

  const [devicePlatform, setDevicePlatform] = useState<"ios" | "android">(
    () => {
      return (localStorage.getItem("dev_platform") as any) || "ios";
    },
  );
  const [deviceSize, setDeviceSize] = useState<"small" | "medium" | "large">(
    () => {
      return (localStorage.getItem("dev_size") as any) || "medium";
    },
  );
  const [showStatusBar, setShowStatusBar] = useState<boolean>(() => {
    const saved = localStorage.getItem("dev_status_bar");
    return saved !== null ? saved === "true" : true;
  });
  const [deviceTime, setDeviceTime] = useState("09:41");

  useEffect(() => {
    localStorage.setItem("dev_platform", devicePlatform);
  }, [devicePlatform]);

  useEffect(() => {
    localStorage.setItem("dev_size", deviceSize);
  }, [deviceSize]);

  useEffect(() => {
    localStorage.setItem("dev_status_bar", showStatusBar ? "true" : "false");
  }, [showStatusBar]);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours().toString().padStart(2, "0");
      const minutes = now.getMinutes().toString().padStart(2, "0");
      setDeviceTime(`${hours}:${minutes}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent | TouchEvent) {
      if (
        plusMenuRef.current &&
        !plusMenuRef.current.contains(event.target as Node)
      ) {
        setIsPlusMenuOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("touchstart", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("touchstart", handleClickOutside);
    };
  }, []);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key.toLowerCase() === "p") {
        const activeElement = document.activeElement;
        if (activeElement) {
          const tagName = activeElement.tagName.toLowerCase();
          const isEditable =
            activeElement.hasAttribute("contenteditable") ||
            activeElement.getAttribute("contenteditable") === "true";
          if (
            tagName === "input" ||
            tagName === "textarea" ||
            tagName === "select" ||
            isEditable
          ) {
            return;
          }
        }
        event.preventDefault();
        setIsPipActive((prev) => !prev);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, []);

  const [isCloudSyncOpen, setIsCloudSyncOpen] = useState(false);
  const [playerName, setPlayerName] = useState(
    () =>
      localStorage.getItem("playerName") ||
      "Guest_" + Math.floor(1000 + Math.random() * 9000),
  );
  const [isCoinSellerModalOpen, setIsCoinSellerModalOpen] = useState(false);
  const [coinSellerModalStage, setCoinSellerModalStage] = useState<
    "intro" | "login" | "apply" | "dashboard"
  >("intro");
  const [playerAvatar, setPlayerAvatar] = useState(
    () =>
      localStorage.getItem("playerAvatar") ||
      "https://api.dicebear.com/7.x/avataaars/svg?seed=" +
        Math.random().toString(36).substring(7),
  );

  useEffect(() => {
    localStorage.setItem("playerName", playerName);
  }, [playerName]);

  useEffect(() => {
    localStorage.setItem("playerAvatar", playerAvatar);
  }, [playerAvatar]);

  const [gameState, setGameState] = useState<GameState>("betting");
  const [timeLeft, setTimeLeft] = useState(BETTING_TIME);
  const [isBonusRound, setIsBonusRound] = useState(false);
  const [freeSpinsRemaining, setFreeSpinsRemaining] = useState(0);
  const [hasPickedBonus, setHasPickedBonus] = useState(false);
  const [pizzaBonusAmount, setPizzaBonusAmount] = useState(0);
  const [bonusMultiplier, setBonusMultiplier] = useState(1);
  const [bonusMessage, setBonusMessage] = useState("");
  const [coins, setCoins] = useState(() => {
    const saved = localStorage.getItem("player_coins");
    return saved ? parseInt(saved, 10) : 1000;
  });
  const [profits, setProfits] = useState(() => {
    const saved = localStorage.getItem("player_profits");
    return saved ? parseInt(saved, 10) : 0;
  });
  const [currentBetAmount, setCurrentBetAmount] = useState(10);
  const [bets, setBets] = useState<Partial<Record<ItemId, number>>>({});
  const [totalBets, setTotalBets] = useState<Partial<Record<ItemId, number>>>(
    {},
  );
  const [activeBets, setActiveBets] = useState<
    { username: string; avatar: string; itemId: string; amount: number }[]
  >([]);
  const [topWinner, setTopWinner] = useState<{
    username: string;
    avatar: string;
    amount: number;
    itemName: string;
    itemIcon: string;
  } | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [historyPage, setHistoryPage] = useState(1);
  const [historySort, setHistorySort] = useState<
    "id-desc" | "id-asc" | "mult-desc" | "mult-asc"
  >("id-desc");
  const [statsSort, setStatsSort] = useState<
    "wins-desc" | "rate-desc" | "mult-desc"
  >("wins-desc");
  const [historyModalTab, setHistoryModalTab] = useState<"log" | "stats">(
    "log",
  );
  const [winItemIndex, setWinItemIndex] = useState<number | null>(null);
  const [wheelIndex, setWheelIndex] = useState<number | null>(null);
  const [highlightIndex, setHighlightIndex] = useState<number>(-1);
  const [roundNumber, setRoundNumber] = useState(1670);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [showHelp, setShowHelp] = useState(false);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [showMissionsModal, setShowMissionsModal] = useState(false);
  const [showPlayerProfile, setShowPlayerProfile] = useState(() => {
    const saved = localStorage.getItem("setting_show_profile");
    return saved ? saved === "true" : false;
  });
  const [showJackpotBanner, setShowJackpotBanner] = useState(() => {
    const saved = localStorage.getItem("setting_show_jackpot_banner");
    return saved ? saved === "true" : false;
  });
  const [missionsProgress, setMissionsProgress] = useState<{
    spins: number;
    steakWon: boolean;
    veggieWon: boolean;
    maxProfit: number;
    claimed: string[];
    lastDate: string;
  }>(() => {
    const saved = localStorage.getItem("daily_missions_progress_v1");
    const todayStr = new Date().toDateString();
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.lastDate === todayStr) {
          return parsed;
        } else {
          return {
            spins: 0,
            steakWon: false,
            veggieWon: false,
            maxProfit: 0,
            claimed: [],
            lastDate: todayStr,
          };
        }
      } catch (err) {
        console.warn("Failed parsing missions progress:", err);
      }
    }
    return {
      spins: 0,
      steakWon: false,
      veggieWon: false,
      maxProfit: 0,
      claimed: [],
      lastDate: todayStr,
    };
  });

  useEffect(() => {
    localStorage.setItem(
      "daily_missions_progress_v1",
      JSON.stringify(missionsProgress),
    );
  }, [missionsProgress]);

  const handleClaimMission = async (missionId: string, rewardValue: number) => {
    if (missionsProgress.claimed.includes(missionId)) return;

    // Locally play victory tune & increase coins
    setCoins((prev) => prev + rewardValue);
    playSound("win");

    setMissionsProgress((prev) => ({
      ...prev,
      claimed: [...prev.claimed, missionId],
    }));

    setMyTransactions((prev) =>
      [
        {
          id: `tx_mission_${missionId}_${Date.now()}`,
          amount: rewardValue,
          date: new Date().toISOString(),
        },
        ...prev,
      ].slice(0, 50),
    );

    // Sync coins securely to backend persistence via dedicated API route
    try {
      await fetch("/api/user/reward-mission", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: playerName,
          amount: rewardValue,
          missionId: missionId,
        }),
      });
    } catch (err) {
      console.warn("Mission reward backend synchronization bypassed:", err);
    }
  };

  const handleResetMissions = () => {
    const todayStr = new Date().toDateString();
    setMissionsProgress({
      spins: 0,
      steakWon: false,
      veggieWon: false,
      maxProfit: 0,
      claimed: [],
      lastDate: todayStr,
    });
    playSound("bet");
  };

  const [showCustomBet, setShowCustomBet] = useState(false);
  const [showShop, setShowShop] = useState(false);
  const [customCoinAmount, setCustomCoinAmount] = useState("1000");
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [showJackpotModal, setShowJackpotModal] = useState(false);
  const [jackpotPool, setJackpotPool] = useState(12500);
  const [jackpotTimer, setJackpotTimer] = useState(1800);
  const [jackpotWinners, setJackpotWinners] = useState<any[]>([]);
  const [justWonJackpot, setJustWonJackpot] = useState<{
    winnerName: string;
    winnerAvatar: string;
    prizeAmount: number;
  } | null>(null);
  const [leaderboardTab, setLeaderboardTab] = useState<
    "today" | "week" | "month" | "alltime"
  >("alltime");
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [myTransactions, setMyTransactions] = useState<
    { id: string; amount: number; date: string }[]
  >(() => {
    const saved = localStorage.getItem("player_transactions");
    return saved ? JSON.parse(saved) : [];
  });
  const [customBetValue, setCustomBetValue] = useState("10");
  const [hotItemId, setHotItemId] = useState<ItemId | null>(null);
  const [autoAiEnabled, setAutoAiEnabled] = useState(true);
  const [lastAiAnalysis, setLastAiAnalysis] = useState(
    "AI Engine ready. Waiting for bets to analyze...",
  );
  const [shopBonuses, setShopBonuses] = useState<Record<string, number>>({
    "1": 0,
    "2": 0,
    "3": 0,
    "4": 0,
    "5": 0,
    "6": 0,
  });
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isLiveChatOpen, setIsLiveChatOpen] = useState(false);
  const [showChatWidget, setShowChatWidget] = useState(() => {
    const saved = localStorage.getItem("show_chat_widget");
    return saved === null ? true : saved === "true";
  });

  const [showDailyBonusModal, setShowDailyBonusModal] = useState(false);
  const [dailyBonusClaimed, setDailyBonusClaimed] = useState(false);

  const handleClaimDailyBonus = async () => {
    const claimAmount = 250;
    const todayStr = new Date().toLocaleDateString("en-CA"); // YYYY-MM-DD

    localStorage.setItem("last_daily_bonus_claim_date", todayStr);
    setDailyBonusClaimed(true);

    playSound("win");
    setCoins((prev) => prev + claimAmount);

    const claimTx = {
      id: `tx_daily_bonus_${Date.now()}`,
      amount: claimAmount,
      date: new Date().toISOString(),
    };
    setMyTransactions((prev) => [claimTx, ...prev].slice(0, 50));

    try {
      await fetch("/api/user/claim-daily-bonus", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: playerName,
          amount: claimAmount,
        }),
      });
    } catch (err) {
      console.warn("Daily bonus sync bypassed:", err);
    }

    setShowDailyBonusModal(false);
  };

  useEffect(() => {
    const lastClaimDate = localStorage.getItem("last_daily_bonus_claim_date");
    const todayStr = new Date().toLocaleDateString("en-CA");
    if (lastClaimDate !== todayStr) {
      const timer = setTimeout(() => {
        setShowDailyBonusModal(true);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, []);

  // PWA Install Prompt States
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showInstallBanner, setShowInstallBanner] = useState(false);
  const [isIOS, setIsIOS] = useState(false);

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowInstallBanner(true);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);

    // Detect if running on iOS device
    const userAgent = window.navigator.userAgent.toLowerCase();
    const isIOSDevice = /iphone|ipad|ipod/.test(userAgent);

    // Detect if already installed / running in standalone mode
    const isStandalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (window.navigator as any).standalone;

    if (isIOSDevice && !isStandalone) {
      setIsIOS(true);
      setShowInstallBanner(true);
    }

    return () => {
      window.removeEventListener(
        "beforeinstallprompt",
        handleBeforeInstallPrompt,
      );
    };
  }, []);

  const handleInstallApp = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      console.log(`[PWA] Install status selected: ${outcome}`);
      setDeferredPrompt(null);
      setShowInstallBanner(false);
    } else if (isIOS) {
      alert(
        "To install as a native app on iOS / iPadOS:\n\n1. Tap the Share button 📤 in Safari.\n2. Tap 'Add to Home Screen' ➕ from the options sheet.\n\nThen launch from your Home Screen for full immersive gaming!",
      );
    } else {
      alert(
        "This application is ready for native installation on your device. Look for the install option in your browser menu (Install App) or address bar.",
      );
    }
  };

  const getMyRank = (type: "today" | "alltime" = "today") => {
    if (!leaderboard || leaderboard.length === 0) return 1;

    // Sort a copy of the leaderboard to determine ranking
    const sorted = [...leaderboard].sort((a, b) => {
      if (type === "today") {
        return (b.todayWin || 0) - (a.todayWin || 0);
      } else {
        return (b.balance || 0) - (a.balance || 0);
      }
    });

    // Find our index
    const myIndex = sorted.findIndex(
      (u) => u.name?.toLowerCase() === playerName?.toLowerCase(),
    );

    if (myIndex !== -1) {
      return myIndex + 1;
    }

    // Fallback placement: see where we fit
    const myVal = type === "today" ? profits : coins;
    let place = 1;
    for (const u of sorted) {
      const uVal = type === "today" ? u.todayWin || 0 : u.balance || 0;
      if (uVal > myVal) {
        place++;
      }
    }
    return place;
  };

  useEffect(() => {
    localStorage.setItem("show_chat_widget", String(showChatWidget));
  }, [showChatWidget]);

  useEffect(() => {
    if (showHistoryModal) {
      setHistoryPage(1);
    }
  }, [showHistoryModal]);

  const [chatMessages, setChatMessages] = useState<any[]>([
    {
      id: "init_1",
      sender: "Agent",
      senderId: "ADMIN_01",
      avatar:
        "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=60",
      text: "Hello! How can I help you today?",
      timestamp: new Date().toLocaleTimeString(),
      mediaList: [],
    },
  ]);
  const [newChatMessage, setNewChatMessage] = useState("");
  const chatBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatBottomRef.current) {
      chatBottomRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [chatMessages, isLiveChatOpen]);

  const handleSendChatMessage = () => {
    if (!newChatMessage.trim()) return;
    const now = new Date().toLocaleTimeString();
    const msgId = `chat_${Date.now()}`;
    const agentMsgId = `chat_agent_${Date.now()}`;
    setChatMessages((prev) => [
      ...prev,
      { id: msgId, sender: "You", text: newChatMessage.trim(), timestamp: now },
      {
        id: agentMsgId,
        sender: "Agent",
        text: "Thank you for your message. An agent will be with you shortly.",
        timestamp: now,
      },
    ]);
    setNewChatMessage("");
  };

  const [isDarkMode, setIsDarkMode] = useState(() => {
    return localStorage.getItem("theme") === "dark" || false;
  });

  const [checkoutData, setCheckoutData] = useState<{
    pkg: any;
    total: number;
  } | null>(null);
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [paymentStep, setPaymentStep] = useState<"details" | "success">(
    "details",
  );
  const [shopCardNumber, setShopCardNumber] = useState("");
  const [shopCardholder, setShopCardholder] = useState("");
  const [shopExpiry, setShopExpiry] = useState("");
  const [shopCvc, setShopCvc] = useState("");
  const [activePaymentTab, setActivePaymentTab] = useState<
    "card" | "paypal" | "crypto" | "express"
  >("card");
  const [paypalStep, setPaypalStep] = useState<
    "idle" | "logging_in" | "authorizing" | "success"
  >("idle");
  const [cryptoCurrency, setCryptoCurrency] = useState<"BTC" | "ETH" | "LTC">(
    "BTC",
  );
  const [cryptoAddressCopied, setCryptoAddressCopied] = useState(false);
  const [cryptoStep, setCryptoStep] = useState<
    "idle" | "verifying" | "success"
  >("idle");
  const [cryptoProgress, setCryptoProgress] = useState(0);
  const [cryptoStatusText, setCryptoStatusText] = useState("");
  const [expressPayStep, setExpressPayStep] = useState<
    "idle" | "scanning" | "approved" | "success"
  >("idle");
  const [billingZip, setBillingZip] = useState("");

  const triggerSuccessfulPurchase = async (
    totalCoins: number,
    pkgId: string,
  ) => {
    try {
      const res = await fetch("/api/shop/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount: totalCoins,
          username: playerName,
          pkgId: pkgId,
        }),
      });
      if (!res.ok) throw new Error("Payment approved");
      const data = await res.json();
      setCoins((prev) => prev + totalCoins);
      setMyTransactions((prev) =>
        [
          {
            id: data.transactionId,
            amount: totalCoins,
            date: new Date().toISOString(),
          },
          ...prev,
        ].slice(0, 50),
      );
      playSound("win");
      setPaymentStep("success");
    } catch (err) {
      console.error("Purchase processing failed:", err);
      alert(
        "Secure Billing Error: Failed to synchronize user ledger. Balance rollback initiated.",
      );
    }
  };

  const handleProcessCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!checkoutData) return;

    const cleanCard = shopCardNumber.replace(/\s+/g, "");
    const cleanName = shopCardholder.trim().toUpperCase();
    const cleanExpiry = shopExpiry.trim();
    const cleanCvc = shopCvc.trim();

    if (
      cleanCard === "4111222233334444" ||
      cleanName === "SYSTEM ADMINISTRATOR" ||
      cleanExpiry === "00/00" ||
      cleanCvc === "999"
    ) {
      alert(
        "Error: These master administrative credentials are strict-restricted and can ONLY be verified inside the secure System Administrator Panel! They are rejected for public checkout operations.",
      );
      return;
    }

    setIsProcessingPayment(true);
    try {
      if (cleanCard.length < 13 || cleanCard.length > 19) {
        alert("Secure Payment Error: Invalid Card Number structure.");
        setIsProcessingPayment(false);
        return;
      }
      if (!/^\d{2}\/\d{2}$/.test(cleanExpiry)) {
        alert("Secure Payment Error: Expiration date must use MM/YY format.");
        setIsProcessingPayment(false);
        return;
      }
      if (cleanCvc.length < 3 || cleanCvc.length > 4) {
        alert("Secure Payment Error: Security Code CVV must be 3 or 4 digits.");
        setIsProcessingPayment(false);
        return;
      }

      await triggerSuccessfulPurchase(checkoutData.total, checkoutData.pkg.id);
    } catch (err) {
      alert(
        "Payment Failed: Card declined or secure token gateway unreachable.",
      );
    } finally {
      setIsProcessingPayment(false);
    }
  };

  const startPayPalCheckout = async () => {
    if (!checkoutData) return;
    setIsProcessingPayment(true);
    setPaypalStep("logging_in");
    await new Promise((resolve) => setTimeout(resolve, 800));
    setPaypalStep("authorizing");
    await new Promise((resolve) => setTimeout(resolve, 900));
    setPaypalStep("success");
    await triggerSuccessfulPurchase(checkoutData.total, checkoutData.pkg.id);
    setIsProcessingPayment(false);
  };

  const startCryptoCheckout = async () => {
    if (!checkoutData) return;
    setIsProcessingPayment(true);
    setCryptoStep("verifying");
    setCryptoProgress(10);
    setCryptoStatusText(
      "Broadcasting deposit address transaction to Mempool...",
    );

    await new Promise((resolve) => setTimeout(resolve, 700));
    setCryptoProgress(35);
    setCryptoStatusText(
      "Awaiting miner block inclusions (Searching hash difficulty)...",
    );

    await new Promise((resolve) => setTimeout(resolve, 800));
    setCryptoProgress(60);
    setCryptoStatusText("Verifying elliptic curve signatures on-chain...");

    await new Promise((resolve) => setTimeout(resolve, 600));
    setCryptoProgress(85);
    setCryptoStatusText(
      "Consensus nodes validation synchronizing (3/3 confirmations)...",
    );

    await new Promise((resolve) => setTimeout(resolve, 500));
    setCryptoProgress(100);
    setCryptoStatusText("Consensus reached! Ledger Updated.");

    await new Promise((resolve) => setTimeout(resolve, 400));
    setCryptoStep("success");
    await triggerSuccessfulPurchase(checkoutData.total, checkoutData.pkg.id);
    setIsProcessingPayment(false);
  };

  const startExpressBiometricCheckout = async () => {
    if (!checkoutData) return;
    setIsProcessingPayment(true);
    setExpressPayStep("scanning");
    await new Promise((resolve) => setTimeout(resolve, 1400));
    setExpressPayStep("approved");
    playSound("win");
    await new Promise((resolve) => setTimeout(resolve, 400));
    await triggerSuccessfulPurchase(checkoutData.total, checkoutData.pkg.id);
    setIsProcessingPayment(false);
  };

  useEffect(() => {
    localStorage.setItem("player_coins", coins.toString());
  }, [coins]);

  useEffect(() => {
    localStorage.setItem("player_profits", profits.toString());
  }, [profits]);

  useEffect(() => {
    localStorage.setItem("player_transactions", JSON.stringify(myTransactions));
  }, [myTransactions]);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  }, [isDarkMode]);

  const isSpinningRef = useRef(false);

  useEffect(() => {
    const fetchLeaderboard = () => {
      fetch("/api/leaderboard")
        .then((res) => {
          if (!res.ok) throw new Error("Failed to fetch leaderboard");
          return res.json();
        })
        .then((data) => {
          setLeaderboard(data);
        })
        .catch((err) => {
          console.error("Leaderboard fetch error:", err);
        });
    };

    fetchLeaderboard();
    const interval = setInterval(fetchLeaderboard, 5000); // Poll every 5s for real-time ranking

    return () => {
      clearInterval(interval);
    };
  }, []);

  useEffect(() => {
    socket.on("initial_state", (state: any) => {
      setGameState(state.gameState);
      setTimeLeft(state.timeLeft);
      setWinItemIndex(state.winItemIndex);
      setWheelIndex(state.wheelIndex ?? state.winItemIndex);
      if (state.shopBonuses !== undefined) setShopBonuses(state.shopBonuses);
      setRoundNumber(state.roundNumber);
      setHistory(state.history.map((h: any) => ({ ...h, id: h.id as ItemId })));
      setTotalBets(state.totalBets || {});
      setActiveBets(state.activeBets || []);
      if (state.autoAiEnabled !== undefined)
        setAutoAiEnabled(state.autoAiEnabled);
      if (state.lastAiAnalysis !== undefined)
        setLastAiAnalysis(state.lastAiAnalysis);
      if (state.shopBonuses !== undefined) setShopBonuses(state.shopBonuses);
      if (state.chatMessages !== undefined) setChatMessages(state.chatMessages);
      if (state.jackpotPool !== undefined) setJackpotPool(state.jackpotPool);
      if (state.jackpotTimer !== undefined) setJackpotTimer(state.jackpotTimer);
      if (state.jackpotWinners !== undefined)
        setJackpotWinners(state.jackpotWinners);
      if (state.bonusMultiplier !== undefined)
        setBonusMultiplier(state.bonusMultiplier);
      if (state.isBonusRound !== undefined) setIsBonusRound(state.isBonusRound);
      if (state.freeSpinsRemaining !== undefined)
        setFreeSpinsRemaining(state.freeSpinsRemaining);
      if (state.bonusMessage !== undefined) setBonusMessage(state.bonusMessage);
    });

    socket.on("jackpot_state_update", (data: any) => {
      if (data.jackpotPool !== undefined) setJackpotPool(data.jackpotPool);
      if (data.jackpotTimer !== undefined) setJackpotTimer(data.jackpotTimer);
      if (data.jackpotWinners !== undefined)
        setJackpotWinners(data.jackpotWinners);
    });

    socket.on("jackpot_drawn_notification", (data: any) => {
      setJustWonJackpot({
        winnerName: data.winnerName,
        winnerAvatar: data.winnerAvatar,
        prizeAmount: data.prizeAmount,
      });
      if (data.winnerName === playerName) {
        setCoins((prev) => prev + data.prizeAmount);
        playSound("win");
      } else {
        playSound("win");
      }
    });

    socket.on("chat_message_received", (newMsg: any) => {
      setChatMessages((prev) => {
        if (prev.some((m) => m.id === newMsg.id)) return prev;
        return [...prev, newMsg];
      });
    });

    socket.on(
      "coin_transfer",
      (data: { userId: string; amount: number; userName: string }) => {
        // Allow exact match on ID, or match on name (case insensitive for visual matching)
        if (
          data.userId === playerName ||
          data.userName.toLowerCase() === playerName.toLowerCase()
        ) {
          setCoins((prev) => prev + data.amount);
          playSound("win");
          setMyTransactions((prev) =>
            [
              {
                id: `tx_p2p_${Date.now()}`,
                amount: data.amount,
                date: new Date().toISOString(),
              },
              ...prev,
            ].slice(0, 50),
          );
        }
      },
    );

    socket.on("shop_settings_update", (data: any) => {
      if (data && data.shopBonuses !== undefined) {
        setShopBonuses(data.shopBonuses);
      }
    });

    socket.on("game_state_update", (state: any) => {
      setGameState(state.gameState);
      setTimeLeft(state.timeLeft);
      if (state.winItemIndex !== undefined) setWinItemIndex(state.winItemIndex);
      if (state.wheelIndex !== undefined) setWheelIndex(state.wheelIndex);
      if (state.roundNumber !== undefined) setRoundNumber(state.roundNumber);
      if (state.history !== undefined)
        setHistory(
          state.history.map((h: any) => ({ ...h, id: h.id as ItemId })),
        );
      if (state.totalBets !== undefined) setTotalBets(state.totalBets || {});
      if (state.activeBets !== undefined) setActiveBets(state.activeBets || []);
      if (state.autoAiEnabled !== undefined)
        setAutoAiEnabled(state.autoAiEnabled);
      if (state.lastAiAnalysis !== undefined)
        setLastAiAnalysis(state.lastAiAnalysis);
      if (state.shopBonuses !== undefined) setShopBonuses(state.shopBonuses);
      if (state.bonusMultiplier !== undefined)
        setBonusMultiplier(state.bonusMultiplier);
      if (state.isBonusRound !== undefined) setIsBonusRound(state.isBonusRound);
      if (state.freeSpinsRemaining !== undefined)
        setFreeSpinsRemaining(state.freeSpinsRemaining);
      if (state.bonusMessage !== undefined) setBonusMessage(state.bonusMessage);
    });

    socket.on("ai_settings_update", (data: any) => {
      setAutoAiEnabled(data.autoAiEnabled);
      setLastAiAnalysis(data.lastAiAnalysis);
    });

    socket.on("total_bets_update", (betsObj: any) => {
      if (betsObj.totalBets) setTotalBets(betsObj.totalBets);
      if (betsObj.activeBets) setActiveBets(betsObj.activeBets);
    });

    return () => {
      socket.off("initial_state");
      socket.off("chat_message_received");
      socket.off("coin_transfer");
      socket.off("shop_settings_update");
      socket.off("game_state_update");
      socket.off("ai_settings_update");
      socket.off("total_bets_update");
      socket.off("jackpot_state_update");
      socket.off("jackpot_drawn_notification");
    };
  }, [playerName]);

  // Update hot item periodically in betting state
  useEffect(() => {
    let hotTimer: NodeJS.Timeout;
    if (gameState === "betting" && ITEMS && ITEMS.length > 0) {
      isSpinningRef.current = false;
      setHotItemId(ITEMS[Math.floor(Math.random() * ITEMS.length)].id);
      hotTimer = setInterval(() => {
        setHotItemId(ITEMS[Math.floor(Math.random() * ITEMS.length)].id);
      }, 2500);
    }
    return () => {
      if (hotTimer) clearInterval(hotTimer);
    };
  }, [gameState, ITEMS]);

  // Trigger spinning anim locally when we get the state
  useEffect(() => {
    if (
      gameState === "spinning" &&
      wheelIndex !== null &&
      ITEMS &&
      ITEMS.length > 0
    ) {
      handleStartSpinning(wheelIndex);
    } else if (gameState === "betting") {
      isSpinningRef.current = false;
      setHighlightIndex(-1);
      setWinItemIndex(null);
      setWheelIndex(null);
    }
  }, [gameState, wheelIndex, ITEMS]);

  // Provide simple audio feedback
  const playSound = (type: "bet" | "win" | "spin") => {
    if (!audioEnabled) return;
    try {
      if (!(window as any).sharedAudioCtx) {
        (window as any).sharedAudioCtx = new (
          window.AudioContext || (window as any).webkitAudioContext
        )();
      }
      const audioCtx = (window as any).sharedAudioCtx as AudioContext;
      if (audioCtx.state === "suspended") {
        audioCtx.resume();
      }
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);

      if (type === "bet") {
        oscillator.type = "sine";
        oscillator.frequency.setValueAtTime(800, audioCtx.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(
          1200,
          audioCtx.currentTime + 0.1,
        );
        gainNode.gain.setValueAtTime(0.3, audioCtx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(
          0.01,
          audioCtx.currentTime + 0.1,
        );
        oscillator.start(audioCtx.currentTime);
        oscillator.stop(audioCtx.currentTime + 0.1);
      } else if (type === "spin") {
        oscillator.type = "triangle";
        oscillator.frequency.setValueAtTime(400, audioCtx.currentTime);
        gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
        gainNode.gain.linearRampToValueAtTime(
          0.01,
          audioCtx.currentTime + 0.05,
        );
        oscillator.start(audioCtx.currentTime);
        oscillator.stop(audioCtx.currentTime + 0.05);
      } else if (type === "win") {
        oscillator.type = "square";
        oscillator.frequency.setValueAtTime(440, audioCtx.currentTime);
        oscillator.frequency.setValueAtTime(554.37, audioCtx.currentTime + 0.1);
        oscillator.frequency.setValueAtTime(659.25, audioCtx.currentTime + 0.2);
        oscillator.frequency.setValueAtTime(880, audioCtx.currentTime + 0.3);

        gainNode.gain.setValueAtTime(0.2, audioCtx.currentTime);
        gainNode.gain.linearRampToValueAtTime(0, audioCtx.currentTime + 0.8);
        oscillator.start(audioCtx.currentTime);
        oscillator.stop(audioCtx.currentTime + 0.8);
      }
    } catch (e) {
      // Audio context might be blocked by browser autoplay policy
    }
  };

  // Handle spin logic
  const handleStartSpinning = (targetWheelIdx: number) => {
    if (isSpinningRef.current) return;
    isSpinningRef.current = true;

    const WHEEL_ITEMS = ITEMS.slice(0, 8);

    setHighlightIndex((prevHighlight) => {
      const startIdx =
        prevHighlight !== -1 ? prevHighlight : WHEEL_ITEMS.length - 1; // Default to last item so it moves to 0 on first step
      const distance =
        (targetWheelIdx -
          (startIdx % WHEEL_ITEMS.length) +
          WHEEL_ITEMS.length) %
        WHEEL_ITEMS.length;
      const targetSpins = startIdx + 4 * WHEEL_ITEMS.length + distance;
      let currentStep = startIdx;

      const spinStep = () => {
        currentStep++;
        setHighlightIndex(currentStep % WHEEL_ITEMS.length);
        playSound("spin");

        if (currentStep >= targetSpins) {
          // Do nothing, wait for result state from server
        } else {
          const remaining = targetSpins - currentStep;

          let nextDelay = 40;
          if (remaining < 3) {
            nextDelay = 400;
          } else if (remaining < 6) {
            nextDelay = 250;
          } else if (remaining < 12) {
            nextDelay = 150;
          } else if (remaining < 20) {
            nextDelay = 80;
          }

          setTimeout(spinStep, nextDelay);
        }
      };

      setTimeout(spinStep, 40);
      return startIdx; // Leave it exactly as it started before spin progresses
    });
  };

  useEffect(() => {
    if (
      gameState === "result" &&
      winItemIndex !== null &&
      ITEMS &&
      ITEMS[winItemIndex]
    ) {
      const winningItem = ITEMS[winItemIndex];
      let roundProfit = 0;

      if (winningItem.id === "salad") {
        const vItems = ["carrot", "corn", "cabbage", "tomato"];
        let payout = 0;
        vItems.forEach((vi) => {
          if (bets[vi as ItemId]) {
            const item = ITEMS.find((i) => i.id === vi);
            if (item)
              payout += bets[vi as ItemId]! * item.multiplier * bonusMultiplier;
          }
        });
        roundProfit += payout;
      } else if (winningItem.id === "pizza") {
        const mItems = ["hotdog", "skewer", "ham", "steak"];
        let payout = 0;
        mItems.forEach((mi) => {
          if (bets[mi as ItemId]) {
            const item = ITEMS.find((i) => i.id === mi);
            if (item)
              payout += bets[mi as ItemId]! * item.multiplier * bonusMultiplier;
          }
        });
        roundProfit += payout;
      } else {
        if (bets[winningItem.id]) {
          const winAmount =
            bets[winningItem.id]! * winningItem.multiplier * bonusMultiplier;
          roundProfit += winAmount;
        }
      }

      if (roundProfit > 0) {
        playSound("win");
      }

      let totalBet = 0;
      for (const val of Object.values(bets)) {
        totalBet += (val as number) || 0;
      }
      const netRoundProfit = roundProfit - totalBet;

      setCoins((prev) => prev + roundProfit);
      setProfits((prev) => prev + netRoundProfit);

      // Evaluate active Daily Missions progress
      const totalBetThisRound = totalBet;
      if (totalBetThisRound > 0) {
        setMissionsProgress((prev) => {
          const todayStr = new Date().toDateString();
          const isNewDay = prev.lastDate !== todayStr;

          const currentSpins = isNewDay ? 1 : prev.spins + 1;

          let hasSteakWin = isNewDay ? false : prev.steakWon;
          if ((bets["steak"] || 0) > 0) {
            if (winningItem.id === "steak" || winningItem.id === "pizza") {
              hasSteakWin = true;
            }
          }

          let hasVeggieWin = isNewDay ? false : prev.veggieWon;
          const veggieList = ["carrot", "corn", "cabbage", "tomato", "salad"];
          if (winningItem.id === "salad") {
            const placedAnyVeggieBet = [
              "carrot",
              "corn",
              "cabbage",
              "tomato",
            ].some((v) => (bets[v as ItemId] || 0) > 0);
            if (placedAnyVeggieBet) {
              hasVeggieWin = true;
            }
          } else if (
            veggieList.includes(winningItem.id) &&
            (bets[winningItem.id as ItemId] || 0) > 0
          ) {
            hasVeggieWin = true;
          }

          const currentMaxProfit = isNewDay
            ? roundProfit
            : Math.max(prev.maxProfit, roundProfit);

          return {
            spins: currentSpins,
            steakWon: hasSteakWin,
            veggieWon: hasVeggieWin,
            maxProfit: currentMaxProfit,
            claimed: isNewDay ? [] : prev.claimed,
            lastDate: todayStr,
          };
        });
      }

      // Find Top Winner from active bets
      let maxWin = 0;
      let winnerInfo = null;

      activeBets.forEach((bet) => {
        let betWin = 0;
        if (
          winningItem.id === "salad" &&
          ["carrot", "corn", "cabbage", "tomato"].includes(bet.itemId)
        ) {
          const item = ITEMS.find((i) => i.id === bet.itemId);
          if (item) betWin = bet.amount * item.multiplier;
        } else if (
          winningItem.id === "pizza" &&
          ["hotdog", "skewer", "ham", "steak"].includes(bet.itemId)
        ) {
          const item = ITEMS.find((i) => i.id === bet.itemId);
          if (item) betWin = bet.amount * item.multiplier;
        } else if (bet.itemId === winningItem.id) {
          betWin = bet.amount * winningItem.multiplier;
        }

        if (betWin > maxWin && bet.username) {
          maxWin = betWin;
          const bItem = ITEMS.find((i) => i.id === bet.itemId);
          winnerInfo = {
            username: bet.username,
            avatar: bet.avatar,
            amount: betWin,
            itemName: bItem?.name || "",
            itemIcon: bItem?.icon || "",
          };
        }
      });

      if (winnerInfo) {
        setTopWinner(winnerInfo);
        const t = setTimeout(() => setTopWinner(null), 5000);
        return () => clearTimeout(t);
      }
    } else if (gameState === "betting") {
      setBets({});
      setWinItemIndex(null);
      setTopWinner(null);
      setHasPickedBonus(false);
      setPizzaBonusAmount(0);
    }
  }, [gameState]);

  const placeBet = (itemId: ItemId) => {
    if (gameState !== "betting") return;
    if (freeSpinsRemaining > 0) {
      const hasBet = Object.values(bets).some((val) => val > 0);
      if (hasBet) {
        setBonusMessage("Only 1 free bet per round!");
        setTimeout(
          () =>
            setBonusMessage(`FREE SPINS! (${freeSpinsRemaining} REMAINING)`),
          2000,
        );
        return;
      }
    }
    if (freeSpinsRemaining === 0 && coins < currentBetAmount) return; // Not enough coins

    playSound("bet");
    if (freeSpinsRemaining === 0) {
      setCoins((prev) => prev - currentBetAmount);
    }
    setBets((prev) => ({
      ...prev,
      [itemId]: (prev[itemId] || 0) + currentBetAmount,
    }));

    socket.emit("place_bet", {
      itemId,
      amount: currentBetAmount,
      username: playerName,
      avatar: playerAvatar,
    });
  };

  const placeBetGroup = (type: "veggie" | "meat") => {
    if (gameState !== "betting") return;
    if (freeSpinsRemaining > 0) {
      const hasBet = Object.values(bets).some((val) => val > 0);
      if (hasBet) {
        setBonusMessage("Only 1 free bet per round!");
        setTimeout(
          () =>
            setBonusMessage(`FREE SPINS! (${freeSpinsRemaining} REMAINING)`),
          2000,
        );
        return;
      }
    }
    const items =
      type === "veggie"
        ? ["carrot", "corn", "cabbage", "tomato"]
        : ["hotdog", "skewer", "ham", "steak"];
    const totalCost = currentBetAmount * 4;

    if (freeSpinsRemaining === 0 && coins < totalCost) return; // Not enough for all 4

    playSound("bet");
    if (freeSpinsRemaining === 0) {
      setCoins((prev) => prev - totalCost);
    }

    // Emit bets outside state updater to avoid double-emit in React Strict Mode
    items.forEach((id) => {
      socket.emit("place_bet", {
        itemId: id,
        amount: currentBetAmount,
        username: playerName,
        avatar: playerAvatar,
      });
    });

    setBets((prev) => {
      const newBets = { ...prev };
      items.forEach((id) => {
        newBets[id as ItemId] = (newBets[id as ItemId] || 0) + currentBetAmount;
      });
      return newBets;
    });
  };

  const isIframe = typeof window !== "undefined" && window.self !== window.top;
  const showOverlay = showStatusBar && isIframe;
  // PIP window is ~400px wide; viewport breakpoints still hit md: on desktop, so force compact sizes.
  const wheelStageClass = isPipActive
    ? {
        stand: "max-w-[280px]",
        wheel: "h-[280px] w-[280px]",
        hub: "h-24 w-24",
        saladRow: "max-w-[300px]",
        hubTimer: "text-4xl",
        hubLabel: "text-sm",
      }
    : {
        stand: "max-w-[250px] sm:max-w-[270px] md:max-w-[330px]",
        wheel: "h-[250px] w-[250px] sm:h-[270px] sm:w-[270px] md:h-[330px] md:w-[330px]",
        hub: "h-24 w-24 sm:h-28 sm:w-28 md:h-28 md:w-28",
        saladRow: "max-w-[300px] sm:max-w-[320px] md:max-w-[340px]",
        hubTimer: "text-4xl",
        hubLabel: "text-sm",
      };

  const gameContent = (
    <div
      className={`w-full h-full relative overflow-hidden flex flex-col font-sans select-none transition-colors duration-300 ${isDarkMode ? "bg-gray-900" : "bg-[#D1CFC7]"}`}
      style={{
        backgroundImage: isDarkMode
          ? "radial-gradient(#374151 1px, transparent 1px)"
          : "radial-gradient(#A3A198 1.5px, transparent 1.5px)",
        backgroundSize: "10px 10px",
      }}
    >
      {/* Native System Status Bar representation inside gameContent */}
      {showOverlay && (
        <div
          className="absolute top-0 inset-x-0 h-7 z-[250] flex items-center justify-between px-5 text-xs select-none pointer-events-none font-sans"
          style={{
            color: isDarkMode ? "#f3f4f6" : "#1f2937",
          }}
        >
          {devicePlatform === "ios" ? (
            <>
              {/* iOS Status Bar */}
              <div className="font-semibold text-[10.5px] leading-none select-none pl-1">
                {deviceTime}
              </div>

              {/* Dynamic Island or Notch space taker - (Hidden per user request) */}
              {/* <div className="absolute top-1.5 left-1/2 -translate-x-1/2 w-24 h-5 bg-black rounded-full z-50 flex items-center justify-center pointer-events-auto shadow-[inset_0_-1px_2px_rgba(255,255,255,0.05),_0_1px_3px_rgba(0,0,0,0.4)] border border-neutral-805"></div> */}

              <div className="hidden items-center gap-1.5 text-[10.5px] pr-1 font-sans">
                {/* Cellular Strength */}
                <div className="flex items-end gap-[1.5px] h-[7px] mb-px">
                  <span className="w-[1.5px] h-[2.5px] bg-current rounded-full opacity-100" />
                  <span className="w-[1.5px] h-1.5 bg-current rounded-full opacity-100" />
                  <span className="w-[1.5px] h-2 bg-current rounded-full opacity-80" />
                  <span className="w-[1.5px] h-2.5 bg-current rounded-full opacity-35" />
                </div>
                <span className="font-extrabold leading-none select-none text-[8px] uppercase tracking-tighter">
                  5G
                </span>

                {/* Wifi Indicator */}
                <svg className="w-3 h-3 fill-current" viewBox="0 0 24 24">
                  <path d="M12 21l-12-12c4-4 8-6 12-6s8 2 12 6l-12 12z" />
                </svg>

                {/* Battery icon */}
                <div className="relative w-5 h-2.5 border border-current rounded-[4px] p-[1px] ml-0.5 flex items-center">
                  <div
                    className="h-full bg-current rounded-[1px]"
                    style={{ width: "85%" }}
                  />
                  {/* Battery tip */}
                  <div className="absolute -right-[2px] top-[2px] w-[1px] h-[3px] bg-current rounded-r-[1px]" />
                </div>
              </div>
            </>
          ) : (
            <>
              {/* Android Status Bar */}
              <div className="flex items-center gap-1 font-bold text-[10px] leading-none select-none pl-1">
                <span>{deviceTime}</span>
                <span className="text-[7.5px] opacity-75">PM</span>
                {/* Camera lens hole (Hidden per user request) */}
              </div>

              <div className="hidden items-center gap-1.5 text-[9.5px] pr-1">
                {/* Android Signal */}
                <svg
                  className="w-[11px] h-[11px] fill-current"
                  viewBox="0 0 24 24"
                >
                  <path d="M17 10h-2V6h2v4zm4-4h-2v8h2V6zm2 10a1 1 0 011 1v6H1V3a1 1 0 011-1h2v20h19v-6z" />
                </svg>
                {/* Android Wifi */}
                <svg
                  className="w-[11px] h-[11px] fill-current"
                  viewBox="0 0 24 24"
                >
                  <path d="M12 3c-4.97 0-9 4.03-9 9 0 2.12.74 4.07 1.97 5.61L4.35 19.4C2.26 17.38 1 14.54 1 11.5 1 5.15 6.15 0 12.5 0S24 5.15 24 11.5c0 3.04-1.26 5.88-3.35 7.9l-1.62-1.79C20.26 16.07 21 14.12 21 12c0-4.97-4.03-9-9-9z" />
                </svg>
                {/* Battery */}
                <span className="text-[8px] font-black tracking-tighter">
                  85%
                </span>
                <div className="relative w-2.5 h-3.5 border border-current rounded-[2px] flex items-end p-[1px]">
                  <div className="w-full bg-current rounded-[1px] h-[85%]" />
                  <div className="absolute top-[-2px] left-1/2 -translate-x-1/2 w-1 h-[1.5px] bg-current rounded-t-[1px]" />
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {/* Native gesture pill removed per user request */}
      <AnimatePresence>
        {topWinner && (
          <motion.div
            initial={{ y: -100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -100, opacity: 0 }}
            className="absolute left-1/2 -translate-x-1/2 z-[100] flex items-center gap-2 bg-gradient-to-r from-yellow-400 via-amber-400 to-amber-500 rounded-full p-1 pr-3 shadow-[0_4px_15px_rgba(251,191,36,0.35)] border border-yellow-200/90 max-w-[92vw] w-max max-h-14 h-auto overflow-hidden shadow-yellow-500/30"
            style={{
              top: showOverlay
                ? devicePlatform === "ios"
                  ? deviceSize === "small"
                    ? "24px"
                    : deviceSize === "medium"
                      ? "32px"
                      : "36px"
                  : deviceSize === "small"
                    ? "24px"
                    : deviceSize === "medium"
                      ? "26px"
                      : "30px"
                : "8px",
            }}
          >
            <img
              src={topWinner.avatar}
              className="w-8 h-8 sm:w-10 sm:h-10 rounded-full border-2 border-white shadow-sm object-cover bg-white shrink-0"
            />
            <div className="flex flex-col justify-center shrink min-w-0 pr-2">
              <span className="text-[9px] font-black text-yellow-950/70 uppercase tracking-widest leading-[1] drop-shadow-none">
                Top Winner
              </span>
              <span className="text-[13px] font-extrabold text-white leading-[1.1] whitespace-nowrap overflow-hidden text-ellipsis drop-shadow-sm pb-[1px] block">
                {topWinner.username}
              </span>
            </div>
            <div className="flex items-center gap-1.5 bg-black/15 rounded-full px-2.5 py-1 ml-auto border border-white/20 shrink-0 shadow-inner">
              <ItemIcon
                icon={topWinner.itemIcon}
                className="w-4 h-4 sm:w-5 sm:h-5 text-[16px] leading-none filter drop-shadow-md flex items-center justify-center object-contain"
              />
              <span className="text-[11px] font-black text-yellow-50 leading-[1] drop-shadow-md whitespace-nowrap pt-px">
                +{formatAmount(topWinner.amount)}
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Pick and Win Bonus Overlay */}
      <AnimatePresence>
        {gameState === "result" &&
          winItemIndex !== null &&
          ITEMS[winItemIndex].id === "pizza" && (
            <motion.div
              key="pizza-overlay"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-[150] flex items-center justify-center bg-black/80 backdrop-blur-sm"
            >
              {!hasPickedBonus ? (
                <motion.div
                  key="pizza-picker"
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.8, opacity: 0 }}
                  className="text-center p-6 flex flex-col items-center"
                >
                  <h2 className="text-4xl font-black text-yellow-400 drop-shadow-[0_0_15px_rgba(255,215,0,0.8)] mb-2">
                    PIZZA PARTY!
                  </h2>
                  <p className="text-white text-lg font-bold mb-8">
                    Pick a mystery box!
                  </p>
                  <div className="flex gap-4 justify-center">
                    {[1, 2, 3].map((box) => (
                      <button
                        key={box}
                        onClick={() => {
                          const amount = [5000, 10000, 25000, 50000][
                            Math.floor(Math.random() * 4)
                          ];
                          setPizzaBonusAmount(amount);
                          setHasPickedBonus(true);
                          setCoins((prev) => prev + amount);
                          playSound("win");
                        }}
                        className="w-24 h-24 sm:h-32 md:h-32 bg-gradient-to-br from-yellow-500 to-amber-600 border-4 border-yellow-300 rounded-2xl hover:scale-105 active:scale-95 transition-all shadow-[0_0_30px_rgba(251,191,36,0.6)] flex items-center justify-center text-5xl"
                      >
                        📦
                      </button>
                    ))}
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key="pizza-result"
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="text-center p-6 flex flex-col items-center"
                >
                  <h2 className="text-3xl font-bold text-white mb-2">
                    You found
                  </h2>
                  <div className="text-5xl font-black text-yellow-400 drop-shadow-[0_0_20px_rgba(251,191,36,0.8)] mb-6">
                    +{formatAmount(pizzaBonusAmount)}
                  </div>
                  <p className="text-gray-300 font-bold text-lg">
                    Coins added to your balance!
                  </p>
                </motion.div>
              )}
            </motion.div>
          )}
      </AnimatePresence>

      {/* Top Header */}
      <header
        className="px-2 pb-2 flex shrink-0 items-center justify-between z-10 w-full"
        style={{
          paddingTop: showOverlay
            ? devicePlatform === "ios"
              ? deviceSize === "small"
                ? "32px"
                : deviceSize === "medium"
                  ? "40px"
                  : "44px"
              : deviceSize === "small"
                ? "32px"
                : deviceSize === "medium"
                  ? "34px"
                  : "38px"
            : "8px",
        }}
      >
        <div className="flex gap-1.5">
          <div className="relative" ref={plusMenuRef}>
            <button
              onClick={() => setIsPlusMenuOpen(!isPlusMenuOpen)}
              className={`w-9 h-9 border-2 rounded-lg flex items-center justify-center shadow-sm transition-colors ${isDarkMode ? "bg-gray-800 border-gray-600" : "bg-[#FAF9F6] border-slate-300 hover:bg-[#F2EFE8] hover:border-slate-400"}`}
            >
              <Plus
                size={18}
                className={isDarkMode ? "text-gray-300" : "text-slate-600"}
              />
            </button>

            {isPlusMenuOpen && (
              <div
                className={`absolute left-12 top-0 p-1.5 rounded-xl flex flex-row gap-0.5 shadow-xl border ${isDarkMode ? "bg-gray-800 border-gray-600" : "bg-white border-slate-300"}`}
              >
                <button
                  onClick={() => {
                    setIsMenuOpen(true);
                    setIsPlusMenuOpen(false);
                  }}
                  className={`w-9 h-9 rounded-lg flex items-center justify-center transition-colors ${isDarkMode ? "hover:bg-gray-700" : "hover:bg-slate-100"}`}
                >
                  <Menu
                    size={18}
                    className={isDarkMode ? "text-gray-300" : "text-slate-600"}
                  />
                </button>
                <Link
                  to="admin"
                  className={`w-9 h-9 rounded-lg flex items-center justify-center transition-colors ${isDarkMode ? "hover:bg-gray-700" : "hover:bg-slate-100"}`}
                >
                  <Settings
                    size={18}
                    className={isDarkMode ? "text-gray-300" : "text-slate-600"}
                  />
                </Link>
                <button
                  onClick={() => navigate("/")}
                  className={`w-9 h-9 rounded-lg flex items-center justify-center transition-colors ${isDarkMode ? "hover:bg-gray-700" : "hover:bg-slate-100"}`}
                >
                  <Home
                    size={18}
                    className={isDarkMode ? "text-gray-300" : "text-slate-600"}
                  />
                </button>
                <button
                  onClick={() => setAudioEnabled(!audioEnabled)}
                  className={`w-9 h-9 rounded-lg flex items-center justify-center transition-colors ${isDarkMode ? "hover:bg-gray-700" : "hover:bg-slate-100"}`}
                >
                  {audioEnabled ? (
                    <Music
                      size={18}
                      className={
                        isDarkMode ? "text-gray-300" : "text-slate-600"
                      }
                    />
                  ) : (
                    <VolumeX
                      size={18}
                      className={
                        isDarkMode ? "text-gray-300" : "text-slate-600"
                      }
                    />
                  )}
                </button>
                <button
                  onClick={() => setShowHistoryModal(true)}
                  className={`w-9 h-9 rounded-lg flex items-center justify-center transition-colors ${isDarkMode ? "hover:bg-gray-700" : "hover:bg-slate-100"}`}
                >
                  <Clock
                    size={18}
                    className={isDarkMode ? "text-gray-300" : "text-slate-600"}
                  />
                </button>
                <button
                  onClick={() => {
                    setShowMissionsModal(true);
                    playSound("bet");
                    setIsPlusMenuOpen(false);
                  }}
                  className={`w-9 h-9 rounded-lg flex items-center justify-center transition-colors ${isDarkMode ? "hover:bg-gray-700" : "hover:bg-slate-100"}`}
                >
                  <Trophy
                    size={18}
                    className={isDarkMode ? "text-gray-300" : "text-slate-600"}
                  />
                </button>
                <button
                  onClick={() => {
                    setIsPipActive(!isPipActive);
                    setIsPlusMenuOpen(false);
                  }}
                  className={`w-9 h-9 rounded-lg flex items-center justify-center transition-colors ${isDarkMode ? "hover:bg-gray-700" : "hover:bg-slate-100"} ${isPipActive ? "bg-blue-500 text-white" : ""}`}
                  title="Picture-in-Picture Mode"
                >
                  <PictureInPicture2
                    size={18}
                    className={
                      isPipActive
                        ? "text-white"
                        : isDarkMode
                          ? "text-gray-300"
                          : "text-slate-600"
                    }
                  />
                </button>
              </div>
            )}
          </div>

          <button
            onClick={() => setIsPipActive(!isPipActive)}
            className={`w-9 h-9 border-2 rounded-lg flex items-center justify-center shadow-sm transition-colors ${isDarkMode ? "bg-gray-800 border-gray-600 text-gray-300" : "bg-[#FAF9F6] border-slate-300 text-slate-600 hover:bg-[#F2EFE8] hover:border-slate-400"} ${isPipActive ? "!bg-blue-500 !border-blue-600 !text-white" : ""}`}
          >
            <PictureInPicture2 size={18} className="text-inherit" />
          </button>

          <button
            onClick={() => setIsDarkMode(!isDarkMode)}
            className={`w-9 h-9 border-2 rounded-lg flex items-center justify-center shadow-sm transition-colors ${isDarkMode ? "bg-gray-800 border-gray-600" : "bg-[#FAF9F6] border-slate-300 hover:bg-[#F2EFE8] hover:border-slate-400"}`}
          >
            {isDarkMode ? (
              <Sun size={18} className="text-yellow-400" />
            ) : (
              <Moon size={18} className="text-[#1A90FF]" />
            )}
          </button>
        </div>
        <div
          className={`px-2 py-1 text-[10px] font-bold rounded-full border-2 shadow-sm whitespace-nowrap overflow-hidden text-ellipsis max-w-[120px] ml-1 transition-colors ${isDarkMode ? "bg-gray-800 border-gray-600 text-gray-300" : "bg-slate-100 border-slate-300 text-slate-700"}`}
        >
          Today's {roundNumber}
        </div>
      </header>

      {/* Player Profile / Welcome Bar */}
      {showPlayerProfile && (
        <div
          className={`mx-4 mb-2 p-1.5 px-3 rounded-xl border flex items-center justify-between gap-2 text-xs transition-all shadow-sm shrink-0 ${isDarkMode ? "bg-gray-800/80 border-gray-700 text-gray-200 shadow-black/20" : "bg-white/90 border-[#A3A198]/40 text-slate-800 shadow-slate-200"}`}
        >
          <div className="flex items-center gap-2 overflow-hidden">
            <img
              src={playerAvatar}
              className="w-6 h-6 rounded-full object-cover p-px bg-yellow-400 border border-yellow-600 shadow-sm shrink-0"
              alt="Avatar"
            />
            <span className="font-extrabold tracking-tight truncate max-w-[120px]">
              {playerName}
            </span>
            <button
              onClick={() => {
                const newName = prompt("Enter your player name:", playerName);
                if (newName && newName.trim()) {
                  const trimmed = newName.trim();
                  setPlayerName(trimmed);
                  setPlayerAvatar(
                    "https://api.dicebear.com/7.x/avataaars/svg?seed=" +
                      encodeURIComponent(trimmed),
                  );
                }
              }}
              className="w-6 h-6 rounded-lg bg-blue-50 dark:bg-blue-900/30 hover:bg-blue-100 dark:hover:bg-blue-900/50 text-blue-500 flex items-center justify-center transition-all shrink-0 ml-1.5 active:scale-95 border border-blue-200/50 dark:border-blue-800/40"
              title="Edit Player Name"
            >
              <Pencil size={11} className="shrink-0" />
            </button>
          </div>
          <div className="text-[10px] font-bold text-green-500 bg-green-50 dark:bg-green-900/20 px-2 py-0.5 rounded">
            <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse"></span>{" "}
            Live Active
          </div>
        </div>
      )}

      {/* Daily Jackpot Banner */}
      {isBonusRound && bonusMessage && (
        <div
          className={`mx-4 mb-2 p-3 rounded-xl border-2 flex items-center justify-center text-center shadow-[0_0_15px_rgba(168,85,247,0.4)] animate-pulse ${isDarkMode ? "bg-purple-900/40 border-purple-500 text-purple-100" : "bg-purple-100 border-purple-500 text-purple-900"}`}
        >
          <div className="flex flex-col items-center">
            <div className="font-extrabold text-[14px] uppercase flex items-center gap-2">
              <Sparkles size={16} className="text-yellow-400" />
              {bonusMessage}
              <Sparkles size={16} className="text-yellow-400" />
            </div>
          </div>
        </div>
      )}

      {showJackpotBanner && !isBonusRound && (
        <div
          onClick={() => {
            setShowJackpotModal(true);
            playSound("bet");
          }}
          className={`mx-4 mb-2 p-2.5 rounded-xl border flex items-center justify-between gap-2 text-xs transition-all cursor-pointer shadow-md select-none group relative overflow-hidden ${
            isDarkMode
              ? "bg-gradient-to-r from-amber-950/45 via-yellow-950/35 to-amber-950/45 border-amber-500/35 hover:border-amber-400 text-yellow-100 shadow-yellow-950/20"
              : "bg-gradient-to-r from-amber-50 via-yellow-50 to-amber-50 border-amber-200 hover:border-amber-400 text-amber-900 shadow-amber-100/50"
          }`}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-yellow-400/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />

          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-amber-500 flex items-center justify-center text-white font-extrabold text-base shadow-sm shrink-0 animate-pulse">
              👑
            </div>
            <div className="flex flex-col">
              <span className="font-extrabold tracking-tight text-[11px] uppercase text-amber-500 flex items-center gap-1">
                Progressive Jackpot
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
              </span>
              <span className="font-mono text-xs text-slate-500 dark:text-gray-400 flex items-center gap-1">
                Trigger:{" "}
                <span className="font-bold text-amber-600 dark:text-amber-400">
                  🍕 Pizza
                </span>
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <div className="flex flex-col items-end">
              <div className="font-extrabold text-sm text-yellow-500 tracking-tight flex items-center gap-1">
                <Coins size={14} className="text-yellow-500 shrink-0" />
                {jackpotPool.toLocaleString()}
              </div>
              <span className="text-[8px] font-bold text-slate-400 dark:text-gray-550 uppercase tracking-widest">
                Jackpot Pool
              </span>
            </div>
            <div className="w-7 h-7 rounded-full bg-amber-500/10 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center border border-amber-300/30 dark:border-amber-500/30 shadow-inner group-hover:bg-amber-500 group-hover:text-white transition-all duration-300">
              <ChevronRight size={14} />
            </div>
          </div>
        </div>
      )}

      {/* Real-time AI Risk Analysis feed ticker - Hidden as requested */}

      {/* Main Wheel Area */}
      {(() => {
        const MainWheelArea = (
          <main className="flex-1 min-h-0 min-w-0 relative flex flex-col items-center justify-center z-0 px-2 mt-1 pb-1 transition-all">
            {/* Compact stage — matches original mobile/desktop reference photos */}
            <div className="relative w-full flex flex-col items-center shrink-0">
              {/* Support structure behind wheel */}
              <div className={`pointer-events-none absolute bottom-6 left-1/2 z-0 flex aspect-square w-full -translate-x-1/2 origin-bottom scale-[0.96] justify-between transition-transform ${wheelStageClass.stand}`}>
                <div
                  className={`h-full w-12 origin-bottom -skew-x-[20deg] translate-x-12 transform rounded-t-2xl border-4 shadow-inner transition-colors ${isDarkMode ? "bg-blue-800 border-blue-900" : "bg-[#1A90FF] border-blue-600"}`}
                />
                <div
                  className={`h-full w-12 origin-bottom skew-x-[20deg] -translate-x-12 transform rounded-t-2xl border-4 shadow-inner transition-colors ${isDarkMode ? "bg-blue-800 border-blue-900" : "bg-[#1A90FF] border-blue-600"}`}
                />
              </div>

              <div
                className={`relative z-10 -mt-2 flex shrink-0 scale-[0.98] items-center justify-center rounded-full border-[8px] bg-gradient-to-br ring-[8px] backdrop-blur-md transition-all ${wheelStageClass.wheel} ${isDarkMode ? "border-gray-700/40 from-gray-700 via-gray-800 to-gray-900 shadow-[0_0_50px_rgba(31,41,55,0.6),inset_0_10px_20px_rgba(255,255,255,0.1)] ring-gray-600" : "border-white/40 from-blue-50 via-blue-100 to-blue-200 shadow-[0_0_50px_rgba(26,144,255,0.4),inset_0_10px_20px_rgba(255,255,255,0.9)] ring-[#1A90FF]"}`}
              >
              {/* Inner Center */}
              <div
                className={`absolute left-1/2 top-1/2 z-20 flex -translate-x-1/2 -translate-y-1/2 origin-center flex-col items-center justify-center rounded-full border-4 border-dashed border-yellow-400 text-white shadow-inner transition-colors duration-300 ${wheelStageClass.hub} ${gameState === "result" && winItemIndex !== null && !["salad", "pizza"].includes(ITEMS[winItemIndex].id) ? "bg-[#FFD700] shadow-[inset_0_0_20px_rgba(255,140,0,0.6)]" : isBonusRound ? "bg-purple-600 shadow-[0_0_20px_rgba(168,85,247,0.8)]" : "bg-red-500"}`}
              >
                {gameState === "betting" ? (
                  isBonusRound ? (
                    <div className="flex flex-col items-center justify-center p-2 text-center animate-pulse">
                      <div className="text-[10px] font-black uppercase text-yellow-300 drop-shadow">
                        BONUS
                      </div>
                      <div className="text-3xl font-extrabold tracking-tighter text-white">
                        {bonusMultiplier}X
                      </div>
                      <div className="text-[9px] font-bold opacity-90">
                        {Math.ceil(timeLeft)}s left
                      </div>
                    </div>
                  ) : (
                    <>
                      <div className={`${wheelStageClass.hubLabel} font-bold opacity-90`}>
                        Select time
                      </div>
                      <div className={`${wheelStageClass.hubTimer} font-extrabold tracking-tighter`}>
                        {Math.ceil(timeLeft)}s
                      </div>
                    </>
                  )
                ) : gameState === "result" && winItemIndex !== null ? (
                  <motion.div
                    initial={{ scale: 0.2, rotate: -180, opacity: 0 }}
                    animate={{ scale: 1, rotate: 0, opacity: 1 }}
                    transition={{ type: "spring", stiffness: 260, damping: 20 }}
                    className="flex flex-col items-center w-full h-full justify-center"
                  >
                    {(() => {
                      const item = ITEMS[winItemIndex];
                      if (item.id === "salad") {
                        const veggieIds = [
                          "carrot",
                          "corn",
                          "cabbage",
                          "tomato",
                        ];
                        return (
                          <div className="flex flex-wrap items-center justify-center gap-1 w-[76px] h-[76px] mb-1">
                            {veggieIds.map((vid) => {
                              const vit = ITEMS.find((i) => i.id === vid);
                              return (
                                <div
                                  key={`v_${vid}`}
                                  className="w-[34px] h-[34px] flex items-center justify-center overflow-hidden"
                                >
                                  <ItemIcon
                                    icon={vit?.icon || ""}
                                    className="text-[32px] w-[34px] h-[34px] drop-shadow-md flex items-center justify-center object-contain"
                                  />
                                </div>
                              );
                            })}
                          </div>
                        );
                      } else if (item.id === "pizza") {
                        const meatIds = ["hotdog", "skewer", "ham", "steak"];
                        return (
                          <div className="flex flex-wrap items-center justify-center gap-1 w-[76px] h-[76px] mb-1">
                            {meatIds.map((mid) => {
                              const mit = ITEMS.find((i) => i.id === mid);
                              return (
                                <div
                                  key={`m_${mid}`}
                                  className="w-[34px] h-[34px] flex items-center justify-center overflow-hidden"
                                >
                                  <ItemIcon
                                    icon={mit?.icon || ""}
                                    className="text-[32px] w-[34px] h-[34px] drop-shadow-md flex items-center justify-center object-contain"
                                  />
                                </div>
                              );
                            })}
                          </div>
                        );
                      } else {
                        return (
                          <ItemIcon
                            icon={item.icon}
                            className="text-[64px] leading-none drop-shadow-xl w-16 h-16 flex items-center justify-center"
                          />
                        );
                      }
                    })()}
                    <div className="font-extrabold text-[#D92A2A] bg-white/95 px-4 py-0.5 rounded-full shadow-md text-lg border-2 border-[#D92A2A] transform -translate-y-2">
                      {(() => {
                        const item = ITEMS[winItemIndex];
                        if (item.id === "salad") {
                          const vItems = [
                            "carrot",
                            "corn",
                            "cabbage",
                            "tomato",
                          ];
                          let payout = 0;
                          vItems.forEach((vi) => {
                            if (bets[vi as ItemId]) {
                              const it = ITEMS.find((i) => i.id === vi);
                              if (it)
                                payout += bets[vi as ItemId]! * it.multiplier;
                            }
                          });
                          return payout > 0
                            ? `+${formatAmount(payout)}`
                            : "Veggie!";
                        } else if (item.id === "pizza") {
                          const mItems = ["hotdog", "skewer", "ham", "steak"];
                          let payout = 0;
                          mItems.forEach((mi) => {
                            if (bets[mi as ItemId]) {
                              const it = ITEMS.find((i) => i.id === mi);
                              if (it)
                                payout += bets[mi as ItemId]! * it.multiplier;
                            }
                          });
                          return payout > 0
                            ? `+${formatAmount(payout)}`
                            : "Meat!";
                        } else {
                          return bets[item.id]
                            ? `+${formatAmount(bets[item.id]! * item.multiplier)}`
                            : `x${item.multiplier}`;
                        }
                      })()}
                    </div>
                  </motion.div>
                ) : (
                  <div className="flex gap-1.5">
                    <motion.div
                      animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }}
                      transition={{ repeat: Infinity, duration: 0.8 }}
                      className="w-3 h-3 bg-white rounded-full shadow-[0_0_10px_white]"
                    />
                    <motion.div
                      animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }}
                      transition={{
                        repeat: Infinity,
                        duration: 0.8,
                        delay: 0.2,
                      }}
                      className="w-3 h-3 bg-white rounded-full shadow-[0_0_10px_white]"
                    />
                    <motion.div
                      animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }}
                      transition={{
                        repeat: Infinity,
                        duration: 0.8,
                        delay: 0.4,
                      }}
                      className="w-3 h-3 bg-white rounded-full shadow-[0_0_10px_white]"
                    />
                  </div>
                )}
              </div>

              {/* Wheel Nodes */}
              {ITEMS.slice(0, 8).map((item, index) => {
                const angle = (index / 8) * 2 * Math.PI - Math.PI / 2;
                const radiusPercent = 44.8;
                const left = 50 + Math.cos(angle) * radiusPercent;
                const top = 50 + Math.sin(angle) * radiusPercent;
                const isHighlighted =
                  (gameState === "spinning" && index === highlightIndex) ||
                  (gameState === "result" &&
                    (index === wheelIndex ||
                      (winItemIndex !== null &&
                        ITEMS[winItemIndex]?.id === "salad" &&
                        ["carrot", "corn", "cabbage", "tomato"].includes(
                          item.id,
                        )) ||
                      (winItemIndex !== null &&
                        ITEMS[winItemIndex]?.id === "pizza" &&
                        ["hotdog", "skewer", "ham", "steak"].includes(
                          item.id,
                        ))));

                return (
                  <button
                    key={`wheel_item_${item.id || "i"}_${index}`}
                    onClick={() => placeBet(item.id)}
                    className="absolute w-[28%] h-[28%] rounded-full transition-transform duration-100 ease-in-out cursor-pointer"
                    style={{
                      left: `${left}%`,
                      top: `${top}%`,
                      transform: `translate(-50%, -50%) scale(${isHighlighted ? 1.15 : 1})`,
                      boxShadow: isHighlighted
                        ? "none"
                        : "0 4px 6px rgba(0,0,0,0.1)",
                      zIndex: isHighlighted ? 30 : 10,
                    }}
                  >
                    <div className="w-full h-full relative transition-transform origin-center scale-[0.85]">
                      <div
                        className={`absolute inset-0 rounded-full flex flex-col items-center overflow-hidden border-[4px] transition-colors ${isHighlighted ? "border-[#FF3B30]" : isDarkMode ? "border-gray-600" : "border-[#2196F3]"}`}
                        style={{
                          boxShadow: isHighlighted
                            ? "0 0 15px rgba(255,59,48,0.95)"
                            : "none",
                        }}
                      >
                        {/* Node Top Half (Icon) */}
                        <div
                          className={`flex-1 w-full flex items-center justify-center transition-colors pb-0.5 ${isDarkMode ? "bg-gray-800" : "bg-[#F4F2EB]"}`}
                        >
                          <ItemIcon
                            icon={item.icon}
                            className={`filter drop-shadow-md object-contain flex items-center justify-center -mt-0.5 ${item.id === "skewer" ? (isPipActive ? "w-[30px] h-[30px] text-[22px]" : "w-[32px] h-[32px] text-[24px] sm:text-[28px] md:text-[30px]") : item.id === "hotdog" ? (isPipActive ? "w-[22px] h-[22px] text-[18px]" : "w-[24px] h-[24px] text-[20px] sm:text-[24px] md:text-[26px]") : isPipActive ? "w-[26px] h-[26px] text-[22px]" : "w-[28px] h-[28px] text-[24px] sm:text-[28px] md:text-[30px]"}`}
                          />
                        </div>
                        {/* Node Bottom Half (Multiplier) */}
                        <div
                          className={`h-[18px] sm:h-[20px] md:h-[22px] w-full flex items-center justify-center border-t border-t-black/10 px-1 transition-colors relative z-10 ${isDarkMode ? "bg-gray-700" : "bg-blue-100"}`}
                        >
                          <span
                            className={`text-[8px] font-black leading-none whitespace-nowrap tracking-tighter ${isDarkMode ? "text-gray-200" : "text-blue-900"}`}
                          >
                            win {item.multiplier}x
                          </span>
                        </div>
                      </div>

                      {/* Hot Indicator */}
                      {item.id === hotItemId &&
                        gameState === "betting" &&
                        timeLeft <= BETTING_TIME - 5 && (
                          <div className="absolute -top-1 -left-2 bg-red-500 text-white min-w-[20px] px-1 py-0.5 rounded-md text-[9px] font-black border border-white shadow-md z-40 whitespace-nowrap flex items-center justify-center transform -rotate-12">
                            Hot
                          </div>
                        )}

                      {/* Bet Indicator */}
                      {bets[item.id] && (
                        <div className="absolute -top-1 -right-2 bg-yellow-400 text-yellow-900 min-w-[20px] px-1 py-0.5 rounded-full text-[10px] font-extrabold border-2 border-yellow-600 shadow-md z-40 whitespace-nowrap flex items-center justify-center">
                          {formatAmount(bets[item.id]!)}
                        </div>
                      )}

                      {/* Global Bet Indicator (Hidden per user request) */}
                      {/* totalBets[item.id] && (
                    <div className="absolute -bottom-1 -right-2 bg-gray-100 text-gray-700 min-w-[20px] px-1 py-0.5 rounded-full text-[9px] font-bold border-2 border-gray-300 shadow-md z-40 whitespace-nowrap flex items-center justify-center gap-[2px]">
                      <span className="text-[8px]">👥</span>{" "}
                      {formatAmount(totalBets[item.id]!)}
                    </div>
                  ) */}

                      {/* Hand Pointer Animation (Just a decorative hint on one item) */}
                    </div>
                  </button>
                );
              })}
              </div>

              {/* Salad and Pizza base structure */}
              <div className={`z-20 mb-0 mt-4 flex w-full origin-top items-end justify-between px-2 transition-all ${wheelStageClass.saladRow}`}>
              <div className="flex flex-col items-center">
                <div
                  className={`w-12 h-12 rounded-full border-4 flex items-center justify-center shadow-md relative transition-colors ${isDarkMode ? "bg-gray-800 border-gray-600" : "bg-green-50 border-green-300"}`}
                >
                  <ItemIcon
                    icon={ITEMS.find((i) => i.id === "salad")?.icon || "🥗"}
                    className="w-8 h-8 text-[32px] leading-none filter drop-shadow flex items-center justify-center object-contain"
                  />

                  {/* Veggie Group Bet Indicator */}
                  {(() => {
                    const veggieSum = [
                      "carrot",
                      "corn",
                      "cabbage",
                      "tomato",
                    ].reduce((sum, id) => sum + (bets[id as ItemId] || 0), 0);
                    if (veggieSum > 0) {
                      return (
                        <div className="absolute -top-1.5 -right-2 bg-yellow-400 text-yellow-900 min-w-[20px] px-1 py-0.5 rounded-full text-[9px] font-extrabold border-2 border-yellow-600 shadow-md z-40 whitespace-nowrap flex items-center justify-center">
                          {formatAmount(veggieSum)}
                        </div>
                      );
                    }
                    return null;
                  })()}
                </div>

                <button
                  onClick={() => placeBetGroup("veggie")}
                  className={`font-extrabold text-[10px] px-2 py-0.5 rounded shadow border -mt-2 z-10 active:scale-95 transition-all ${isDarkMode ? "bg-orange-600 text-white border-orange-800 hover:bg-orange-700" : "bg-green-600 text-white border-green-700 hover:bg-green-500"}`}
                >
                  Salad &gt;
                </button>
              </div>

              <div className="flex flex-col items-center">
                <div
                  className={`w-12 h-12 rounded-full border-4 flex items-center justify-center shadow-md relative transition-colors ${isDarkMode ? "bg-gray-800 border-gray-600" : "bg-red-50 border-red-300"}`}
                >
                  <ItemIcon
                    icon={ITEMS.find((i) => i.id === "pizza")?.icon || "🍕"}
                    className="w-10 h-10 text-[36px] leading-none filter drop-shadow flex items-center justify-center object-contain"
                  />

                  {/* Meat Group Bet Indicator */}
                  {(() => {
                    const meatSum = ["hotdog", "skewer", "ham", "steak"].reduce(
                      (sum, id) => sum + (bets[id as ItemId] || 0),
                      0,
                    );
                    if (meatSum > 0) {
                      return (
                        <div className="absolute -top-1.5 -right-2 bg-yellow-400 text-yellow-900 min-w-[20px] px-1 py-0.5 rounded-full text-[9px] font-extrabold border-2 border-yellow-600 shadow-md z-40 whitespace-nowrap flex items-center justify-center">
                          {formatAmount(meatSum)}
                        </div>
                      );
                    }
                    return null;
                  })()}
                </div>

                <button
                  onClick={() => placeBetGroup("meat")}
                  className={`font-extrabold text-[10px] px-2 py-0.5 rounded shadow border -mt-2 z-10 active:scale-95 transition-all ${isDarkMode ? "bg-orange-600 text-white border-orange-800 hover:bg-orange-700" : "bg-red-600 text-white border-red-700 hover:bg-red-500"}`}
                >
                  Pizza &gt;
                </button>
              </div>
              </div>
            </div>
          </main>
        );

        return MainWheelArea;
      })()}

      {/* Betting Panel Interface */}
      <section
        className={`shrink-0 rounded-t-2xl pt-1.5 pb-1 px-1.5 shadow-[0_-10px_20px_rgba(0,0,0,0.1)] z-20 flex flex-col relative mt-auto border-t-[3px] transition-colors ${isDarkMode ? "bg-gray-800 border-gray-600" : "bg-[#29B6F6] border-blue-400"}`}
      >
        {/* Chips */}
        <div
          className={`flex items-center overflow-x-auto hide-scrollbar p-1 rounded-xl border-b-2 gap-1 transition-colors ${isDarkMode ? "bg-gray-700 border-gray-900" : "bg-[#E1F5FE] border-blue-200"}`}
        >
          {BET_AMOUNTS.map((amt) => {
            const isSelected = currentBetAmount === amt;
            return (
              <button
                key={`game_bet_${amt}`}
                onClick={() => setCurrentBetAmount(amt)}
                className={`relative shrink-0 w-[40px] h-[40px] rounded-[10px] flex items-center justify-center transition-all ${
                  isSelected
                    ? "bg-red-500 scale-110 shadow-lg -translate-y-1"
                    : "bg-[#FAF9F6] shadow hover:scale-105"
                }`}
              >
                <div
                  className={`w-[32px] h-[32px] rounded-full border-2 flex items-center justify-center ${
                    isSelected
                      ? "border-yellow-300 bg-yellow-400"
                      : "border-yellow-200 bg-yellow-100"
                  }`}
                >
                  <div className="w-[24px] h-[24px] rounded-full border border-yellow-500 bg-gradient-to-br from-yellow-300 to-yellow-500 flex items-center justify-center shadow-inner">
                    <span className="font-extrabold text-yellow-900 drop-shadow-sm text-[9px]">
                      {formatAmount(amt)}
                    </span>
                  </div>
                </div>
                {/* Active Indicator Ring */}
                {isSelected && (
                  <motion.div
                    layoutId="bet-ring"
                    className="absolute inset-0 rounded-[10px] border-[3px] border-yellow-300 opacity-50"
                  />
                )}
              </button>
            );
          })}

          {/* Custom Bet Chip */}
          <button
            onClick={() => setShowCustomBet(true)}
            className={`relative shrink-0 w-[40px] h-[40px] rounded-[10px] flex items-center justify-center transition-all ${
              !BET_AMOUNTS.includes(currentBetAmount)
                ? "bg-red-500 scale-110 shadow-lg -translate-y-1"
                : "bg-[#FAF9F6] shadow hover:scale-105"
            }`}
          >
            <div
              className={`w-[32px] h-[32px] rounded-full border-2 flex items-center justify-center ${
                !BET_AMOUNTS.includes(currentBetAmount)
                  ? "border-yellow-300 bg-yellow-400"
                  : "border-yellow-200 bg-yellow-100"
              }`}
            >
              <div className="w-[24px] h-[24px] rounded-full border border-yellow-500 bg-gradient-to-br from-yellow-300 to-yellow-500 flex items-center justify-center shadow-inner">
                <span className="font-extrabold text-yellow-900 drop-shadow-sm text-[8px]">
                  {!BET_AMOUNTS.includes(currentBetAmount)
                    ? formatAmount(currentBetAmount)
                    : "Custom"}
                </span>
              </div>
            </div>
            {!BET_AMOUNTS.includes(currentBetAmount) && (
              <motion.div
                layoutId="bet-ring"
                className="absolute inset-0 rounded-[10px] border-[3px] border-yellow-300 opacity-50"
              />
            )}
          </button>

          {/* Shop Button */}
          <button
            onClick={() => setShowShop(true)}
            className="relative shrink-0 w-[40px] h-[40px] rounded-[10px] flex items-center justify-center transition-all bg-gradient-to-br from-green-400 to-emerald-600 shadow hover:scale-105 ml-auto border-b-[3px] border-emerald-700 text-white"
            title="Open Shop"
          >
            <ShoppingCart size={16} className="filter drop-shadow-md" />
          </button>
        </div>
      </section>

      {/* Bottom Display / History */}
      <section
        className={`shrink-0 p-1.5 shadow-inner z-20 relative border-t-[3px] flex flex-col gap-1 transition-colors ${isDarkMode ? "bg-gray-900 border-gray-700" : "bg-[#d1d1d1]/85 backdrop-blur-[6px] border-[#830000] shadow-inner"}`}
        style={{
          paddingBottom: showOverlay
            ? `calc(12px + ${devicePlatform === "ios" ? "18px" : "14px"})`
            : "12px",
        }}
      >
        {/* Coins and Profits */}
        <div className="flex gap-1.5">
          <div
            className={`flex-1 rounded-full py-1 px-2 flex items-center justify-between shadow transition-colors ${isDarkMode ? "bg-gray-800 text-gray-300" : "bg-[#FAF9F6] border border-gray-100"}`}
          >
            <span className="text-gray-500 font-bold text-[10px]">
              Coins left
            </span>
            <div className="flex items-center gap-1 font-bold text-[11px]">
              <div className="w-3.5 h-3.5 bg-yellow-400 rounded-full border border-yellow-600 flex items-center justify-center text-[7px] shadow-sm">
                💰
              </div>
              {formatAmount(coins)} &gt;
            </div>
          </div>
          <div
            className={`flex-1 rounded-full py-1 px-2 flex flex-col items-center justify-center shadow transition-colors ${isDarkMode ? "bg-gray-800" : "bg-[#FAF9F6] border border-gray-100"}`}
          >
            <span className="text-gray-500 font-bold text-[9px] leading-tight">
              Today's profits
            </span>
            <div className="flex items-center gap-1 font-bold text-orange-500 text-[11px] leading-tight">
              💰 {formatAmount(profits)}
            </div>
          </div>
        </div>

        {/* Result History Row */}
        <div className="flex items-center overflow-visible h-[44px] shrink-0">
          <div
            className={`flex items-center gap-1 border-r pr-1.5 shrink-0 h-full ${isDarkMode ? "border-white/20" : "border-slate-300"}`}
          >
            <div className="flex flex-col">
              <span
                className={`font-black text-[8px] uppercase tracking-wider ${isDarkMode ? "text-white opacity-60" : "text-slate-500"}`}
              >
                Result
              </span>
              <span
                className={`font-bold text-[7px] uppercase tracking-tighter ${isDarkMode ? "text-gray-400" : "text-slate-600"}`}
              >
                History
              </span>
            </div>
            <button
              onClick={() => setShowHistoryModal(true)}
              className="w-6 h-6 rounded-md bg-blue-50 dark:bg-blue-900/30 hover:bg-blue-100 dark:hover:bg-blue-900/50 text-blue-500 flex items-center justify-center transition-all shrink-0 active:scale-95 border border-blue-200/50 dark:border-blue-800/40"
              title="View Full History"
            >
              <Clock size={10} className="shrink-0" />
            </button>
          </div>
          <div className="flex gap-1 flex-nowrap overflow-x-auto hide-scrollbar w-full py-2 items-center overflow-y-visible pl-1.5">
            <AnimatePresence initial={false}>
              {history.slice(0, 16).map((histItem, idx) => {
                const item = ITEMS.find((i) => i.id === histItem.id);
                const isNew = idx === 0 && gameState === "result";
                return (
                  <motion.div
                    key={
                      histItem.uid
                        ? `${histItem.uid}_${idx}`
                        : `game_hist_v4_${histItem.round || idx}_${histItem.timestamp || "time"}`
                    }
                    initial={{ width: 0, opacity: 0, scale: 0.5 }}
                    animate={{ width: 24, opacity: 1, scale: 1 }}
                    transition={{ type: "spring", stiffness: 300, damping: 25 }}
                    className="relative shrink-0 overflow-visible"
                  >
                    <div
                      className={`w-6 h-6 rounded-lg flex items-center justify-center shadow border transition-colors overflow-hidden ${isNew ? "border-yellow-400 bg-white shadow-md shadow-yellow-500/25" : isDarkMode ? "border-gray-600 bg-gray-800" : "border-gray-200 bg-white"}`}
                    >
                      {item && (
                        <ItemIcon
                          icon={item.icon}
                          className="text-xs w-4 h-4 flex items-center justify-center"
                        />
                      )}
                    </div>
                    {isNew && (
                      <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[6px] font-bold px-0.5 rounded shadow-sm z-40 border border-white animate-bounce uppercase leading-none select-none">
                        New
                      </span>
                    )}
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        </div>

        {/* Bottom actionable cards */}
        <div className="flex gap-2 h-[44px] shrink-0 mt-2">
          <button
            onClick={() => {
              setLeaderboardTab("today");
              setShowLeaderboard(true);
            }}
            className={`flex-1 rounded-xl p-1.5 px-3 flex items-center shadow-md text-left relative overflow-visible group transition-all duration-200 hover:scale-[1.01] active:scale-95 ${isDarkMode ? "bg-gray-800/90 border border-gray-700/60 shadow-black/40 hover:bg-gray-700/90" : "bg-white border border-gray-200/80 shadow-gray-200/50 hover:bg-gray-50"}`}
          >
            <div className="w-7 h-7 bg-amber-500 rounded-full flex items-center justify-center text-white mr-2.5 shrink-0 relative shadow-sm">
              <span className="text-xs">🏆</span>
              <div className="absolute -bottom-1.5 -right-1.5 bg-rose-500 min-w-[17px] h-[17px] px-0.5 rounded-full border-2 border-white dark:border-gray-800 flex items-center justify-center text-[9px] font-black leading-none text-white shadow-md transition-all">
                {getMyRank("today")}
              </div>
            </div>
            <div className="flex flex-col leading-tight overflow-hidden justify-center space-y-0.5">
              <span
                className={`text-[9px] font-bold uppercase tracking-wider ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}
              >
                Today's Profit
              </span>
              <span
                className={`text-[11px] font-extrabold font-mono flex items-center ${isDarkMode ? "text-white" : "text-gray-900"}`}
              >
                💰 {formatAmount(profits)}
              </span>
            </div>
            <span className="absolute right-2.5 text-gray-400 font-bold group-hover:text-gray-600 dark:group-hover:text-gray-200 text-xs transition-transform group-hover:translate-x-0.5">
              &gt;
            </span>
          </button>
          <button
            onClick={() => {
              setLeaderboardTab("alltime");
              setShowLeaderboard(true);
            }}
            className={`flex-1 rounded-xl p-1.5 px-3 flex items-center shadow-md text-left relative group transition-all duration-200 hover:scale-[1.01] active:scale-95 ${isDarkMode ? "bg-gray-800/90 border border-gray-700/60 shadow-black/40 hover:bg-gray-700/90" : "bg-white border border-gray-200/80 shadow-gray-200/50 hover:bg-gray-50"}`}
          >
            <div className="w-7 h-7 rounded-full flex items-center justify-center text-white mr-2.5 shrink-0 bg-gradient-to-br from-yellow-400 to-orange-500 shadow-md border-2 border-white dark:border-gray-800">
              <span className="text-xs drop-shadow-sm">👑</span>
            </div>
            <div className="flex flex-col flex-1 leading-tight justify-center space-y-0.5">
              <span
                className={`text-[11px] font-extrabold ${isDarkMode ? "text-white" : "text-gray-900"}`}
              >
                Leaderboard
              </span>
              <span className="text-[9px] font-extrabold text-amber-500 dark:text-amber-400 uppercase tracking-widest leading-none">
                Rank #{getMyRank("alltime")}
              </span>
            </div>
            <span className="absolute right-2.5 text-gray-400 font-bold group-hover:text-gray-600 dark:group-hover:text-gray-200 text-xs transition-transform group-hover:translate-x-0.5">
              &gt;
            </span>
          </button>
        </div>
      </section>

      {/* Modals */}
      <AnimatePresence>
        {showHelp && (
          <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className={`rounded-3xl p-6 w-full max-w-sm shadow-2xl relative border-[6px] transition-colors ${isDarkMode ? "bg-gray-800 border-gray-600" : "bg-white border-yellow-400"}`}
            >
              <button
                onClick={() => setShowHelp(false)}
                className={`absolute -top-4 -right-4 w-10 h-10 rounded-full border-4 text-white font-bold flex items-center justify-center text-xl shadow-lg transition-colors ${isDarkMode ? "bg-red-600 border-gray-600" : "bg-red-500 border-white"}`}
              >
                ✕
              </button>
              <h2
                className={`text-2xl font-black text-center mb-4 tracking-tight drop-shadow-sm flex items-center justify-center gap-2 ${isDarkMode ? "text-red-400" : "text-red-500"}`}
              >
                <span>🎮</span> How to Play
              </h2>
              <div
                className={`space-y-3 font-medium text-sm overflow-y-auto max-h-[50vh] pr-2 custom-scrollbar ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}
              >
                <p
                  className={`p-3 rounded-xl border ${isDarkMode ? "bg-gray-700 border-gray-600" : "bg-orange-50 border-orange-200"}`}
                >
                  1. Select a chip amount{" "}
                  <span
                    className={`font-bold ${isDarkMode ? "text-orange-400" : "text-orange-600"}`}
                  >
                    (10, 50, 100, 1k, 10k, 100k, Custom)
                  </span>{" "}
                  from the bottom panel.
                </p>
                <p
                  className={`p-3 rounded-xl border ${isDarkMode ? "bg-gray-700 border-gray-600" : "bg-orange-50 border-orange-200"}`}
                >
                  2. Tap on the{" "}
                  <span
                    className={`font-bold ${isDarkMode ? "text-orange-400" : "text-orange-600"}`}
                  >
                    food items
                  </span>{" "}
                  on the wheel to place your bets before the timer runs out.
                </p>
                <p
                  className={`p-3 rounded-xl border ${isDarkMode ? "bg-gray-700 border-gray-600" : "bg-orange-50 border-orange-200"}`}
                >
                  3. Wait for the wheel to spin. If it lands on your selected
                  item, you multiply your bet by that item's multiplier!
                </p>
                <p
                  className={`p-3 rounded-xl border ${isDarkMode ? "bg-gray-700 border-gray-600" : "bg-orange-50 border-orange-200"}`}
                >
                  <strong
                    className={`block mb-1 ${isDarkMode ? "text-orange-400" : "text-orange-600"}`}
                  >
                    Quick Bets:
                  </strong>
                  Tap{" "}
                  <strong
                    className={`text-sm border px-1 shadow-sm rounded mr-1 ${isDarkMode ? "bg-gray-600 border-gray-500" : "bg-white"}`}
                  >
                    🥗 Salad
                  </strong>{" "}
                  or{" "}
                  <strong
                    className={`text-sm border px-1 shadow-sm rounded ${isDarkMode ? "bg-gray-600 border-gray-500" : "bg-white"}`}
                  >
                    🍕 Pizza
                  </strong>{" "}
                  to bet on all veggies or all meats at once!
                </p>
              </div>
            </motion.div>
          </div>
        )}

        {showShop && (
          <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 50 }}
              className={`rounded-3xl w-full max-w-sm shadow-2xl relative border-[4px] overflow-hidden flex flex-col max-h-[80vh] transition-colors ${isDarkMode ? "bg-gray-800 border-gray-600" : "bg-white border-green-500"}`}
            >
              <div
                className={`px-4 py-3 flex justify-between items-center text-white transition-colors ${isDarkMode ? "bg-green-700" : "bg-green-500"}`}
              >
                <h3 className="font-black text-lg flex items-center gap-2">
                  🛒 Coin Shop
                </h3>
                <button
                  onClick={() => setShowShop(false)}
                  className="bg-white/20 p-1.5 rounded-full hover:bg-white/30 transition-colors"
                >
                  <div className="w-4 h-4 flex items-center justify-center font-bold">
                    ✕
                  </div>
                </button>
              </div>

              <div className="p-4 overflow-y-auto hide-scrollbar space-y-4 flex-1">
                <div>
                  <h4
                    className={`text-sm font-bold opacity-70 mb-2 uppercase tracking-wide ${isDarkMode ? "text-gray-300" : "text-gray-500"}`}
                  >
                    Packages
                  </h4>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { id: "1", base: 100, price: 0.99 },
                      { id: "2", base: 504, price: 4.99 },
                      { id: "3", base: 1010, price: 9.99 },
                      { id: "4", base: 3030, price: 29.99 },
                      { id: "5", base: 5050, price: 49.99 },
                      { id: "6", base: 12121, price: 99.99 },
                    ].map((pkg) => {
                      const bonusPercent = shopBonuses[pkg.id] || 0;
                      const bonusCoins = Math.floor(
                        pkg.base * (bonusPercent / 100),
                      );
                      const totalCoins = pkg.base + bonusCoins;

                      return (
                        <button
                          key={`game_pkg_${pkg.id || "pkg"}`}
                          onClick={() => {
                            setCheckoutData({ pkg, total: totalCoins });
                            setPaymentStep("details");
                          }}
                          className={`relative p-3 rounded-2xl border-2 flex flex-col items-center gap-1 active:scale-95 transition-transform ${isDarkMode ? "border-gray-600 hover:border-green-500 bg-gray-700 text-white" : "border-gray-200 hover:border-green-500 bg-gray-50 text-gray-900"}`}
                        >
                          {bonusPercent > 0 && (
                            <div className="absolute -top-2 -right-2 bg-red-500 text-white text-[8px] font-black px-1.5 py-0.5 rounded-full shadow-sm animate-bounce z-10">
                              +{bonusPercent}% BONUS
                            </div>
                          )}
                          <div className="text-xl">💰</div>
                          <div className="font-black text-sm">
                            {formatAmount(totalCoins)}
                          </div>
                          <div className="text-[10px] font-bold opacity-60">
                            Coins
                          </div>
                          <div className="mt-1 w-full py-1 rounded-xl bg-green-500 text-white font-black text-[10px] shadow-sm">
                            ${pkg.price}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <h4
                    className={`text-sm font-bold opacity-70 mb-2 uppercase tracking-wide mt-4 ${isDarkMode ? "text-white" : "text-gray-500"}`}
                  >
                    Custom Amount
                  </h4>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-xs">
                        💰
                      </span>
                      <input
                        type="number"
                        value={customCoinAmount}
                        onChange={(e) => setCustomCoinAmount(e.target.value)}
                        className={`w-full pl-8 pr-3 py-3 rounded-xl border-2 outline-none font-black transition-all ${isDarkMode ? "bg-gray-800 border-gray-700 text-white focus:border-blue-500" : "bg-gray-50 border-gray-200 text-gray-800 focus:border-blue-500"}`}
                        placeholder="Min 100"
                      />
                    </div>
                    <button
                      onClick={() => {
                        const amt = parseInt(customCoinAmount);
                        if (amt >= 100) {
                          const price = (amt * 0.01).toFixed(2);
                          setCheckoutData({
                            pkg: { id: "custom", price: price },
                            total: amt,
                          });
                          setPaymentStep("details");
                        } else {
                          alert("Minimum purchase is 100 coins ($1.00)");
                        }
                      }}
                      className="bg-blue-600 hover:bg-blue-700 text-white px-6 rounded-xl font-black transition-all active:scale-95 shadow-lg shadow-blue-500/20 flex flex-col items-center justify-center min-w-[120px]"
                    >
                      <span className="text-[10px] opacity-70 uppercase tracking-tighter">
                        Buy Now
                      </span>
                      <span className="text-sm font-black">
                        ${((parseInt(customCoinAmount) || 0) * 0.01).toFixed(2)}
                      </span>
                    </button>
                  </div>
                  <div className="mt-2 flex items-center gap-1 opacity-40 justify-center">
                    <ShieldCheck size={10} />
                    <span className="text-[8px] font-bold uppercase tracking-wider">
                      End-to-End Encrypted
                    </span>
                  </div>
                </div>

                <div>
                  <h4
                    className={`text-sm font-bold opacity-70 mb-2 uppercase tracking-wide mt-4 ${isDarkMode ? "text-white" : "text-gray-500"}`}
                  >
                    Recent Transactions
                  </h4>
                  <div className="space-y-2">
                    {myTransactions.length === 0 ? (
                      <p
                        className={`text-xs text-center p-4 rounded-xl ${isDarkMode ? "bg-gray-700 text-gray-500" : "bg-gray-100 text-gray-400"}`}
                      >
                        No recent purchases
                      </p>
                    ) : (
                      myTransactions.map((tx, idx) => (
                        <div
                          key={`tx_${tx.id || "tx"}_${idx}`}
                          className={`p-2 rounded-xl flex justify-between items-center bg-green-50/10 border-l-4 border-green-500 text-sm ${isDarkMode ? "bg-opacity-20" : ""}`}
                        >
                          <div className="flex flex-col">
                            <span
                              className={`font-bold ${isDarkMode ? "text-white" : "text-gray-700"}`}
                            >
                              Purchase
                            </span>
                            <span className="text-[10px] text-gray-400">
                              {new Date(tx.date).toLocaleTimeString()}
                            </span>
                          </div>
                          <span className="font-black text-green-500">
                            +{formatAmount(tx.amount)}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}

        {showLeaderboard && (
          <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 50 }}
              className={`rounded-3xl w-full max-w-sm shadow-2xl relative border-[4px] overflow-hidden flex flex-col max-h-[80vh] transition-colors ${isDarkMode ? "bg-gray-800 border-gray-600 text-white" : "bg-white border-yellow-500 text-gray-900"}`}
            >
              <div
                className={`px-4 py-3 flex justify-between items-center text-white transition-colors bg-gradient-to-r from-yellow-400 to-orange-500`}
              >
                <h3 className="font-black text-lg flex items-center gap-2">
                  👑 Top Players
                </h3>
                <button
                  onClick={() => setShowLeaderboard(false)}
                  className="bg-white/20 p-1.5 rounded-full hover:bg-white/30 transition-colors"
                >
                  <div className="w-4 h-4 flex items-center justify-center font-bold">
                    ✕
                  </div>
                </button>
              </div>

              <div
                className={`flex gap-1 p-2 mx-4 mt-3 rounded-xl overflow-x-auto hide-scrollbar ${isDarkMode ? "bg-gray-700" : "bg-gray-100"}`}
              >
                {(["today", "week", "month", "alltime"] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setLeaderboardTab(tab)}
                    className={`flex-1 px-2 py-1.5 rounded-lg text-[11px] font-bold capitalize transition-all ${leaderboardTab === tab ? "bg-white text-gray-800 shadow-sm" : isDarkMode ? "text-gray-400" : "text-gray-500"}`}
                  >
                    {tab === "alltime" ? "All Time" : tab}
                  </button>
                ))}
              </div>

              <div className="p-4 overflow-y-auto hide-scrollbar space-y-2 flex-1 pb-6">
                {leaderboard.length === 0 ? (
                  <div className="text-center py-8 text-gray-500 font-bold">
                    Loading...
                  </div>
                ) : (
                  leaderboard
                    .sort((a, b) => {
                      const getVal = (u: any) =>
                        leaderboardTab === "today"
                          ? u.todayWin || 0
                          : leaderboardTab === "week"
                            ? u.weekWin || 0
                            : leaderboardTab === "month"
                              ? u.monthWin || 0
                              : u.balance;
                      return getVal(b) - getVal(a);
                    })
                    .map((user, idx) => (
                      <div
                        key={`u_${user.id || "u"}_${idx}`}
                        className={`p-3 rounded-xl flex items-center gap-3 transition-colors ${idx === 0 ? "bg-yellow-50 border-2 border-yellow-200" : isDarkMode ? "bg-gray-700" : "bg-gray-50"}`}
                      >
                        <div
                          className={`w-8 h-8 shrink-0 rounded-full flex items-center justify-center font-black text-xs relative ${idx === 0 ? "bg-yellow-400 text-white shadow-lg" : idx === 1 ? "bg-gray-300 text-gray-800" : idx === 2 ? "bg-orange-300 text-white" : isDarkMode ? "bg-gray-600 text-gray-300" : "bg-gray-200 text-gray-600"}`}
                        >
                          {user.avatar ? (
                            <img
                              src={user.avatar}
                              className="w-full h-full rounded-full object-cover p-0.5"
                              alt="Avatar"
                            />
                          ) : (
                            idx + 1
                          )}
                          <div
                            className={`absolute -top-1 -right-1 w-4 h-4 rounded-full flex items-center justify-center text-[8px] font-bold border-2 ${idx === 0 ? "bg-yellow-400 border-white text-white" : "hidden"}`}
                          >
                            1
                          </div>
                        </div>
                        <div className="flex-1 overflow-hidden">
                          <p
                            className={`font-bold text-sm truncate ${isDarkMode ? "text-gray-200" : "text-gray-800"}`}
                          >
                            {user.name}
                          </p>
                          <p
                            className={`text-[10px] ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}
                          >
                            {user.role}
                          </p>
                        </div>
                        <div className="font-black text-green-500 flex flex-col items-end shrink-0">
                          <span className="flex items-center gap-1 text-sm tracking-tighter">
                            💰{" "}
                            {formatAmount(
                              leaderboardTab === "today"
                                ? user.todayWin || 0
                                : leaderboardTab === "week"
                                  ? user.weekWin || 0
                                  : leaderboardTab === "month"
                                    ? user.monthWin || 0
                                    : user.balance,
                            )}
                          </span>
                        </div>
                      </div>
                    ))
                )}
              </div>
            </motion.div>
          </div>
        )}

        {showCustomBet && (
          <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className={`rounded-3xl w-full max-w-[300px] overflow-hidden shadow-2xl border-4 transition-colors ${isDarkMode ? "bg-gray-800 border-blue-900 text-white" : "bg-white border-[#29B6F6] text-gray-900"}`}
            >
              <div
                className={`px-4 py-3 flex justify-between items-center text-white transition-colors ${isDarkMode ? "bg-blue-900" : "bg-[#29B6F6]"}`}
              >
                <h3 className="font-extrabold text-lg flex items-center gap-2">
                  Custom Bet Amount
                </h3>
                <button
                  onClick={() => setShowCustomBet(false)}
                  className="bg-white/20 p-1.5 rounded-full hover:bg-white/30 transition-colors"
                >
                  <div className="w-4 h-4 flex items-center justify-center font-bold">
                    X
                  </div>
                </button>
              </div>
              <div className="p-6 flex flex-col gap-4 items-center">
                <input
                  type="number"
                  value={customBetValue}
                  onChange={(e) => setCustomBetValue(e.target.value)}
                  className={`w-full text-center text-3xl font-extrabold border-b-4 outline-none pb-2 bg-transparent transition-colors ${isDarkMode ? "border-gray-600 text-gray-200" : "border-gray-200 text-gray-800"}`}
                  placeholder="Enter amount"
                />
                <button
                  onClick={() => {
                    const val = parseInt(customBetValue, 10);
                    if (!isNaN(val) && val > 0) {
                      setCurrentBetAmount(val);
                      setShowCustomBet(false);
                    }
                  }}
                  className={`w-full font-extrabold py-3 rounded-xl active:translate-y-1 active:shadow-none transition-all ${isDarkMode ? "bg-yellow-600 hover:bg-yellow-500 text-white shadow-[0_4px_0_#b45309]" : "bg-[#FFB300] hover:bg-[#FF8F00] text-yellow-900 shadow-[0_4px_0_#FF6F00]"}`}
                >
                  Confirm
                </button>
              </div>
            </motion.div>
          </div>
        )}

        <AnimatePresence>
          {showMissionsModal && (
            <DailyMissionsModal
              isOpen={showMissionsModal}
              onClose={() => setShowMissionsModal(false)}
              progress={missionsProgress}
              onClaim={handleClaimMission}
              onResetMissions={handleResetMissions}
              isDarkMode={isDarkMode}
            />
          )}
        </AnimatePresence>

        <AnimatePresence>
          {showDailyBonusModal && (
            <div className="absolute inset-0 z-[350] flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md overflow-y-auto">
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className={`rounded-3xl w-full max-w-[min(24rem,100%)] shadow-2xl relative border-[1px] transition-colors flex flex-col overflow-hidden max-h-[min(85vh,100%)] my-auto ${
                  isDarkMode
                    ? "bg-gray-900 border-gray-700 text-white"
                    : "bg-white border-gray-200 text-slate-900"
                }`}
              >
                {/* Modal Header */}
                <div
                  className={`p-4 border-b flex justify-between items-center shrink-0 ${
                    isDarkMode
                      ? "bg-gray-800/50 border-gray-700"
                      : "bg-gray-50 border-gray-200"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-indigo-500 flex items-center justify-center text-white">
                      <Gift size={16} />
                    </div>
                    <div>
                      <h3 className="font-extrabold text-sm tracking-tight">
                        Daily Login Bonus
                      </h3>
                      <span className="text-[10px] text-slate-400 dark:text-gray-500 block -mt-0.5">
                        Free daily credits for returning users
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      setShowDailyBonusModal(false);
                      playSound("bet");
                    }}
                    className={`w-7 h-7 rounded-full flex items-center justify-center transition-colors cursor-pointer ${
                      isDarkMode
                        ? "hover:bg-gray-700 text-gray-400"
                        : "hover:bg-gray-200 text-slate-500"
                    }`}
                  >
                    <X size={16} />
                  </button>
                </div>

                {/* Modal Content */}
                <div className="p-5 flex flex-col gap-4 text-xs shrink-0 items-center text-center">
                  <div className="relative my-2">
                    {/* Animated visual elements */}
                    <motion.div
                      animate={{ scale: [1, 1.05, 1] }}
                      transition={{
                        repeat: Infinity,
                        duration: 2,
                        ease: "easeInOut",
                      }}
                      className="w-20 h-20 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-400 flex items-center justify-center shadow-lg border-4 border-yellow-200 dark:border-yellow-500/30"
                    >
                      <Coins size={38} className="text-white animate-pulse" />
                    </motion.div>
                    <div className="absolute -top-1 -right-1 text-xl animate-bounce">
                      ✨
                    </div>
                    <div className="absolute -bottom-1 -left-1 text-lg">🎉</div>
                  </div>

                  <div>
                    <h4 className="font-black text-lg tracking-tight">
                      Welcome Back!
                    </h4>
                    <p className="text-[11px] text-slate-400 dark:text-gray-400 mt-1 max-w-[240px] mx-auto">
                      Here is your free daily login bonus to keep the fun
                      rolling and place food slots spins!
                    </p>
                  </div>

                  <div className="w-full p-4 rounded-2xl bg-gradient-to-br from-yellow-500/10 to-amber-500/10 border border-yellow-500/20 text-center relative overflow-hidden flex flex-col items-center">
                    <span className="text-[10px] font-bold text-yellow-600 dark:text-yellow-500 uppercase tracking-widest block mb-1">
                      Today's Claimable Reward
                    </span>
                    <span className="font-mono text-3xl font-black text-yellow-600 dark:text-yellow-500 tracking-tight">
                      +250 Coins
                    </span>
                  </div>

                  <button
                    type="button"
                    disabled={dailyBonusClaimed}
                    onClick={handleClaimDailyBonus}
                    className={`w-full py-3 px-4 bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-600 hover:to-amber-600 active:scale-[0.98] disabled:opacity-50 transition-all text-white font-extrabold text-sm rounded-xl shadow-lg flex items-center justify-center gap-2 cursor-pointer`}
                  >
                    <Gift size={16} />
                    {dailyBonusClaimed ? "Claimed today!" : "Claim Reward"}
                  </button>

                  <span className="text-[9px] text-slate-400 dark:text-gray-500 -mt-2">
                    Resets daily at local midnight.
                  </span>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {justWonJackpot && (
            <div className="absolute inset-0 z-[400] flex items-center justify-center p-4 bg-black/80 backdrop-blur-lg">
              <motion.div
                initial={{ opacity: 0, scale: 0.5, y: -50 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.8, y: 50 }}
                className={`rounded-3xl p-6 w-full max-w-sm text-center shadow-2xl relative border-4 flex flex-col items-center justify-center overflow-hidden transition-colors duration-300 ${
                  isDarkMode
                    ? "bg-gradient-to-b from-gray-900 via-gray-850 to-amber-950/40 border-amber-500 text-white"
                    : "bg-gradient-to-b from-white via-amber-50/50 to-yellow-50/70 border-yellow-400 text-slate-900"
                }`}
              >
                {/* Simulated Confetti Accents */}
                <div className="absolute top-2 left-4 text-purple-400 text-xl animate-bounce">
                  🎈
                </div>
                <div className="absolute top-8 right-6 text-yellow-400 text-2xl animate-spin">
                  ⚡
                </div>
                <div className="absolute bottom-10 left-8 text-green-400 text-xl animate-bounce">
                  ✨
                </div>
                <div className="absolute bottom-6 right-10 text-rose-400 text-2xl animate-pulse">
                  🎉
                </div>

                <h3 className="font-extrabold text-2xl text-yellow-500 uppercase tracking-widest flex items-center gap-1 animate-pulse mb-2">
                  👑 Jackpot drawn!
                </h3>

                <div className="relative my-4 flex flex-col items-center">
                  <div className="w-20 h-20 rounded-full border-4 border-yellow-400 overflow-hidden shadow-xl bg-gray-200">
                    <img
                      src={justWonJackpot.winnerAvatar}
                      className="w-full h-full object-cover"
                      alt="Winner"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="absolute -bottom-2 bg-yellow-500 text-yellow-950 text-[10px] font-black uppercase px-2 py-0.5 rounded-full shadow cursor-default">
                    LUCKY WINNER
                  </div>
                </div>

                <div className="mt-4 mb-5">
                  <span className="text-[11px] uppercase tracking-wider font-bold text-slate-400 dark:text-gray-500 block">
                    Congratulations
                  </span>
                  <span className="font-extrabold text-lg text-emerald-500 dark:text-emerald-400 block truncate max-w-[200px]">
                    {justWonJackpot.winnerName}
                  </span>
                  <div className="mt-3 inline-flex items-center gap-2 bg-yellow-500/10 border border-yellow-500/20 px-3.5 py-1.5 rounded-2xl">
                    <Coins size={16} className="text-yellow-500 shrink-0" />
                    <span className="font-extrabold text-xl font-mono text-yellow-500">
                      {justWonJackpot.prizeAmount.toLocaleString()}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 dark:text-gray-500 block mt-2 text-center max-w-[220px]">
                    The award has been dispatched instantly and credited
                    directly to the lucky player's account.
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setJustWonJackpot(null);
                    playSound("bet");
                  }}
                  className={`w-full font-bold py-2.5 rounded-xl active:translate-y-0.5 transition-all text-sm cursor-pointer ${
                    isDarkMode
                      ? "bg-amber-600 hover:bg-amber-500 text-white shadow-md shadow-amber-950"
                      : "bg-yellow-500 hover:bg-yellow-400 text-yellow-950 shadow-md shadow-yellow-200"
                  }`}
                >
                  Awesome claim!
                </button>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {showJackpotModal && (
            <div className="absolute inset-0 z-[300] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className={`rounded-3xl w-full max-w-sm shadow-2xl relative border-[1px] transition-colors flex flex-col overflow-hidden max-h-[85vh] ${
                  isDarkMode
                    ? "bg-gray-900 border-gray-700 text-white"
                    : "bg-white border-gray-200 text-slate-900"
                }`}
              >
                {/* Modal Header */}
                <div
                  className={`p-4 border-b flex justify-between items-center shrink-0 ${
                    isDarkMode
                      ? "bg-gray-800/50 border-gray-700"
                      : "bg-gray-50 border-gray-200"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-yellow-500 flex items-center justify-center text-white">
                      👑
                    </div>
                    <div>
                      <h3 className="font-extrabold text-sm tracking-tight">
                        Daily Jackpot Draw
                      </h3>
                      <span className="text-[10px] text-slate-400 dark:text-gray-500 block -mt-0.5">
                        Pool a portion of every spin's cost
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      setShowJackpotModal(false);
                      playSound("bet");
                    }}
                    className={`w-7 h-7 rounded-full flex items-center justify-center transition-colors cursor-pointer ${
                      isDarkMode
                        ? "hover:bg-gray-700 text-gray-400"
                        : "hover:bg-gray-200 text-slate-500"
                    }`}
                  >
                    <X size={16} />
                  </button>
                </div>

                {/* Modal Content */}
                <div className="p-4 overflow-y-auto flex-1 flex flex-col gap-4 text-xs">
                  {/* Big Pool Display */}
                  <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-500/10 to-yellow-500/10 border border-yellow-500/20 text-center relative overflow-hidden flex flex-col items-center">
                    <span className="text-[10px] font-bold text-yellow-500 uppercase tracking-widest block mb-1">
                      Current Reward Pool
                    </span>
                    <div className="flex items-center gap-2">
                      <Coins
                        size={22}
                        className="text-yellow-500 animate-pulse shrink-0"
                      />
                      <span className="font-mono text-3xl font-black text-yellow-500 tracking-tight">
                        {jackpotPool.toLocaleString()}
                      </span>
                    </div>

                    <div className="mt-3 flex items-center gap-1.5 bg-black/10 dark:bg-black/35 py-1 px-3 rounded-full text-[11px] font-mono">
                      <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-ping shrink-0" />
                      <span>Trigger:</span>
                      <span className="font-bold text-amber-500">
                        Hitting 🍕 Pizza
                      </span>
                    </div>
                  </div>

                  {/* Rules Details */}
                  <div
                    className={`p-3 rounded-xl border flex flex-col gap-1.5 ${
                      isDarkMode
                        ? "bg-gray-800/45 border-gray-700"
                        : "bg-slate-50 border-gray-200"
                    }`}
                  >
                    <span className="font-bold uppercase tracking-wider text-[9px] text-amber-500">
                      📜 How does the jackpot work?
                    </span>
                    <p className="text-slate-500 dark:text-gray-400 leading-normal text-[10.5px]">
                      A portion of{" "}
                      <strong className="text-amber-500">
                        2% of every spin's total cost
                      </strong>{" "}
                      placed by any user is added directly to this pooled
                      jackpot.
                    </p>
                    <p className="text-slate-500 dark:text-gray-400 leading-normal text-[10.5px]">
                      When the rare{" "}
                      <strong className="text-amber-500">
                        🍕 Pizza combination
                      </strong>{" "}
                      is rolled on the wheel, the entire jackpot pool is
                      distributed to{" "}
                      <strong className="text-amber-500">
                        lucky players who bet on Pizza
                      </strong>
                      !
                    </p>
                  </div>

                  {/* Sandbox Playtesting triggers */}
                  <div
                    className={`p-3 rounded-xl border flex flex-col gap-2 ${
                      isDarkMode
                        ? "bg-amber-950/20 border-amber-500/20"
                        : "bg-amber-100/10 border-amber-400/20"
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <span className="font-bold uppercase tracking-wider text-[9px] text-amber-500">
                        🛠️ Sandboxed Playground (Demo)
                      </span>
                      <span className="bg-yellow-500/15 text-yellow-500 text-[8px] font-black uppercase px-1.5 py-0.5 rounded">
                        TEST ENVIRONMENT
                      </span>
                    </div>
                    <p className="text-slate-400 dark:text-gray-500 text-[10px]">
                      Don't want to wait for the Pizza to finally roll? Run a
                      simulated jackpot drawing immediately!
                    </p>
                    <button
                      onClick={async () => {
                        playSound("bet");
                        try {
                          await fetch("/api/jackpot/draw", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({
                              triggeredBy: `Sandbox of ${playerName}`,
                            }),
                          });
                        } catch (err) {
                          console.warn("Manual jackpot draw failed", err);
                        }
                      }}
                      className="w-full font-bold py-2 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 text-white rounded-lg shadow cursor-pointer text-center text-[11px] transition-all"
                    >
                      🎰 Force Drawing Now!
                    </button>
                  </div>

                  {/* Winners List log */}
                  <div className="flex-1 flex flex-col gap-2">
                    <span className="font-bold uppercase tracking-wider text-[9px] text-slate-400 dark:text-gray-500 font-mono">
                      Recent Jackpot Winners list ({jackpotWinners.length})
                    </span>

                    <div className="flex-1 overflow-y-auto max-h-[140px] flex flex-col gap-2 pr-1 scrollbar-thin">
                      {jackpotWinners.length === 0 ? (
                        <div className="text-center py-6 text-slate-400 dark:text-gray-500 font-medium italic text-[10.5px] border-2 border-dashed border-slate-200 dark:border-gray-850 rounded-xl">
                          No jackpots drawn yet. Be the first one!
                        </div>
                      ) : (
                        jackpotWinners.map((winner, idx) => (
                          <div
                            key={`jackpot_win_v3_${winner.id || "id"}_${idx}`}
                            className={`p-2 rounded-xl border flex items-center justify-between gap-2 shadow-sm ${
                              isDarkMode
                                ? "bg-gray-800/50 border-gray-700/80"
                                : "bg-[#FAF9F6] border-gray-200"
                            }`}
                          >
                            <div className="flex items-center gap-2 overflow-hidden">
                              <img
                                src={
                                  winner.avatar ||
                                  `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(winner.name)}`
                                }
                                className="w-5 h-5 rounded-full object-cover shrink-0 p-px bg-yellow-400"
                                alt="Avatar"
                                referrerPolicy="no-referrer"
                              />
                              <div className="flex flex-col min-w-0">
                                <span className="font-bold text-[11px] text-emerald-500 dark:text-emerald-400 truncate max-w-[120px]">
                                  {winner.name}
                                </span>
                                <span className="text-[9px] text-slate-400 dark:text-gray-500 font-medium font-mono">
                                  {winner.date}
                                </span>
                              </div>
                            </div>

                            <div className="font-bold text-yellow-500 font-mono text-xs flex items-center gap-0.5 shrink-0 bg-yellow-500/5 px-2 py-0.5 border border-yellow-500/10 rounded-full">
                              <Coins
                                size={10}
                                className="shrink-0 text-yellow-500"
                              />
                              {winner.amount.toLocaleString()}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {showHistoryModal && (
          <div className="absolute inset-0 z-[300] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className={`rounded-3xl w-full max-w-lg shadow-2xl relative border-[1px] transition-colors flex flex-col overflow-hidden ${isDarkMode ? "bg-gray-900 border-gray-700" : "bg-white border-gray-200"}`}
              style={{ maxHeight: "85vh" }}
            >
              {/* Modal Header */}
              <div
                className={`p-4 border-b flex justify-between items-center shrink-0 ${isDarkMode ? "bg-gray-800/50 border-gray-700" : "bg-gray-50 border-gray-200"}`}
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-500 rounded-xl text-white shadow-lg shadow-blue-500/20">
                    <Clock size={20} />
                  </div>
                  <div>
                    <h2
                      className={`text-lg font-black tracking-tight ${isDarkMode ? "text-white" : "text-gray-900"}`}
                    >
                      Detailed Betting History
                    </h2>
                    <p
                      className={`text-[10px] font-bold uppercase tracking-wider ${isDarkMode ? "text-gray-500" : "text-gray-400"}`}
                    >
                      Last 100 rounds performance
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setShowHistoryModal(false)}
                  className={`p-2 rounded-xl transition-colors ${isDarkMode ? "hover:bg-gray-700 text-gray-400" : "hover:bg-gray-100 text-gray-500"}`}
                >
                  <X size={20} />
                </button>
              </div>

              {/* Modal Tabs */}
              <div
                className={`flex shrink-0 ${isDarkMode ? "bg-gray-800" : "bg-gray-100"}`}
              >
                <button
                  onClick={() => setHistoryModalTab("log")}
                  className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest transition-all ${historyModalTab === "log" ? (isDarkMode ? "bg-gray-900 text-blue-400 border-b-2 border-blue-500" : "bg-white text-blue-600 border-b-2 border-blue-500") : "text-gray-500 hover:text-gray-400"}`}
                >
                  Round Log
                </button>
                <button
                  onClick={() => setHistoryModalTab("stats")}
                  className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest transition-all ${historyModalTab === "stats" ? (isDarkMode ? "bg-gray-900 text-blue-400 border-b-2 border-blue-500" : "bg-white text-blue-600 border-b-2 border-blue-500") : "text-gray-500 hover:text-gray-400"}`}
                >
                  Betting Stats
                </button>
              </div>

              {historyModalTab === "log" ? (
                <>
                  {/* Sorting Controls */}
                  <div
                    className={`p-3 border-b flex gap-2 overflow-x-auto hide-scrollbar shrink-0 ${isDarkMode ? "bg-gray-900 border-gray-800" : "bg-white border-gray-100"}`}
                  >
                    <span
                      className={`text-[10px] font-black uppercase flex items-center px-1 whitespace-nowrap ${isDarkMode ? "text-gray-500" : "text-gray-400"}`}
                    >
                      Sort by:
                    </span>
                    {[
                      {
                        id: "id-desc",
                        label: "Round (Newest)",
                        icon: <ChevronDown size={14} />,
                      },
                      {
                        id: "id-asc",
                        label: "Round (Oldest)",
                        icon: <ChevronUp size={14} />,
                      },
                      {
                        id: "mult-desc",
                        label: "Multiplier (High)",
                        icon: <Sparkles size={14} />,
                      },
                    ].map((sort) => (
                      <button
                        key={`sort_hist_${sort.id}`}
                        onClick={() => setHistorySort(sort.id as any)}
                        className={`px-3 py-1.5 rounded-full text-[10px] font-bold border transition-all flex items-center gap-1.5 whitespace-nowrap ${historySort === sort.id ? (isDarkMode ? "bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-600/20" : "bg-blue-500 border-blue-400 text-white shadow-lg shadow-blue-500/20") : isDarkMode ? "bg-gray-800 border-gray-700 text-gray-400" : "bg-white border-gray-200 text-gray-600"}`}
                      >
                        {sort.icon} {sort.label}
                      </button>
                    ))}
                  </div>

                  {/* History Table */}
                  <div className="flex-1 overflow-y-auto custom-scrollbar p-2">
                    <table className="w-full border-collapse">
                      <thead className="sticky top-0 z-10">
                        <tr>
                          <th
                            className={`p-2 text-left text-[10px] font-black uppercase tracking-widest ${isDarkMode ? "bg-gray-900 text-gray-500" : "bg-white text-gray-400"}`}
                          >
                            Round
                          </th>
                          <th
                            className={`p-2 text-left text-[10px] font-black uppercase tracking-widest ${isDarkMode ? "bg-gray-900 text-gray-500" : "bg-white text-gray-400"}`}
                          >
                            Result
                          </th>
                          <th
                            className={`p-2 text-center text-[10px] font-black uppercase tracking-widest ${isDarkMode ? "bg-gray-900 text-gray-500" : "bg-white text-gray-400"}`}
                          >
                            Payout
                          </th>
                          <th
                            className={`p-2 text-right text-[10px] font-black uppercase tracking-widest ${isDarkMode ? "bg-gray-900 text-gray-500" : "bg-white text-gray-400"}`}
                          >
                            Time
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-800/10">
                        {(() => {
                          const ITEMS_PER_PAGE = 8;
                          const sorted = [...history].sort((a, b) => {
                            if (historySort === "id-desc")
                              return b.round - a.round;
                            if (historySort === "id-asc")
                              return a.round - b.round;
                            if (historySort === "mult-desc")
                              return b.multiplier - a.multiplier;
                            if (historySort === "mult-asc")
                              return a.multiplier - b.multiplier;
                            return 0;
                          });

                          const totalItems = sorted.length;
                          const totalPages =
                            Math.ceil(totalItems / ITEMS_PER_PAGE) || 1;

                          const currentPage = Math.min(historyPage, totalPages);
                          const start = (currentPage - 1) * ITEMS_PER_PAGE;
                          const end = start + ITEMS_PER_PAGE;
                          const pageItems = sorted.slice(start, end);

                          return (
                            <>
                              {pageItems.map((histItem, idx) => {
                                const food = ITEMS.find(
                                  (f) => f.id === histItem.id,
                                );
                                const isBigWin = histItem.multiplier >= 45;
                                return (
                                  <tr
                                    key={
                                      histItem.uid
                                        ? `${histItem.uid}_${idx}`
                                        : `table_hist_v4_${histItem.round || idx}_${histItem.timestamp || "time"}`
                                    }
                                    className={`group transition-colors ${isDarkMode ? "hover:bg-gray-800/40" : "hover:bg-gray-50"}`}
                                  >
                                    <td className="p-2">
                                      <span
                                        className={`text-xs font-mono font-bold ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}
                                      >
                                        #{histItem.round}
                                      </span>
                                    </td>
                                    <td className="p-2">
                                      <div className="flex items-center gap-2">
                                        <div
                                          className={`w-8 h-8 rounded-lg flex items-center justify-center shadow-inner border transition-all ${isBigWin ? "bg-gradient-to-br from-yellow-400/20 to-orange-500/20 border-orange-500/30" : isDarkMode ? "bg-gray-800 border-gray-700" : "bg-gray-100 border-gray-200"}`}
                                        >
                                          {food && (
                                            <ItemIcon
                                              icon={food.icon}
                                              className="text-lg flex items-center justify-center grayscale-[0.2] group-hover:grayscale-0 transition-all"
                                            />
                                          )}
                                        </div>
                                        <span
                                          className={`text-[11px] font-black tracking-tight ${isDarkMode ? "text-gray-200" : "text-gray-800"}`}
                                        >
                                          {food?.name}
                                        </span>
                                      </div>
                                    </td>
                                    <td className="p-2 text-center">
                                      <span
                                        className={`px-2 py-1 rounded-md text-[10px] font-black tracking-tighter ${isBigWin ? "bg-orange-500 text-white shadow-md shadow-orange-500/20" : isDarkMode ? "bg-gray-800 text-blue-400 border border-gray-700" : "bg-blue-50 text-blue-600 border border-blue-100"}`}
                                      >
                                        {histItem.multiplier}x
                                      </span>
                                    </td>
                                    <td className="p-2 text-right">
                                      <span
                                        className={`text-[10px] font-bold ${isDarkMode ? "text-gray-500" : "text-gray-400"}`}
                                      >
                                        {histItem.timestamp}
                                      </span>
                                    </td>
                                  </tr>
                                );
                              })}

                              {totalItems > 0 && (
                                <tr>
                                  <td colSpan={4} className="p-3">
                                    <div className="flex flex-col items-center justify-between gap-3 pt-2 border-t dark:border-gray-850 border-gray-100">
                                      <span
                                        className={`text-[9px] font-bold uppercase tracking-wider ${isDarkMode ? "text-gray-500" : "text-gray-400"}`}
                                      >
                                        Showing{" "}
                                        <span className="font-extrabold text-blue-500">
                                          {start + 1}
                                        </span>{" "}
                                        to{" "}
                                        <span className="font-extrabold text-blue-500">
                                          {Math.min(end, totalItems)}
                                        </span>{" "}
                                        of{" "}
                                        <span className="font-extrabold">
                                          {totalItems}
                                        </span>{" "}
                                        rounds
                                      </span>

                                      <div className="flex items-center gap-1">
                                        <button
                                          disabled={currentPage === 1}
                                          onClick={() =>
                                            setHistoryPage(currentPage - 1)
                                          }
                                          className={`p-1 rounded-lg border transition-all flex items-center justify-center disabled:opacity-30 ${isDarkMode ? "bg-gray-800 border-gray-700 hover:bg-gray-700 text-gray-300" : "bg-white border-gray-200 hover:bg-gray-50 text-gray-600"}`}
                                          style={{
                                            minWidth: "28px",
                                            minHeight: "28px",
                                          }}
                                          title="Previous Page"
                                        >
                                          <ChevronLeft size={12} />
                                        </button>

                                        {(() => {
                                          const getPageNumbers = () => {
                                            const pages = [];
                                            if (totalPages <= 5) {
                                              for (
                                                let i = 1;
                                                i <= totalPages;
                                                i++
                                              )
                                                pages.push(i);
                                            } else {
                                              pages.push(1);
                                              if (currentPage > 3)
                                                pages.push("...");

                                              const startPage = Math.max(
                                                2,
                                                currentPage - 1,
                                              );
                                              const endPage = Math.min(
                                                totalPages - 1,
                                                currentPage + 1,
                                              );

                                              for (
                                                let i = startPage;
                                                i <= endPage;
                                                i++
                                              ) {
                                                pages.push(i);
                                              }

                                              if (currentPage < totalPages - 2)
                                                pages.push("...");
                                              pages.push(totalPages);
                                            }
                                            return pages;
                                          };

                                          return getPageNumbers().map(
                                            (p, idx) => {
                                              if (p === "...") {
                                                return (
                                                  <span
                                                    key={`dots-${idx}`}
                                                    className={`px-1 text-[9px] font-bold ${isDarkMode ? "text-gray-600" : "text-gray-400"}`}
                                                  >
                                                    ...
                                                  </span>
                                                );
                                              }
                                              return (
                                                <button
                                                  key={`page-${p}-${idx}`}
                                                  onClick={() =>
                                                    setHistoryPage(p as number)
                                                  }
                                                  className={`text-[9px] font-black w-6 h-6 rounded-lg transition-all flex items-center justify-center ${
                                                    currentPage === p
                                                      ? "bg-blue-600 border border-blue-500 text-white shadow-md shadow-blue-600/10"
                                                      : isDarkMode
                                                        ? "bg-gray-800 border border-gray-700 hover:bg-gray-700 text-gray-300"
                                                        : "bg-white border border-gray-200 hover:bg-gray-50 text-gray-600"
                                                  }`}
                                                >
                                                  {p}
                                                </button>
                                              );
                                            },
                                          );
                                        })()}

                                        <button
                                          disabled={currentPage === totalPages}
                                          onClick={() =>
                                            setHistoryPage(currentPage + 1)
                                          }
                                          className={`p-1 rounded-lg border transition-all flex items-center justify-center disabled:opacity-30 ${isDarkMode ? "bg-gray-800 border-gray-700 hover:bg-gray-700 text-gray-300" : "bg-white border-gray-200 hover:bg-gray-50 text-gray-600"}`}
                                          style={{
                                            minWidth: "28px",
                                            minHeight: "28px",
                                          }}
                                          title="Next Page"
                                        >
                                          <ChevronRight size={12} />
                                        </button>
                                      </div>
                                    </div>
                                  </td>
                                </tr>
                              )}
                            </>
                          );
                        })()}
                      </tbody>
                    </table>
                    {history.length === 0 && (
                      <div className="flex flex-col items-center justify-center py-20 gap-4">
                        <div
                          className={`p-4 rounded-full ${isDarkMode ? "bg-gray-800" : "bg-gray-50"}`}
                        >
                          <Clock
                            size={32}
                            className="text-gray-400 opacity-20"
                          />
                        </div>
                        <p
                          className={`text-xs font-bold ${isDarkMode ? "text-gray-500" : "text-gray-400"}`}
                        >
                          Waiting for round completion...
                        </p>
                      </div>
                    )}
                  </div>
                </>
              ) : (
                <>
                  {/* Stats Sorting */}
                  <div
                    className={`p-3 border-b flex gap-2 overflow-x-auto hide-scrollbar shrink-0 ${isDarkMode ? "bg-gray-900 border-gray-800" : "bg-white border-gray-100"}`}
                  >
                    <span
                      className={`text-[10px] font-black uppercase flex items-center px-1 whitespace-nowrap ${isDarkMode ? "text-gray-500" : "text-gray-400"}`}
                    >
                      Sort by:
                    </span>
                    {[
                      {
                        id: "wins-desc",
                        label: "Wins",
                        icon: <Sparkles size={14} />,
                      },
                      {
                        id: "rate-desc",
                        label: "Win Rate",
                        icon: <ChevronDown size={14} />,
                      },
                      {
                        id: "mult-desc",
                        label: "Multiplier",
                        icon: <Sparkles size={14} />,
                      },
                    ].map((sort) => (
                      <button
                        key={`stat_${sort.id}`}
                        onClick={() => setStatsSort(sort.id as any)}
                        className={`px-3 py-1.5 rounded-full text-[10px] font-bold border transition-all flex items-center gap-1.5 whitespace-nowrap ${statsSort === sort.id ? (isDarkMode ? "bg-purple-600 border-purple-500 text-white shadow-lg shadow-purple-600/20" : "bg-purple-500 border-purple-400 text-white shadow-lg shadow-blue-500/20") : isDarkMode ? "bg-gray-800 border-gray-700 text-gray-400" : "bg-white border-gray-200 text-gray-600"}`}
                      >
                        {sort.icon} {sort.label}
                      </button>
                    ))}
                  </div>

                  <div className="flex-1 overflow-y-auto custom-scrollbar p-2">
                    <table className="w-full border-collapse">
                      <thead className="sticky top-0 z-10">
                        <tr>
                          <th
                            className={`p-2 text-left text-[10px] font-black uppercase tracking-widest ${isDarkMode ? "bg-gray-900 text-gray-500" : "bg-white text-gray-400"}`}
                          >
                            Item
                          </th>
                          <th
                            className={`p-2 text-center text-[10px] font-black uppercase tracking-widest ${isDarkMode ? "bg-gray-900 text-gray-500" : "bg-white text-gray-400"}`}
                          >
                            Wins
                          </th>
                          <th
                            className={`p-2 text-center text-[10px] font-black uppercase tracking-widest ${isDarkMode ? "bg-gray-900 text-gray-500" : "bg-white text-gray-400"}`}
                          >
                            Rate %
                          </th>
                          <th
                            className={`p-2 text-right text-[10px] font-black uppercase tracking-widest ${isDarkMode ? "bg-gray-900 text-gray-500" : "bg-white text-gray-400"}`}
                          >
                            Payout
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-800/10">
                        {ITEMS.map((f) => {
                          const wins = history.filter(
                            (h) => h.id === f.id,
                          ).length;
                          const rate =
                            history.length > 0
                              ? ((wins / history.length) * 100).toFixed(1)
                              : "0";
                          return { ...f, wins, rate: parseFloat(rate) };
                        })
                          .sort((a, b) => {
                            if (statsSort === "wins-desc")
                              return b.wins - a.wins;
                            if (statsSort === "rate-desc")
                              return b.rate - a.rate;
                            if (statsSort === "mult-desc")
                              return b.multiplier - a.multiplier;
                            return 0;
                          })
                          .map((stat, idx) => (
                            <tr
                              key={`stat_item_${stat.id}_${idx}`}
                              className={
                                isDarkMode
                                  ? "hover:bg-white/5"
                                  : "hover:bg-black/5"
                              }
                            >
                              <td className="p-2 text-xs font-bold flex items-center gap-1.5">
                                <div
                                  className={`w-8 h-8 rounded-lg flex items-center justify-center border ${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-gray-100 border-gray-200"}`}
                                >
                                  <ItemIcon
                                    icon={stat.icon}
                                    className="text-base"
                                  />
                                </div>
                                <span>{stat.name}</span>
                              </td>
                              <td className="p-2 text-center text-sm font-black">
                                {stat.wins}
                              </td>
                              <td className="p-2 text-center">
                                <div className="w-full bg-gray-200 dark:bg-gray-800 h-1 rounded-full overflow-hidden mb-1">
                                  <div
                                    className="bg-blue-500 h-full"
                                    style={{ width: `${stat.rate}%` }}
                                  ></div>
                                </div>
                                <span className="text-[9px] font-bold opacity-60">
                                  {stat.rate}%
                                </span>
                              </td>
                              <td className="p-2 text-right font-black text-xs">
                                {stat.multiplier}x
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                </>
              )}

              {/* Modal Footer */}
              <div
                className={`p-4 border-t shrink-0 ${isDarkMode ? "bg-gray-800/30 border-gray-800" : "bg-gray-50/50 border-gray-100"}`}
              >
                <button
                  onClick={() => setShowHistoryModal(false)}
                  className={`w-full py-3 rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg transition-all active:scale-[0.98] ${isDarkMode ? "bg-gray-800 text-white border border-gray-700 hover:bg-gray-700" : "bg-white text-gray-900 border border-gray-200 hover:bg-gray-50 shadow-gray-200"}`}
                >
                  Return to Lobby
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {checkoutData && (
        <div className="absolute inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className={`w-full max-w-sm rounded-[2rem] overflow-hidden shadow-2xl border-[3px] ${isDarkMode ? "bg-gray-900 border-gray-700 text-white" : "bg-white border-blue-500 text-gray-900"}`}
          >
            <div className="p-6">
              {paymentStep === "details" ? (
                <SecurePaymentGateway
                  checkoutData={checkoutData}
                  isDarkMode={isDarkMode}
                  playerName={playerName}
                  onClose={() => setCheckoutData(null)}
                  onSuccess={() =>
                    triggerSuccessfulPurchase(
                      checkoutData.total,
                      checkoutData.pkg.id,
                    )
                  }
                />
              ) : (
                <div className="text-center py-8 space-y-6">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto shadow-xl shadow-green-500/20"
                  >
                    <CheckCircle2 size={40} className="text-white" />
                  </motion.div>
                  <div>
                    <h4 className="text-2xl font-black">Payment Success!</h4>
                    <p className="text-sm opacity-60 mt-2">
                      {formatAmount(checkoutData.total)} coins have been added{" "}
                      <br /> to your vault instantly.
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      setCheckoutData(null);
                      setShowShop(false);
                    }}
                    className="w-full bg-gray-900 text-white font-black py-4 rounded-2xl"
                  >
                    BACK TO GAME
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}

      {/* Slide-over User Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <div className="absolute inset-0 z-[200] flex justify-end">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMenuOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm cursor-pointer"
            />
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className={`relative w-4/5 max-w-sm h-full flex flex-col shadow-2xl ${isDarkMode ? "bg-gray-900 border-l border-gray-800 text-white" : "bg-white border-l border-gray-200 text-gray-900"}`}
            >
              <div className="p-4 border-b flex justify-between items-center shrink-0">
                <h3 className="font-extrabold text-lg flex items-center gap-2">
                  <Menu size={20} /> Navigation
                </h3>
                <button
                  onClick={() => setIsMenuOpen(false)}
                  className={`p-2 rounded-xl transition-colors ${isDarkMode ? "hover:bg-gray-800" : "hover:bg-gray-100"}`}
                >
                  <X size={20} />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-6">
                {/* Google Cloud & Workspace Section */}
                <section>
                  <h4 className="font-bold mb-3 flex items-center gap-2 text-sky-400">
                    <Sparkles size={18} /> Cloud & Workspace
                  </h4>
                  <div className="grid grid-cols-1 gap-2">
                    <button
                      onClick={() => {
                        setIsMenuOpen(false);
                        setIsCloudSyncOpen(true);
                      }}
                      className={`p-3 border rounded-xl flex items-center gap-3 transition-colors text-left ctrl-cloud-sync ${isDarkMode ? "border-gray-800 hover:bg-gray-800" : "border-gray-200 hover:bg-gray-50"}`}
                    >
                      <div className="bg-sky-500/10 text-sky-500 p-2 rounded-lg">
                        <Sparkles size={16} />
                      </div>
                      <div>
                        <div className="font-bold text-sm">
                          Google Cloud Center
                        </div>
                        <div className="text-[10px] opacity-65">
                          Backup to Sheets, Calendar, Tasks
                        </div>
                      </div>
                    </button>
                  </div>
                </section>

                {/* Native App Installation Segment */}
                <section>
                  <h4
                    className={`font-bold mb-3 flex items-center gap-2 ${isDarkMode ? "text-indigo-400" : "text-indigo-600"}`}
                  >
                    <Smartphone size={18} /> Device Native Applet
                  </h4>
                  <div className="grid grid-cols-1 gap-2">
                    <button
                      onClick={() => {
                        handleInstallApp();
                      }}
                      className={`p-3 border rounded-xl flex items-center gap-3 transition-all text-left relative overflow-hidden group ${isDarkMode ? "border-indigo-950 bg-indigo-950/20 hover:bg-indigo-950/40" : "border-indigo-100 bg-indigo-50/50 hover:bg-indigo-100"}`}
                    >
                      <div className="bg-indigo-500/10 text-indigo-500 p-2 rounded-lg group-hover:scale-110 duration-200 transition-transform">
                        <Smartphone size={16} />
                      </div>
                      <div>
                        <div className="font-extrabold text-sm flex items-center gap-1.5 text-indigo-600 dark:text-indigo-400">
                          Install Native App
                          <span className="bg-indigo-500 text-white text-[8px] font-black px-1 rounded animate-pulse">
                            ANY DEVICE
                          </span>
                        </div>
                        <div className="text-[10px] opacity-70">
                          Run in full-screen on Mobile, Tablet & Desktop
                        </div>
                      </div>
                    </button>
                  </div>
                </section>

                {/* Help Center Section */}
                <section>
                  <h4 className="font-bold mb-3 flex items-center gap-2 text-blue-500">
                    <HelpCircle size={18} /> Help Center
                  </h4>
                  <div className="grid grid-cols-1 gap-2">
                    <button
                      onClick={() => {
                        setIsMenuOpen(false);
                        setIsLiveChatOpen(true);
                      }}
                      className={`p-3 border rounded-xl flex items-center gap-3 transition-colors text-left ${isDarkMode ? "border-gray-800 hover:bg-gray-800" : "border-gray-200 hover:bg-gray-50"}`}
                    >
                      <div className="bg-blue-500/10 text-blue-500 p-2 rounded-lg">
                        <HelpCircle size={16} />
                      </div>
                      <div>
                        <div className="font-bold text-sm">
                          Live Chat Support
                        </div>
                        <div className="text-[10px] opacity-60">
                          Connect to an agent now
                        </div>
                      </div>
                    </button>
                  </div>
                </section>

                {/* Display Settings Section */}
                <section>
                  <h4
                    className={`font-bold mb-3 flex items-center gap-2 ${isDarkMode ? "text-sky-400" : "text-sky-600"}`}
                  >
                    <Settings size={18} /> Display Settings
                  </h4>
                  <div className="grid grid-cols-1 gap-2">
                    <div
                      className={`p-3 border rounded-xl flex items-center justify-between transition-colors ${isDarkMode ? "border-gray-800 bg-gray-900/50" : "border-gray-200 bg-gray-50/50"}`}
                    >
                      <div className="flex flex-col">
                        <span className="font-bold text-sm">
                          Show Player Profile
                        </span>
                        <span className="text-[10px] opacity-60">
                          View avatar, live status & name
                        </span>
                      </div>
                      <button
                        onClick={() => {
                          const val = !showPlayerProfile;
                          setShowPlayerProfile(val);
                          localStorage.setItem(
                            "setting_show_profile",
                            val.toString(),
                          );
                        }}
                        className={`w-10 h-6 flex items-center rounded-full p-0.5 transition-colors duration-300 focus:outline-none shrink-0 ${showPlayerProfile ? "bg-sky-500" : "bg-gray-300 dark:bg-gray-700"}`}
                      >
                        <div
                          className={`bg-white w-5 h-5 rounded-full shadow-md transform transition-transform duration-300 ${showPlayerProfile ? "translate-x-4" : "translate-x-0"}`}
                        />
                      </button>
                    </div>

                    <div
                      className={`p-3 border rounded-xl flex items-center justify-between transition-colors ${isDarkMode ? "border-gray-800 bg-gray-900/50" : "border-gray-200 bg-gray-50/50"}`}
                    >
                      <div className="flex flex-col">
                        <span className="font-bold text-sm">
                          Show Jackpot Banner
                        </span>
                        <span className="text-[10px] opacity-60">
                          View progressive jackpot pool
                        </span>
                      </div>
                      <button
                        onClick={() => {
                          const val = !showJackpotBanner;
                          setShowJackpotBanner(val);
                          localStorage.setItem(
                            "setting_show_jackpot_banner",
                            val.toString(),
                          );
                        }}
                        className={`w-10 h-6 flex items-center rounded-full p-0.5 transition-colors duration-300 focus:outline-none shrink-0 ${showJackpotBanner ? "bg-sky-500" : "bg-gray-300 dark:bg-gray-700"}`}
                      >
                        <div
                          className={`bg-white w-5 h-5 rounded-full shadow-md transform transition-transform duration-300 ${showJackpotBanner ? "translate-x-4" : "translate-x-0"}`}
                        />
                      </button>
                    </div>
                  </div>
                </section>

                {/* FAQ Accordion Section */}
                <section>
                  <h4 className="font-bold mb-3">Frequently Asked Questions</h4>
                  <div className="space-y-2">
                    <FAQAccordionItem
                      isDarkMode={isDarkMode}
                      question="How do I place a bet?"
                      answer="Select an item, enter your amount, and hit 'Place Bet' before the timer ends."
                    />
                    <FAQAccordionItem
                      isDarkMode={isDarkMode}
                      question="How do I withdraw?"
                      answer="Transaction requests are processed through your registered deposit methods. Approvals may take up to 24 hours."
                    />
                    <FAQAccordionItem
                      isDarkMode={isDarkMode}
                      question="Is it fair?"
                      answer="Spinners use a server-side random number generator and weighted probability balancing to guarantee fair outcomes."
                    />
                  </div>
                </section>

                {/* Coin Seller Section */}
                <section>
                  <h4
                    className={`font-bold mb-3 flex items-center gap-2 ${isDarkMode ? "text-green-500" : "text-slate-800"}`}
                  >
                    <Store size={18} /> Reseller Program
                  </h4>
                  <div
                    className={`p-4 rounded-xl border ${isDarkMode ? "bg-green-950/30 border-green-900/50" : "bg-black/[0.03] border-slate-300 shadow-sm backdrop-blur-[4px]"}`}
                  >
                    <p
                      className={`text-xs mb-3 font-semibold ${isDarkMode ? "text-green-400" : "text-slate-700"}`}
                    >
                      Become verified to securely trade coins via P2P transfers.
                    </p>
                    <div className="space-y-2">
                      <button
                        onClick={() => {
                          setIsMenuOpen(false);
                          setCoinSellerModalStage("apply");
                          setIsCoinSellerModalOpen(true);
                        }}
                        className={`w-full py-2.5 border rounded-lg font-extrabold text-sm transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-1.5 ${isDarkMode ? "bg-green-500 hover:bg-green-600 text-white border-transparent" : "bg-slate-800 hover:bg-slate-900 text-white border-transparent shadow-sm"}`}
                      >
                        Apply to become Seller
                      </button>
                      <button
                        onClick={() => {
                          setIsMenuOpen(false);
                          setCoinSellerModalStage("login");
                          setIsCoinSellerModalOpen(true);
                        }}
                        className={`w-full py-2.5 border rounded-lg font-extrabold text-sm transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-1.5 ${isDarkMode ? "border-green-900/50 text-green-400 bg-green-950/20 hover:bg-green-950/40" : "border-slate-300 text-slate-700 bg-white hover:bg-slate-50 shadow-sm"}`}
                      >
                        Login as Seller
                      </button>
                    </div>
                  </div>
                </section>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Live Chat Modal */}
      {isLiveChatOpen && (
        <div
          className={`absolute inset-x-2 bottom-2 z-[250] flex flex-col rounded-2xl shadow-2xl border ${isDarkMode ? "bg-gray-900 border-gray-700" : "bg-white border-gray-200"} max-h-[80vh] overflow-hidden`}
        >
          <div
            className={`p-3 shrink-0 flex justify-between items-center ${isDarkMode ? "bg-blue-600 text-white" : "bg-blue-500 text-white"}`}
          >
            <h3 className="font-bold flex items-center gap-2 text-sm">
              <HelpCircle size={16} /> Live Support
            </h3>
            <button
              onClick={() => setIsLiveChatOpen(false)}
              className="hover:text-blue-200 transition-colors"
            >
              <X size={18} />
            </button>
          </div>
          <ChatBox
            messages={chatMessages.map((msg, idx) => ({
              id: msg.id || `msg_${idx}`,
              sender:
                msg.senderId === "CUSTOMER_01"
                  ? playerName || "Customer"
                  : "Agent",
              senderId:
                msg.senderId ||
                (msg.sender === "Agent" || msg.sender === "Admin"
                  ? "ADMIN_01"
                  : "CUSTOMER_01"),
              text: msg.text,
              avatar:
                msg.avatar ||
                (msg.senderId === "ADMIN_01" ||
                msg.sender === "Agent" ||
                msg.sender === "Admin"
                  ? "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=60"
                  : playerAvatar ||
                    "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=60"),
              mediaList: msg.mediaList || [],
              timestamp: msg.timestamp || new Date().toLocaleTimeString(),
            }))}
            currentUser={{
              id: "CUSTOMER_01",
              name: playerName,
              avatar: playerAvatar,
            }}
            isAdmin={false}
            isDarkMode={isDarkMode}
            onSendMessage={(text, mediaList) => {
              const messageObj = {
                sender: playerName,
                senderId: "CUSTOMER_01",
                text,
                mediaList: mediaList || [],
                avatar: playerAvatar,
                timestamp: new Date().toLocaleTimeString(),
              };
              if (socket.connected) {
                socket.emit("send_chat_message", messageObj);
              } else {
                console.warn("Socket not connected, message not sent");
              }
            }}
          />
        </div>
      )}

      {/* Coin Seller Auth & Panel */}
      <AnimatePresence>
        {isCoinSellerModalOpen && (
          <CoinSellerModal
            isOpen={isCoinSellerModalOpen}
            onClose={() => setIsCoinSellerModalOpen(false)}
            isDarkMode={isDarkMode}
            initialStage={coinSellerModalStage}
          />
        )}
      </AnimatePresence>

      {/* Cloud & Workspace Integration Sync Panel */}
      <AnimatePresence>
        {isCloudSyncOpen && (
          <CloudSyncModal
            isOpen={isCloudSyncOpen}
            onClose={() => setIsCloudSyncOpen(false)}
            isDarkMode={isDarkMode}
            localBalance={coins}
            onBalanceSynced={(newBalance) => {
              setCoins(newBalance);
              localStorage.setItem("player_coins", newBalance.toString());
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );

  const gameContentWrapper = isPipActive ? (
    <>
      <div className="flex-1 flex flex-col w-full h-full items-center justify-center px-4 text-center">
        <PictureInPicture2
          size={48}
          className={`mb-4 ${isDarkMode ? "text-gray-600" : "text-gray-400"}`}
        />
        <p
          className={`font-bold ${isDarkMode ? "text-gray-400" : "text-gray-600"}`}
        >
          Playing in Picture-in-Picture
        </p>
        <p
          className={`text-sm mt-2 ${isDarkMode ? "text-gray-500" : "text-gray-400"}`}
        >
          Close the mini-player to restore the game here.
        </p>
        <button
          onClick={() => setIsPipActive(false)}
          className="mt-6 px-6 py-2.5 bg-blue-500 hover:bg-blue-600 text-white font-bold rounded-xl shadow-md transition-all active:scale-95"
        >
          Restore Game
        </button>
      </div>
      <PipPortal
        active={isPipActive}
        onClose={() => setIsPipActive(false)}
        width={400}
        height={700}
      >
        <div className="w-full h-full relative overflow-hidden flex flex-col m-0 p-0">
          {gameContent}
        </div>
      </PipPortal>
    </>
  ) : (
    gameContent
  );

  const pageBackdropStyle = {
    backgroundImage: isDarkMode
      ? "radial-gradient(#374151 1px, transparent 1px)"
      : "radial-gradient(#A3A198 1.5px, transparent 1.5px)",
    backgroundSize: "10px 10px",
  } as const;

  return (
    <div
      className={`flex min-h-[100dvh] h-full w-full justify-center transition-colors duration-300 ${isDarkMode ? "bg-gray-900" : "bg-[#D1CFC7]"}`}
      style={pageBackdropStyle}
    >
      <div
        className={`relative flex h-full min-h-[100dvh] w-full flex-col shadow-2xl transition-colors duration-300 ${
          isIframe ? "max-w-none border-0" : "md:max-w-md md:border-x"
        } ${isDarkMode ? "bg-gray-900 border-gray-800" : "bg-[#D1CFC7] border-gray-300"}`}
        style={pageBackdropStyle}
      >
        {gameContentWrapper}
      </div>
    </div>
  );
}
