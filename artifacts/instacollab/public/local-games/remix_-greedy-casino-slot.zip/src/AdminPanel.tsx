import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameItem } from './types';
import { Link } from 'react-router-dom';
import { ItemIcon } from './components/ItemIcon';
import { AdminItemCard } from './components/AdminItemCard';
import { socket } from './socket';
import { Home, Users, DollarSign, Gift, Settings, BarChart3, Sun, Moon, LogOut, CheckCircle2, Gamepad2, ChevronLeft, ChevronRight, Menu, X, History, Trash2, Download, Printer, Clock, Sparkles, Lock, CreditCard, RefreshCw, HelpCircle, Store, ChevronDown, ChevronUp, ShieldCheck, CircleDashed, MessageSquare, Paperclip } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ChatBox } from './components/ChatBox';

socket.on('connect_error', (err) => {
  console.warn('Admin socket connection error handled:', err.message);
});

socket.on('connect_failed', () => {
  console.warn('Admin socket connection failed');
});

const LiveClock = () => {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);
  return (
    <div className="font-mono text-xs opacity-70 bg-black/5 dark:bg-white/5 border border-current/10 px-2 flex items-center gap-1.5 rounded h-6">
      <Clock size={10} />
      {time.toLocaleDateString()} {time.toLocaleTimeString('en-US', { hour12: true })}
    </div>
  );
};

const getFormattedTime = (raw: number | undefined, backup: string) => {
  if (!raw) return backup;
  try {
    return new Date(raw).toLocaleTimeString('en-US', { hour12: true });
  } catch (e) {
    return backup;
  }
};

const getFormattedDate = (raw: number | undefined) => {
  const target = raw ? new Date(raw) : new Date();
  try {
    return target.toLocaleDateString('en-US');
  } catch (e) {
    return new Date().toLocaleDateString('en-US');
  }
};

const FAQAccordionItem = ({ question, answer, isDarkMode }: { question: string, answer: string, isDarkMode: boolean }) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className={`border rounded-xl overflow-hidden ${isDarkMode ? 'border-gray-700 bg-gray-750' : 'border-gray-200 bg-white'}`}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`w-full flex justify-between items-center p-4 text-left font-bold transition-colors ${isDarkMode ? 'hover:bg-gray-700/50' : 'hover:bg-gray-50'}`}
      >
        <span>{question}</span>
        <div className={`transition-transform duration-200 ${isOpen ? 'rotate-180 text-blue-500' : 'text-gray-400'}`}>
          <ChevronDown size={20} />
        </div>
      </button>
      <div className={`overflow-hidden transition-all duration-300 ease-in-out ${isOpen ? 'max-h-[500px] opacity-100' : 'max-h-0 opacity-0'}`}>
        <div className={`p-4 pt-0 text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
          {answer}
        </div>
      </div>
    </div>
  );
};

const adminFetch = async (input: RequestInfo | URL, init?: RequestInit) => {
  const urlStr = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url;
  const updatedInit = init ? { ...init } : {};
  if (urlStr.includes('/api/admin') && !urlStr.includes('/verify')) {
    let token = 'admin123';
    try {
      token = localStorage.getItem('admin_mode') === 'real' ? 'Weilin1500@' : 'admin123';
    } catch {
      token = 'admin123';
    }
    updatedInit.headers = {
      ...(updatedInit.headers || {}),
      'Authorization': `Bearer ${token}`
    };
  }
  return window.fetch(input, updatedInit);
};

export default function AdminPanel({ items, setItems }: { items: GameItem[], setItems: React.Dispatch<React.SetStateAction<GameItem[]>> }) {
  const fetch = adminFetch;
  const [localItems, setLocalItems] = useState(items);
  const [status, setStatus] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    try {
      return localStorage.getItem('admin_authenticated') === 'true';
    } catch {
      return false;
    }
  });
  const [adminMode, setAdminMode] = useState<'real' | 'demo'>(() => {
    try {
      return (localStorage.getItem('admin_mode') as 'real' | 'demo') || 'demo';
    } catch {
      return 'demo';
    }
  });
  const [password, setPassword] = useState('');
  const [isDarkMode, setIsDarkMode] = useState(() => {
    try {
      return localStorage.getItem('admin_theme') === 'dark' || false;
    } catch {
      return false;
    }
  });
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(() => {
    try {
      return localStorage.getItem('admin_sidebar_collapsed') === 'true' || false;
    } catch {
      return false;
    }
  });
  const [gameState, setGameState] = useState('loading');
  const [winItemIndex, setWinItemIndex] = useState<number | null>(null);
  const [projectedWinItemIndex, setProjectedWinItemIndex] = useState<number>(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const [totalBets, setTotalBets] = useState<Record<string, number>>({});
  const [activeBets, setActiveBets] = useState<{ id?: string, username: string, avatar: string, itemId: string, amount: number, timestamp?: string, timestampRaw?: number }[]>([]);
  const [serverUsers, setServerUsers] = useState<any[]>([]);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [allHistoricalBets, setAllHistoricalBets] = useState<any[]>([]);
  const [searchBetsQuery, setSearchBetsQuery] = useState('');
  const [betsLogTimeFilter, setBetsLogTimeFilter] = useState<'today' | 'week' | 'month' | 'year' | 'all'>('all');
  const [forceWinIndex, setForceWinIndex] = useState<number | null>(null);
  const [autoAiEnabled, setAutoAiEnabled] = useState(true);
  const [lastAiAnalysis, setLastAiAnalysis] = useState("AI Engine ready. Waiting for bets to analyze...");
  const [shopBonuses, setShopBonuses] = useState<Record<string, number>>({ '1': 0, '2': 0, '3': 0, '4': 0, '5': 0, '6': 0 });
  const [isBetaEnabled, setIsBetaEnabled] = useState(() => {
    try {
      return localStorage.getItem('admin_beta_enabled') === 'true';
    } catch {
      return false;
    }
  });
  const [isCheckingUpdates, setIsCheckingUpdates] = useState(false);
  const [updateStatus, setUpdateStatus] = useState<'idle' | 'checking' | 'latest' | 'update'>('idle');
  const [isLiveChatOpen, setIsLiveChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<any[]>([
    {
      id: "admin_init_1",
      sender: 'Agent',
      senderId: 'ADMIN_01',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=60',
      text: 'Hello! How can I help you today?',
      timestamp: new Date().toLocaleTimeString(),
      mediaList: []
    }
  ]);
  const [newChatMessage, setNewChatMessage] = useState('');
  const [transactionTimeFilter, setTransactionTimeFilter] = useState<'today' | 'month' | 'year'>('today');
  const [sellerApplications, setSellerApplications] = useState<any[]>([]);
  const [activeManagementUser, setActiveManagementUser] = useState<any>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  const [isSecureAddCoinOpen, setIsSecureAddCoinOpen] = useState(false);
  const [selectedTargetUserId, setSelectedTargetUserId] = useState('');
  const [addCoinAmount, setAddCoinAmount] = useState<number>(25000);
  const [isSecureMinting, setIsSecureMinting] = useState(false);
  const [secureMintCardNumber, setSecureMintCardNumber] = useState('4111 2222 3333 4444');
  const [secureMintExpiry, setSecureMintExpiry] = useState('00/00');
  const [secureMintCvc, setSecureMintCvc] = useState('999');
  const [secureMintName, setSecureMintName] = useState('SYSTEM ADMINISTRATOR');
  const [secureMintCvcFocused, setSecureMintCvcFocused] = useState(false);
  const [secureMintStep, setSecureMintStep] = useState<'idle' | 'encrypting' | 'routing' | 'verifying' | 'success'>('idle');
  const [secureMintStepText, setSecureMintStepText] = useState('');
  const [secureMintTargetType, setSecureMintTargetType] = useState<'user' | 'seller'>('user');
  const [secureMintSearchQuery, setSecureMintSearchQuery] = useState('');
  const [secureMintCustomAmount, setSecureMintCustomAmount] = useState('');

  const [devPlatform, setDevPlatform] = useState<"ios" | "android">(() => {
    try {
      return (localStorage.getItem("dev_platform") as any) || "ios";
    } catch {
      return "ios";
    }
  });
  const [devSize, setDevSize] = useState<"small" | "medium" | "large">(() => {
    try {
      return (localStorage.getItem("dev_size") as any) || "medium";
    } catch {
      return "medium";
    }
  });

  const getItemWeight = (item: GameItem) => {
    if (typeof item.weight === 'number') return item.weight;
    if (item.id === 'salad') return 1;
    if (item.id === 'pizza') return 0.1;
    return 15;
  };

  const totalWeight = localItems.reduce((acc, item) => acc + getItemWeight(item), 0) || 1;

  const applyPreset = (presetType: 'default' | 'equal' | 'meat' | 'veggie' | 'lucky') => {
    const updated = localItems.map(item => {
      let weight = 12;
      if (presetType === 'default') {
        if (item.id === 'salad') weight = 1;
        else if (item.id === 'pizza') weight = 0.1;
        else weight = 15;
      } else if (presetType === 'equal') {
        weight = 10;
      } else if (presetType === 'meat') {
        if (['hotdog', 'skewer', 'ham', 'steak'].includes(item.id)) weight = 20;
        else if (['carrot', 'corn', 'cabbage', 'tomato'].includes(item.id)) weight = 4;
        else if (item.id === 'salad') weight = 1;
        else if (item.id === 'pizza') weight = 0.1;
      } else if (presetType === 'veggie') {
        if (['carrot', 'corn', 'cabbage', 'tomato'].includes(item.id)) weight = 20;
        else if (['hotdog', 'skewer', 'ham', 'steak'].includes(item.id)) weight = 4;
        else if (item.id === 'salad') weight = 1;
        else if (item.id === 'pizza') weight = 0.1;
      } else if (presetType === 'lucky') {
        if (item.id === 'salad') weight = 5;
        else if (item.id === 'pizza') weight = 2;
        else weight = 9;
      }
      return { ...item, weight };
    });
    setLocalItems(updated);
  };

  useEffect(() => {
    const handleStorage = () => {
      try {
        setDevPlatform((localStorage.getItem("dev_platform") as any) || "ios");
        setDevSize((localStorage.getItem("dev_size") as any) || "medium");
      } catch {
        // fail silently
      }
    };
    window.addEventListener("storage", handleStorage);
    const interval = setInterval(handleStorage, 1000);
    return () => {
      window.removeEventListener("storage", handleStorage);
      clearInterval(interval);
    };
  }, []);


  const getItemChance = (item: GameItem, idx: number) => {
    if (forceWinIndex === idx) return "100";
    if (autoAiEnabled && projectedWinItemIndex === idx) return "100";
    if (forceWinIndex !== null || (autoAiEnabled && projectedWinItemIndex !== null)) return "0";
    const totalWeightVal = localItems.reduce((acc, item) => acc + getItemWeight(item), 0) || 1;
    return ((getItemWeight(item) / totalWeightVal) * 100).toFixed(1);
  };
  useEffect(() => {
    fetch('/api/admin/seller-applications')
      .then(res => {
        if (!res.ok) throw new Error("Unauthorized or server error");
        return res.json();
      })
      .then(data => {
        if (Array.isArray(data)) {
          setSellerApplications(data);
        }
      })
      .catch(() => {});

    return () => {
      // socket.off('seller_applications_update'); // Listener moved to authenticated effect
    };
  }, []);

  useEffect(() => {
    if (chatBottomRef.current) {
      chatBottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages, isLiveChatOpen]);

  const handleSendChatMessage = () => {
    if (!newChatMessage.trim()) return;
    setChatMessages(prev => [...prev, { sender: 'You', text: newChatMessage.trim() }]);
    setNewChatMessage('');
    setTimeout(() => {
      setChatMessages(prev => [...prev, { sender: 'Agent', text: 'Thank you for your message. An agent will be with you shortly.' }]);
    }, 1000);
  };

  const handleApproveSeller = (id: string) => {
    fetch(`/api/admin/seller-applications/${id}/approve`, { method: 'POST' })
      .then(res => res.json())
      .then(data => {
        if (data.success && data.application) {
          setSellerApplications(prev => prev.map(a => a.id === id ? data.application : a));
        }
      })
      .catch(console.error);
  };

  const handleRejectSeller = (id: string) => {
    fetch(`/api/admin/seller-applications/${id}/reject`, { method: 'POST' })
      .then(res => res.json())
      .then(data => {
        if (data.success && data.application) {
          setSellerApplications(prev => prev.map(a => a.id === id ? data.application : a));
        }
      })
      .catch(console.error);
  };

  const handleRemoveSeller = (id: string) => {
    console.log(`Debug: handleRemoveSeller called for ${id}`);
    fetch(`/api/admin/seller-applications/${id}`, { method: 'DELETE' })
      .then(res => res.json())
      .then(data => {
        console.log(`Debug: DELETE response for ${id}:`, data);
        if (data.success) {
          setSellerApplications(prev => prev.filter(a => a.id !== id));
        } else {
           console.error(`Debug: DELETE failed for ${id}:`, data.error);
        }
      })
      .catch(err => console.error("Debug: DELETE request failed:", err));
  };

  const handleAdminAddStock = (id: string, amount: number) => {
    fetch(`/api/admin/seller/${id}/add-stock`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount })
    })
      .then(res => res.json())
      .then(data => {
        if (data.success && data.seller) {
          setSellerApplications(prev => prev.map(a => a.id === id ? data.seller : a));
          alert(`Successfully added ${amount.toLocaleString()} coins to owner/seller's stock.`);
        } else {
          alert("Failed to reload stock: " + (data.error || "Unknown"));
        }
      })
      .catch(err => {
        console.error(err);
        alert("Communications error while allocating stock.");
      });
  };

  const downloadTransactions = () => {
    if (!transactions.length) return;
    const header = "ID,User ID,Name,Email,Type,Amount,Date,Seller ID\n";
    const csv = transactions.map(t => `${t.id},${t.userId},"${t.userName || t.userId}","${t.userEmail || ''}",${t.type},${t.amount},"${t.date}",${t.sellerId || ''}`).join("\n");
    const blob = new Blob([header + csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `transactions_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const getFilteredTransactions = (type: string) => {
    let filtered = transactions.filter(t => t.type === type);
    const now = new Date();
    if (transactionTimeFilter === 'today') {
      filtered = filtered.filter(t => new Date(t.date).toDateString() === now.toDateString());
    } else if (transactionTimeFilter === 'month') {
      filtered = filtered.filter(t => new Date(t.date).getMonth() === now.getMonth() && new Date(t.date).getFullYear() === now.getFullYear());
    } else if (transactionTimeFilter === 'year') {
      filtered = filtered.filter(t => new Date(t.date).getFullYear() === now.getFullYear());
    }
    return filtered;
  };

  const handleToggleAi = (val: boolean) => {
    fetch('/api/admin/toggle-ai', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ enabled: val })
    })
    .then(res => res.json())
    .then(data => {
      setAutoAiEnabled(data.autoAiEnabled);
    })
    .catch(err => console.error("Could not toggle AI", err));
  };

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      try { localStorage.setItem('admin_theme', 'dark'); } catch {}
    } else {
      document.documentElement.classList.remove('dark');
      try { localStorage.setItem('admin_theme', 'light'); } catch {}
    }
  }, [isDarkMode]);

  useEffect(() => {
    setLocalItems(items);
  }, [items]);

  useEffect(() => {
    if (isAuthenticated) {
      socket.on('initial_state', (state: any) => {
        setGameState(state.gameState);
        setTimeLeft(state.timeLeft);
        if (state.winItemIndex !== undefined) setWinItemIndex(state.winItemIndex);
        if (state.projectedWinItemIndex !== undefined) setProjectedWinItemIndex(state.projectedWinItemIndex);
        if (state.forcedWinItemIndex !== undefined) setForceWinIndex(state.forcedWinItemIndex);
        setTotalBets(state.totalBets || {});
        setActiveBets(state.activeBets || []);
        if (state.allHistoricalBets) setAllHistoricalBets(state.allHistoricalBets);
        if (state.autoAiEnabled !== undefined) setAutoAiEnabled(state.autoAiEnabled);
        if (state.lastAiAnalysis !== undefined) setLastAiAnalysis(state.lastAiAnalysis);
        if (state.shopBonuses !== undefined) setShopBonuses(state.shopBonuses);
        if (state.chatMessages !== undefined) setChatMessages(state.chatMessages);
      });

      socket.on('chat_message_received', (newMsg: any) => {
        setChatMessages(prev => {
          if (prev.some(m => m.id === newMsg.id)) return prev;
          return [...prev, newMsg];
        });
      });

      socket.on('seller_applications_update', (data) => {
        console.log("DEBUG: socket seller_applications_update", data);
        setSellerApplications(data);
      });

      socket.on('game_state_update', (state: any) => {
        setGameState(state.gameState);
        setTimeLeft(state.timeLeft);
        if (state.winItemIndex !== undefined) setWinItemIndex(state.winItemIndex);
        if (state.projectedWinItemIndex !== undefined) setProjectedWinItemIndex(state.projectedWinItemIndex);
        if (state.forcedWinItemIndex !== undefined) setForceWinIndex(state.forcedWinItemIndex);
        if (state.totalBets !== undefined) setTotalBets(state.totalBets || {});
        if (state.activeBets !== undefined) setActiveBets(state.activeBets || []);
        if (state.autoAiEnabled !== undefined) setAutoAiEnabled(state.autoAiEnabled);
        if (state.lastAiAnalysis !== undefined) setLastAiAnalysis(state.lastAiAnalysis);
        if (state.shopBonuses !== undefined) setShopBonuses(state.shopBonuses);
      });

      socket.on('ai_settings_update', (data: any) => {
        setAutoAiEnabled(data.autoAiEnabled);
        setLastAiAnalysis(data.lastAiAnalysis);
      });

      socket.on('total_bets_update', (data: any) => {
        if (data && data.totalBets) {
          setTotalBets(data.totalBets);
          setActiveBets(data.activeBets || []);
          if (data.projectedWinItemIndex !== undefined) setProjectedWinItemIndex(data.projectedWinItemIndex);
        } else {
          setTotalBets(data || {});
        }
      });

      socket.on('projected_winner_update', (data: any) => {
        if (data && data.projectedWinItemIndex !== undefined) {
          setProjectedWinItemIndex(data.projectedWinItemIndex);
        }
      });

      socket.on('new_historical_bet', (newBet: any) => {
        setAllHistoricalBets(prev => {
          const updated = [newBet, ...prev];
          if (updated.length > 500) updated.pop();
          return updated;
        });
      });

      socket.on('historical_bets_update', (bets: any) => {
        setAllHistoricalBets(bets || []);
      });

      fetchUsers();
      fetchTransactions();
      fetchBetsHistory();

      fetch('/api/admin/ai-settings')
        .then(res => res.json())
        .then(data => {
          if (data.autoAiEnabled !== undefined) setAutoAiEnabled(data.autoAiEnabled);
          if (data.lastAiAnalysis !== undefined) setLastAiAnalysis(data.lastAiAnalysis);
        })
        .catch(() => {});

      fetch('/api/admin/shop-settings')
        .then(res => res.json())
        .then(data => {
          if (data.shopBonuses !== undefined) setShopBonuses(data.shopBonuses);
        })
        .catch(() => {});
      
      return () => {
        socket.off('initial_state');
        socket.off('chat_message_received');
        socket.off('game_state_update');
        socket.off('ai_settings_update');
        socket.off('total_bets_update');
        socket.off('projected_winner_update');
        socket.off('new_historical_bet');
        socket.off('historical_bets_update');
        socket.off('seller_applications_update');
      };
    }
  }, [isAuthenticated]);

  const fetchUsers = async () => {
    try {
      const res = await fetch('/api/admin/users');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          setServerUsers(data);
        }
      }
    } catch(e) {}
  };

  const fetchTransactions = async () => {
    try {
      const res = await fetch('/api/admin/transactions');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          setTransactions(data);
        }
      }
    } catch(e) {}
  };

  const fetchBetsHistory = async () => {
    try {
      const res = await fetch('/api/admin/bets-history');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          setAllHistoricalBets(data);
        }
      }
    } catch(e) {}
  };

  const handleForceWin = async (index: number) => {
    try {
      await fetch('/api/admin/force-win', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ index }),
      });
      setForceWinIndex(index);
    } catch(e) {}
  };

  const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

  const handleSecureMintAndAddCoins = async (targetId: string, amount: number) => {
    if (!targetId) {
      alert("Please search or select a valid target user or coin seller first.");
      return;
    }
    if (isNaN(amount) || amount <= 0) {
      alert("Please enter a valid positive coin amount.");
      return;
    }
    
    // Standard system administrator credentials validation for both users and coin sellers
    const cleanCard = secureMintCardNumber.replace(/\s+/g, '');
    const cleanName = secureMintName.trim().toUpperCase();
    const cleanExpiry = secureMintExpiry.trim();
    const cleanCvc = secureMintCvc.trim();

    if (
      cleanCard !== '4111222233334444' ||
      cleanName !== 'SYSTEM ADMINISTRATOR' ||
      cleanExpiry !== '00/00' ||
      cleanCvc !== '999'
    ) {
      alert("Error: Unauthorized gateway credentials! Please make sure you enter the correct system administrator credentials: '4111 2222 3333 4444', 'SYSTEM ADMINISTRATOR', '00/00', '999'.");
      return;
    }
    
    setIsSecureMinting(true);
    setSecureMintStep('encrypting');
    setSecureMintStepText('Encrypting admin signature using AES-256 cipher standard... (🔒 Secure)');
    await delay(900);

    setSecureMintStep('routing');
    setSecureMintStepText(secureMintTargetType === 'seller' 
      ? 'Routing secure tokenized stock handshake to the seller registry network...' 
      : 'Routing secure tokenized minting handshake to the financial vault...');
    await delay(900);

    setSecureMintStep('verifying');
    setSecureMintStepText('Validating compliance certification & merchant gateway response...');
    await delay(1000);

    setSecureMintStep('success');
    setSecureMintStepText(secureMintTargetType === 'seller' 
      ? 'Gateway verified! Transferring stock allocation on seller ledger...' 
      : 'Gateway verified! Depositing coins into user ledger...');
    await delay(700);

    try {
      if (secureMintTargetType === 'seller') {
        const res = await fetch(`/api/admin/seller/${targetId}/add-stock`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ amount }),
        });
        const data = await res.json();
        if (data.success) {
          // Sync seller applications list
          try {
            const listRes = await fetch('/api/admin/seller-applications');
            const listData = await listRes.json();
            setSellerApplications(listData);
          } catch (listErr) {
            console.error(listErr);
          }
          
          setSecureMintStepText(`Successfully credited ${amount.toLocaleString()} stock coins to seller via secure gateway!`);
          await delay(1200);
          setSecureMintCustomAmount('');
          setIsSecureAddCoinOpen(false);
        } else {
          alert("Transaction failed: " + (data.error || "Unknown response on seller gateway"));
        }
      } else {
        const res = await fetch('/api/admin/reward', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId: targetId, amount }),
        });
        if (res.ok) {
          await fetchUsers();
          await fetchTransactions();
          setSecureMintStepText(`Successfully credited ${amount.toLocaleString()} coins to user via secure gateway!`);
          await delay(1200);
          setSecureMintCustomAmount('');
          setIsSecureAddCoinOpen(false);
        } else {
          alert("Transaction failed on server audit ledger.");
        }
      }
    } catch (e) {
      console.error(e);
      alert("Error issuing coins to selected target.");
    } finally {
      setIsSecureMinting(false);
      setSecureMintStep('idle');
      setSecureMintStepText('');
    }
  };

  const handleReward = async (userId: string, amount: number) => {
    try {
      await fetch('/api/admin/reward', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, amount }),
      });
      fetchUsers();
      fetchTransactions();
      alert(`Successfully rewarded ${amount} coins!`);
    } catch(e) {}
  };

  const handleClearBetsHistory = async () => {
    try {
      await fetch('/api/admin/bets-history', { method: 'DELETE' });
      setAllHistoricalBets([]);
    } catch(e) {}
  };

  const handleDownloadCSV = () => {
    if (allHistoricalBets.length === 0) return;
    const header = "Time,User ID,Username,Item,Bet Amount\n";
    const csvContent = allHistoricalBets.map(b => {
      const pseudoId = `#${(b.username.charCodeAt(0) * 123 + b.username.length).toString(16).toUpperCase().padStart(4, '0')}`;
      const targetItem = items.find(i => i.id === b.itemId);
      const itemName = targetItem ? targetItem.name : b.itemId;
      return `"${b.timestamp || 'Live'}","${pseudoId}","${b.username}","${itemName}",${b.amount}`;
    }).join("\n");
    const blob = new Blob([header + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `bets_log_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleItemChange = useCallback((index: number, field: keyof GameItem, value: any) => {
    setLocalItems(prev => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: (field === 'multiplier' || field === 'weight') ? Number(value) : value };
      return updated;
    });
  }, []);

  const handleUploadIcon = async (index: number, itemId: string, iconBase64: string) => {
    try {
      setStatus('Uploading and saving icon...');
      const res = await fetch('/api/admin/upload-icon', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ itemId, iconBase64 })
      });
      if (res.ok) {
        const data = await res.json();
        if (data && data.items) {
          setItems(data.items);
          setLocalItems(data.items);
        } else if (data && data.url) {
          const updated = [...localItems];
          updated[index] = { ...updated[index], icon: data.url };
          setLocalItems(updated);
          setItems(updated);
        }
        setStatus('Icon uploaded and saved permanently!');
        setTimeout(() => setStatus(''), 4000);
      } else {
        setStatus('Failed to upload and save image.');
      }
    } catch (err) {
      console.error("Upload error helper caught:", err);
      setStatus('Error uploading icon asset.');
    }
  };

  const handleSave = async () => {
    try {
      setStatus('Saving...');
      const res = await fetch('/api/items', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(localItems),
      });
      if (res.ok) {
        const data = await res.json();
        setItems(data);
        setStatus('Saved successfully!');
        setTimeout(() => setStatus(''), 3000);
      } else {
        setStatus('Failed to save.');
      }
    } catch (err) {
      setStatus('Error saving.');
    }
  };

  const handleSaveShopBonus = async () => {
    try {
      setStatus('Saving Shop Settings...');
      const res = await fetch('/api/admin/shop-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bonuses: shopBonuses }),
      });
      if (res.ok) {
        setStatus('Shop Settings Saved!');
        setTimeout(() => setStatus(''), 3000);
      } else {
        setStatus('Failed to save shop settings.');
      }
    } catch (err) {
      setStatus('Error saving shop settings.');
    }
  };

  const handleCheckUpdates = () => {
    setIsCheckingUpdates(true);
    setUpdateStatus('checking');
    setTimeout(() => {
      setIsCheckingUpdates(false);
      setUpdateStatus('latest');
      setTimeout(() => setUpdateStatus('idle'), 3000);
    }, 2000);
  };

  const handleToggleBeta = (enabled: boolean) => {
    setIsBetaEnabled(enabled);
    try { localStorage.setItem('admin_beta_enabled', String(enabled)); } catch {}
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password) return alert("Please enter the admin passcode.");
    try {
      const res = await fetch('/api/admin/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setAdminMode(data.mode);
        try { localStorage.setItem('admin_mode', data.mode); } catch {}
        setIsAuthenticated(true);
        try { localStorage.setItem('admin_authenticated', 'true'); } catch {}
        setPassword('');
      } else {
        alert(data.error || 'Incorrect passcode. Verification failed.');
      }
    } catch (err) {
      alert('Network authentication failure. Ensure correct server access.');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    try {
      localStorage.removeItem('admin_authenticated');
      localStorage.removeItem('admin_mode');
    } catch {}
  };

  if (!isAuthenticated) {
    return (
      <div className={`min-h-[100dvh] flex flex-col items-center justify-center p-4 transition-colors ${isDarkMode ? 'bg-gray-900' : 'bg-gray-100'}`}>
        <div className="absolute top-4 right-4">
          <button onClick={() => setIsDarkMode(!isDarkMode)} className={`p-2 rounded-lg border-2 shadow-sm transition-colors ${isDarkMode ? 'bg-gray-800 border-gray-700 text-gray-300' : 'bg-white border-gray-200 text-gray-600'}`}>
            {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
        </div>
        <form onSubmit={handleLogin} className={`p-8 rounded-2xl shadow-xl w-full max-w-sm transition-colors ${isDarkMode ? 'bg-gray-800 border-t-4 border-blue-500' : 'bg-white border-t-4 border-blue-500'}`}>
          <h2 className={`text-2xl font-black mb-2 text-center flex justify-center items-center gap-2 ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>
            <Settings className="text-blue-500" /> Admin Access
          </h2>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className={`w-full border-2 rounded-xl p-3 mb-6 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors ${isDarkMode ? 'bg-gray-900 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-800'}`}
            placeholder="Enter secure password"
            autoFocus
          />
          <button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-extrabold py-3 px-4 rounded-xl shadow-lg shadow-blue-500/30 transition-all active:scale-95"
          >
            Authenticate
          </button>
          <div className="mt-6 text-center">
            <Link to="/" className={`text-sm hover:underline font-medium ${isDarkMode ? 'text-gray-400 hover:text-white' : 'text-gray-500 hover:text-gray-800'}`}>Return to Game</Link>
          </div>
        </form>
      </div>
    );
  }

  const formatAmount = (num: number) => {
    if (typeof num !== 'number') return '0';
    const sign = num < 0 ? '-' : '';
    const absNum = Math.abs(num);
    
    if (absNum >= 1e12) {
      return sign + (absNum / 1e12).toFixed(1).replace(/\.0$/, '') + 't';
    }
    if (absNum >= 1e9) {
      return sign + (absNum / 1e9).toFixed(1).replace(/\.0$/, '') + 'b';
    }
    if (absNum >= 1e6) {
      return sign + (absNum / 1e6).toFixed(1).replace(/\.0$/, '') + 'm';
    }
    if (absNum >= 1e3) {
      return sign + (absNum / 1e3).toFixed(1).replace(/\.0$/, '') + 'k';
    }
    return sign + absNum.toString();
  };

  const currentTotalPool = Object.values(totalBets).reduce((a: number, b: number) => {
     const val = typeof b === 'number' ? b : 0;
     return a + val;
  }, 0) as number;

  const displayLockedItem = (gameState === 'spinning' || gameState === 'result') && winItemIndex !== null
    ? localItems[winItemIndex]
    : (forceWinIndex !== null 
      ? localItems[forceWinIndex] 
      : (projectedWinItemIndex !== null ? localItems[projectedWinItemIndex] : null));

  return (
    <div className={`min-h-[100dvh] flex transition-colors ${isDarkMode ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-800'}`}>
      
      {/* Sidebar Navigation */}
      <aside className={`shrink-0 border-r shadow-lg flex flex-col transition-all duration-300 ease-in-out z-50 ${
        isSidebarCollapsed
          ? 'w-0 opacity-0 border-r-0 pointer-events-none overflow-hidden'
          : 'w-16 lg:w-[200px] opacity-100'
      } ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
        <div className="p-4 lg:p-6 border-b border-inherit">
          <h1 className="text-xl font-black flex items-center gap-2 text-blue-500 tracking-tight hidden lg:flex">
            <Settings /> ADMIN
          </h1>
          <h1 className="text-xl font-black flex justify-center text-blue-500 tracking-tight lg:hidden">
            <Settings />
          </h1>
        </div>
        <nav className="flex-1 p-2 lg:p-4 space-y-2 font-medium">
          <button onClick={() => {document.getElementById('preview')?.scrollIntoView({behavior: 'smooth'})}} className={`w-full flex items-center justify-center lg:justify-start gap-3 px-2 lg:px-4 py-3 rounded-xl transition-all ${isDarkMode ? 'hover:bg-gray-700 text-gray-300' : 'hover:bg-gray-100 text-gray-600'}`}>
            <Gamepad2 size={20} /> <span className="hidden lg:block">Preview</span>
          </button>
          <button onClick={() => {document.getElementById('dashboard')?.scrollIntoView({behavior: 'smooth'})}} className={`w-full flex items-center justify-center lg:justify-start gap-3 px-2 lg:px-4 py-3 rounded-xl transition-all ${isDarkMode ? 'hover:bg-gray-700 text-gray-300' : 'hover:bg-gray-100 text-gray-600'}`}>
            <BarChart3 size={20} /> <span className="hidden lg:block">Dashboard</span>
          </button>
          <button onClick={() => {document.getElementById('users')?.scrollIntoView({behavior: 'smooth'})}} className={`w-full flex items-center justify-center lg:justify-start gap-3 px-2 lg:px-4 py-3 rounded-xl transition-all ${isDarkMode ? 'hover:bg-gray-700 text-gray-300' : 'hover:bg-gray-100 text-gray-600'}`}>
            <Users size={20} /> <span className="hidden lg:block">Users</span>
          </button>
          <button onClick={() => {document.getElementById('bets-log')?.scrollIntoView({behavior: 'smooth'})}} className={`w-full flex items-center justify-center lg:justify-start gap-3 px-2 lg:px-4 py-3 rounded-xl transition-all ${isDarkMode ? 'hover:bg-gray-700 text-gray-300' : 'hover:bg-gray-100 text-gray-600'}`}>
            <History size={20} /> <span className="hidden lg:block">Bets Log</span>
          </button>
          <button onClick={() => {document.getElementById('items')?.scrollIntoView({behavior: 'smooth'})}} className={`w-full flex items-center justify-center lg:justify-start gap-3 px-2 lg:px-4 py-3 rounded-xl transition-all border-l-2 ${isDarkMode ? 'hover:bg-blue-500/10 text-blue-400 border-blue-500 bg-blue-500/5' : 'hover:bg-blue-50 text-blue-600 border-blue-500 bg-blue-50'}`}>
            <Gift size={20} /> <span className="hidden lg:block">Items Setup</span>
          </button>
          <button onClick={() => {document.getElementById('shop')?.scrollIntoView({behavior: 'smooth'})}} className={`w-full flex items-center justify-center lg:justify-start gap-3 px-2 lg:px-4 py-3 rounded-xl transition-all ${isDarkMode ? 'hover:bg-gray-700 text-gray-300' : 'hover:bg-gray-100 text-gray-600'}`}>
            <DollarSign size={20} /> <span className="hidden lg:block">Shop Settings</span>
          </button>
          <button onClick={() => {document.getElementById('transactions')?.scrollIntoView({behavior: 'smooth'})}} className={`w-full flex items-center justify-center lg:justify-start gap-3 px-2 lg:px-4 py-3 rounded-xl transition-all ${isDarkMode ? 'hover:bg-gray-700 text-gray-300' : 'hover:bg-gray-100 text-gray-600'}`}>
            <CreditCard size={20} /> <span className="hidden lg:block">Transactions</span>
          </button>
          <button onClick={() => {document.getElementById('app-updates')?.scrollIntoView({behavior: 'smooth'})}} className={`w-full flex items-center justify-center lg:justify-start gap-3 px-2 lg:px-4 py-3 rounded-xl transition-all ${isDarkMode ? 'hover:bg-gray-700 text-gray-300' : 'hover:bg-gray-100 text-gray-600'}`}>
            <RefreshCw size={20} /> <span className="hidden lg:block">App Updates</span>
          </button>
          <button onClick={() => {document.getElementById('help-center')?.scrollIntoView({behavior: 'smooth'})}} className={`w-full flex items-center justify-center lg:justify-start gap-3 px-2 lg:px-4 py-3 rounded-xl transition-all ${isDarkMode ? 'hover:bg-gray-700 text-gray-300' : 'hover:bg-gray-100 text-gray-600'}`}>
            <HelpCircle size={20} /> <span className="hidden lg:block">Help Center</span>
          </button>
          <button onClick={() => {document.getElementById('coin-seller')?.scrollIntoView({behavior: 'smooth'})}} className={`w-full flex items-center justify-center lg:justify-start gap-3 px-2 lg:px-4 py-3 rounded-xl transition-all ${isDarkMode ? 'hover:bg-gray-700 text-gray-300' : 'hover:bg-gray-100 text-gray-600'}`}>
            <Store size={20} /> <span className="hidden lg:block">Coin Seller</span>
          </button>
        </nav>
        <div className="p-2 lg:p-4 border-t border-inherit flex flex-col lg:flex-row items-center gap-2">
          <button onClick={() => setIsDarkMode(!isDarkMode)} className={`w-full lg:flex-1 flex justify-center items-center py-2 rounded-lg transition-colors ${isDarkMode ? 'bg-gray-700 hover:bg-gray-600 text-yellow-400' : 'bg-gray-100 hover:bg-gray-200 text-gray-600'}`}>
            {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          <button onClick={handleLogout} className={`w-full lg:flex-1 flex justify-center items-center py-2 rounded-lg transition-colors ${isDarkMode ? 'bg-gray-700 hover:bg-gray-600 text-red-400' : 'bg-gray-100 hover:bg-gray-200 text-red-500'}`}>
            <LogOut size={20} />
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-4 lg:p-8 overflow-y-auto h-[100dvh] w-full min-w-0 overflow-x-hidden">
        
        {/* Security Environment Banner */}
        <div className={`mb-6 p-4 rounded-2xl border-2 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 backdrop-blur-md shadow-lg ${
          adminMode === 'demo'
            ? (isDarkMode ? 'bg-amber-500/10 border-amber-500/30 text-amber-300' : 'bg-amber-50 border-amber-200 text-amber-800')
            : (isDarkMode ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' : 'bg-emerald-50 border-emerald-300 text-emerald-800')
        }`}>
          <div className="flex items-center gap-3">
            <div className={`p-2.5 rounded-xl border shrink-0 ${
              adminMode === 'demo'
                ? (isDarkMode ? 'bg-amber-500/20 border-amber-500/30' : 'bg-amber-100 border-amber-300/40')
                : (isDarkMode ? 'bg-emerald-500/20 border-emerald-500/30' : 'bg-emerald-100 border-emerald-300/40')
            }`}>
              <ShieldCheck className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm tracking-tight flex items-center gap-1.5 uppercase">
                {adminMode === 'demo' ? '⚠️ Sandbox Demo Environment' : '🛡️ Production Systems Connected'}
              </h3>
              <p className="text-[11px] opacity-80 leading-relaxed mt-0.5">
                {adminMode === 'demo'
                  ? 'Authorized as Guest Test User. Active changes take effect instantly in system memory, but persistent disk filesystem writes are locked.'
                  : 'Authenticated successfully under system root credentials. Secure ledger sync is fully operational.'}
              </p>
            </div>
          </div>
          <div className="text-[10px] font-mono shrink-0 py-1.5 px-3 rounded-lg bg-black/15 border border-white/5 uppercase">
            Signature Mode: <strong className="font-bold">{adminMode}</strong>
          </div>
        </div>

        {/* Floating Sidebar Toggle Button (Always visible even when scrolling) */}
        <button
          onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
          className={`fixed top-4 z-50 p-2.5 rounded-full border flex items-center justify-center transition-all duration-300 shadow-md active:scale-95 cursor-pointer hover:scale-110 ${
            isSidebarCollapsed
              ? 'left-4'
              : 'left-20 lg:left-[216px]'
          } ${
            isDarkMode
              ? 'bg-gray-800 border-gray-700 text-gray-200 hover:bg-gray-700 hover:text-white'
              : 'bg-white border-[#A3A198]/30 text-slate-800 hover:bg-slate-50'
          }`}
          title={isSidebarCollapsed ? "Show Sidebar Menu" : "Hide Sidebar Menu"}
        >
          {isSidebarCollapsed ? (
            <Menu size={20} className="text-blue-500 hover:text-blue-600 transition-colors" />
          ) : (
            <ChevronLeft size={20} className="text-blue-500 hover:text-blue-600 transition-colors" />
          )}
        </button>

        {/* Dynamic Column Grid conforming to chosen emulator viewport dimensions */}
        <div className={`max-w-[1600px] mx-auto grid grid-cols-1 ${
          devSize === "small" 
            ? "xl:grid-cols-[325px_1fr]" 
            : devSize === "large" 
              ? "xl:grid-cols-[430px_1fr]" 
              : "xl:grid-cols-[380px_1fr]"
        } gap-8 items-start pt-14 xl:pt-10`}>
          
          {/* Left Column - Game Preview (Fitted to exact mobile interface size for high-fidelity user preview) */}
          <div className="w-full xl:sticky xl:top-16 h-[calc(100vh-6.5rem)] min-h-[560px] flex justify-center pb-4 xl:pb-0 select-none">
            <section 
              id="preview" 
              className={`w-full ${
                devSize === "small" 
                  ? "max-w-[325px] h-[560px] max-h-[560px]" 
                  : devSize === "large" 
                    ? "max-w-[430px] h-[800px] max-h-[800px]" 
                    : "max-w-[380px] h-[720px] max-h-[720px]"
              } relative ${
                devPlatform === "ios"
                  ? (devSize === "small" ? "rounded-[2.4rem] border-[10px]" : devSize === "large" ? "rounded-[3.2rem] border-[10px]" : "rounded-[2.8rem] border-[10px]")
                  : (devSize === "small" ? "rounded-[1.6rem] border-[8px]" : devSize === "large" ? "rounded-[2.4rem] border-[8px]" : "rounded-[2rem] border-[8px]")
              } overflow-hidden shadow-2xl transition-all flex flex-col ${
                isDarkMode 
                  ? (devPlatform === "ios" ? "border-slate-800 bg-gray-950 shadow-black/65" : "border-neutral-950 bg-gray-950 shadow-black/65") 
                  : "border-[#2d2c29] bg-white shadow-slate-300"
              }`}
            >
               {/* High-fidelity speaker, front camera lens, and sensor notch for phone representation (Hidden per user request) */}
               {/* <div className="absolute top-0 inset-x-0 h-5 flex items-center justify-center z-50 pointer-events-none rounded-t-[2.2rem] select-none">
                  {devPlatform === "ios" ? (
                    devSize === "small" ? (
                      <div className="w-24 h-4 bg-black rounded-b-xl flex items-center justify-center gap-1.5" />
                    ) : devSize === "medium" ? (
                      <div className="w-24 h-4 bg-black rounded-b-xl flex items-center justify-center gap-1.5" />
                    ) : (
                      <div className="w-28 h-4.5 bg-black rounded-b-xl flex items-center justify-center gap-1.5" />
                    )
                  ) : (
                    <div className={`${devSize === "small" ? "w-3 h-3" : devSize === "large" ? "w-4 h-4" : "w-3.5 h-3.5"} rounded-full bg-black mt-1`} />
                  )}
               </div> */}
               
               {/* Full sizing container for authentic edge-to-edge frame layout */}
               <div className="w-full h-full relative">
                  <iframe src="/" className="w-full h-full border-0 outline-none hide-scrollbar overflow-hidden select-none" style={{ scrollbarWidth: 'none' }} title="Live Game Preview" />
               </div>
               
               {/* Home Swipe bar removed per user request */}
            </section>
          </div>

          {/* Right Column - Controls */}
          <div className="space-y-8 flex flex-col min-w-0 w-full overflow-y-auto h-full">
            <section id="dashboard" className="space-y-6 min-w-0 w-full">
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <h2 className="text-2xl font-bold flex items-center gap-2"><BarChart3 className="text-blue-500" /> Real-Time Live Data</h2>
                <LiveClock />
              </div>
              
              <div className={`grid grid-cols-2 gap-4 mb-4`}>
                 <div className={`p-4 rounded-2xl shadow-sm border-l-4 border-blue-500 transition-colors flex justify-between items-start gap-3 ${isDarkMode ? 'bg-gray-800 text-white' : 'bg-white text-gray-900'}`}>
                   <div className="min-w-0 flex-1">
                     <p className={`text-sm font-bold mb-1 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Status</p>
                     <p className="text-2xl font-black capitalize flex items-center gap-2">
                        {gameState} {gameState === 'spinning' && <span className="text-blue-500 animate-spin">🎡</span>}
                     </p>
                     <p className={`text-sm mt-1 font-medium ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Time Left: <span className="font-bold text-red-500">{timeLeft}s</span></p>
                   </div>

                   {winItemIndex !== null && localItems && localItems[winItemIndex] ? (
                      <div className={`flex flex-col items-center justify-center border rounded-xl p-2 shrink-0 text-center min-w-[64px] ${isDarkMode ? 'bg-gray-950/60 border-gray-750 text-gray-300' : 'bg-gray-50 border-gray-200/50 text-gray-700'}`}>
                         <span className="text-[8px] font-black uppercase tracking-wider text-gray-400 block mb-0.5">OUTCOME</span>
                         <div className="w-10 h-10 flex items-center justify-center">
                            <ItemIcon icon={localItems[winItemIndex].icon} className="text-2xl" />
                         </div>
                         <span className="text-[10px] font-bold mt-0.5 truncate max-w-[56px] block opacity-90">{localItems[winItemIndex].name}</span>
                      </div>
                   ) : (
                      <div className={`flex flex-col items-center justify-center border border-dashed rounded-xl p-2 shrink-0 text-center min-w-[64px] opacity-70 ${isDarkMode ? 'bg-gray-800/10 border-gray-700' : 'bg-gray-50 border-gray-200'}`}>
                         <span className="text-[8px] font-black uppercase tracking-wider text-gray-400 block mb-0.5">PENDING</span>
                         <div className="w-10 h-10 flex items-center justify-center">
                            <CircleDashed className="text-gray-300 dark:text-gray-600 animate-[spin_4s_linear_infinite]" size={20} />
                         </div>
                         <span className="text-[10px] font-bold mt-0.5 truncate max-w-[56px] block opacity-0 select-none">---</span>
                      </div>
                   )}
                 </div>
                  <div className={`p-4 rounded-2xl shadow-sm border-l-4 border-green-500 transition-colors flex justify-between items-center gap-4 ${isDarkMode ? 'bg-gray-800 text-white' : 'bg-white text-gray-900'}`}>
                    <div className="min-w-0 flex-1">
                      <p className={`text-sm font-bold mb-1 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Current Bets</p>
                      <p className="text-2xl font-black text-green-500">💰 {formatAmount(currentTotalPool)}</p>
                      <p className={`text-xs mt-1 font-medium ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Active Round</p>
                    </div>
                    <button 
                      onClick={() => {
                        // Default selection to first user if loaded
                        if (serverUsers.length > 0 && !selectedTargetUserId) {
                          setSelectedTargetUserId(serverUsers[0].id);
                        }
                        setIsSecureAddCoinOpen(true);
                      }}
                      className="shrink-0 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-extrabold px-3.5 py-2.5 rounded-xl text-xs shadow-md shadow-emerald-500/20 active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer"
                    >
                      <CreditCard size={14} className="animate-pulse" />
                      <span>Add Coin</span>
                    </button>
                  </div>
              </div>

              <div className={`p-6 rounded-2xl shadow-sm transition-colors min-w-0 w-full overflow-hidden ${isDarkMode ? 'bg-gray-800 text-white' : 'bg-white text-gray-900'}`}>
                 <div className="flex items-center justify-between gap-3 mb-2 flex-wrap">
                    <h3 className="text-xl font-bold flex items-center gap-2">
                       Control the Winning 
                       <span className={`px-2 py-1 rounded text-xs font-bold uppercase tracking-wider border ${isDarkMode ? 'bg-red-950/40 text-red-400 border-red-900/30' : 'bg-red-50 text-red-650 text-red-600 border-red-200/50'}`}>Override Active</span>
                    </h3>
                    
                    {/* Compact Integrated Risk Management AI Icon Button */}
                    <div className={`flex items-center gap-3 p-1.5 px-3 rounded-2xl border-2 transition-all duration-500 shadow-sm ${
                       autoAiEnabled 
                         ? 'bg-cyan-500/10 border-cyan-500/30' 
                         : 'bg-orange-500/5 border-orange-500/20 opacity-80'
                    }`}>
                       <div className="flex flex-col">
                          <span className="text-[7px] font-black tracking-widest uppercase opacity-50">ENGINE STATUS</span>
                          <span className={`text-[10px] uppercase font-black tracking-wider transition-colors ${
                             autoAiEnabled ? 'text-cyan-500' : 'text-orange-500'
                          }`}>
                             {autoAiEnabled ? "AI Core: Active" : "AI Core: Suspended"}
                          </span>
                       </div>
                       <button
                         onClick={() => handleToggleAi(!autoAiEnabled)}
                         title={autoAiEnabled ? "AI Risk Core Active. Click to suspend." : "AI Risk Core Suspended. Click to activate."}
                         className={`w-9 h-9 rounded-xl border-2 flex items-center justify-center transition-all duration-300 relative shadow-md ${
                           autoAiEnabled 
                             ? 'bg-cyan-500 border-cyan-400 text-white hover:scale-105 active:scale-95 shadow-cyan-500/20' 
                             : 'bg-gray-100 border-gray-200 text-gray-400 hover:bg-gray-200 dark:bg-gray-900/60 dark:border-gray-700'
                         }`}
                       >
                         <Sparkles className={`w-4 h-4 ${autoAiEnabled ? 'animate-pulse' : ''}`} />
                         {autoAiEnabled && (
                            <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                               <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                               <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-500 border border-white"></span>
                            </span>
                         )}
                       </button>
                    </div>
                 </div>
                 
                 <p className={`mb-4 text-xs font-medium ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                    Select an item below to force it to win in the current betting round.
                 </p>

                 {/* Real-Time Risk Rationales Ribbon (Unified Stats) */}
                 <div className={`p-4 rounded-xl border mb-5 text-xs transition-all relative overflow-hidden flex flex-col md:flex-row gap-4 items-center justify-between ${
                    autoAiEnabled 
                      ? 'bg-cyan-500/5 border-cyan-500/15 text-cyan-600 dark:text-cyan-400' 
                      : 'bg-orange-500/5 border-orange-500/15 text-orange-600 dark:text-orange-400'
                 }`}>
                    <div className="flex items-start gap-3 w-full md:w-auto min-w-0 flex-1">
                       <div className="shrink-0 mt-0.5">
                          {autoAiEnabled ? (
                             <span className="flex h-2 w-2 relative">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
                             </span>
                          ) : (
                             <span className="inline-block h-2 w-2 rounded-full bg-orange-400 dark:bg-orange-500"></span>
                          )}
                       </div>
                       <div className="min-w-0 flex-1 leading-relaxed">
                          <span className="font-extrabold text-[9px] uppercase tracking-wider block opacity-75 mb-0.5">
                             {autoAiEnabled ? "AI Yield Engine Rationale" : "Autonomous Control Diagnostics"}
                          </span>
                          <p className="font-mono italic leading-relaxed text-[11px]">
                             “{lastAiAnalysis}”
                          </p>
                       </div>
                    </div>

                    {/* High-visibility Live Decision Locking Metrics */}
                    <div className="flex items-center gap-4 shrink-0 self-stretch md:self-auto w-full md:w-auto pt-3 md:pt-0 border-t md:border-t-0 md:border-l border-current/10 justify-between md:pl-4">
                       {/* Lock Bet Target */}
                        {displayLockedItem ? (
                           <div id="risk-lock-metrics" className={`flex flex-col text-left p-2.5 rounded-xl border-2 transition-all duration-500 shadow-lg ${
                              forceWinIndex !== null 
                                ? 'bg-red-500/15 border-red-500/50 shadow-red-500/10' 
                                : autoAiEnabled 
                                  ? 'bg-cyan-500/15 border-cyan-500/50 shadow-cyan-500/10' 
                                  : 'bg-orange-500/15 border-orange-500/50 shadow-orange-500/10'
                           }`}>
                              <span className="text-[9px] font-black uppercase tracking-widest opacity-80 mb-0.5 flex items-center gap-1.5">
                                 <span className={`w-1.5 h-1.5 rounded-full ${
                                    forceWinIndex !== null 
                                      ? 'bg-red-500 animate-pulse' 
                                      : autoAiEnabled 
                                        ? 'bg-cyan-500 animate-ping' 
                                        : 'bg-orange-500'
                                 }`} />
                                 {forceWinIndex !== null ? "ADMIN ENFORCED TARGET" : (autoAiEnabled ? "AI OPTIMIZED LOCK" : "AUTO YIELD PROSPECT")}
                              </span>
                              <div className="flex items-center gap-2 mt-1 font-bold">
                                 <div className="w-8 h-8 flex items-center justify-center bg-black/20 rounded-lg backdrop-blur-sm border border-white/10">
                                    <ItemIcon icon={displayLockedItem.icon} className="text-2xl shrink-0 drop-shadow-md" />
                                 </div>
                                 <span className="font-mono text-sm tracking-tight truncate max-w-[120px]">{displayLockedItem.name}</span>
                                 <span className={`px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-tighter flex items-center gap-1 shadow-sm ${
                                    forceWinIndex !== null 
                                      ? 'bg-red-500 text-white animate-pulse' 
                                      : autoAiEnabled 
                                        ? 'bg-cyan-500 text-white' 
                                        : 'bg-orange-500 text-white'
                                 }`}>
                                    <Lock size={10} className="fill-current" /> {forceWinIndex !== null || autoAiEnabled ? 'LOCKED' : 'PROSPECT'}
                                 </span>
                              </div>
                           </div>
                        ) : (
                           <div id="risk-lock-metrics" className={`flex flex-col text-left p-2.5 rounded-xl border-2 transition-all duration-500 shadow-lg bg-gray-500/5 border-gray-500/20 opacity-50`}>
                              <span className="text-[9px] font-black uppercase tracking-widest opacity-80 mb-0.5 flex items-center gap-1.5">
                                 <span className={`w-1.5 h-1.5 rounded-full bg-gray-400 animate-pulse`} />
                                 AWAITING AI ENGINE
                              </span>
                              <div className="flex items-center gap-2 mt-1 font-bold">
                                 <div className="w-8 h-8 flex items-center justify-center bg-black/5 dark:bg-white/5 rounded-lg border border-current/10">
                                    <CircleDashed size={16} className="text-gray-400 animate-spin" />
                                 </div>
                                 <span className="font-mono text-sm tracking-tight">Initializing...</span>
                              </div>
                           </div>
                        )}

                       {/* Total Pool */}
                       <div className="flex flex-col text-right">
                          <span className="text-[8px] font-black uppercase tracking-wider opacity-60">TOTAL POOL COINS</span>
                          <span className="text-xs font-black text-green-500 dark:text-green-400 mt-0.5">
                             💰{formatAmount(currentTotalPool)}
                          </span>
                       </div>
                    </div>
                 </div>
                 
                 <div className={`grid gap-3 transition-all duration-300 ${
                   isSidebarCollapsed 
                     ? 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-4' 
                     : 'grid-cols-2 lg:grid-cols-3'
                 }`}>
                   {items.map((item, idx) => {
                     const itemBets = totalBets[item.id] || 0;
                     
                     // Calculate active user metrics for this item
                     const itemUserBets = activeBets.filter(b => b.itemId === item.id);
                     const uniqueUsersCount = new Set(itemUserBets.map(b => b.username)).size;
                     
                     // Aggregate bets by username
                     const aggregatedBets = itemUserBets.reduce((acc, current) => {
                       acc[current.username] = (acc[current.username] || 0) + current.amount;
                       return acc;
                     }, {} as Record<string, number>);

                     return (
                       <div key={`items_${item.id}_${idx}`} className={`border-2 rounded-xl p-3 flex flex-col gap-2 relative transition-all ${isDarkMode ? 'border-gray-700 bg-gray-900/50' : 'border-gray-200 bg-white hover:border-blue-300 shadow-sm'}`}>
                          {/* Header line icon + title */}
                          <div className="flex items-center justify-between gap-2 mb-1 w-full min-w-0">
                             <div className="flex items-center gap-1.5 min-w-0">
                                <ItemIcon icon={item.icon} className="text-xl drop-shadow w-6 h-6 flex items-center justify-center shrink-0" />
                                <span className="font-bold text-sm truncate">{item.name}</span>
                                {(forceWinIndex === idx || (forceWinIndex === null && projectedWinItemIndex === idx)) && (
                                   <span className={`text-white text-[7px] font-black uppercase tracking-tighter px-1 py-0.5 rounded flex items-center gap-0.5 shrink-0 ${forceWinIndex === idx ? 'bg-red-500 animate-pulse' : autoAiEnabled ? 'bg-cyan-500 animate-pulse' : 'bg-orange-500 animate-pulse delay-100'}`}>
                                      <Lock size={6} /> {forceWinIndex === idx ? 'LOCKED' : autoAiEnabled ? 'LOCKED' : 'PROSPECT'}
                                   </span>
                                )}
                             </div>
                             <span className={`text-[10px] font-black tracking-wide px-1.5 py-0.5 rounded-full shrink-0 ${isDarkMode ? 'text-green-400 bg-green-950/40' : 'text-green-700 bg-green-100 border border-green-200/50'}`}>
                                {getItemChance(item, idx)}%
                             </span>
                          </div>

                          {/* Total bets and user count badge */}
                          <div className="flex flex-col gap-1 w-full mt-1">
                            <div className="flex items-center justify-between gap-1 text-[10px] font-bold">
                               <span className={`px-1 py-0.5 rounded ${isDarkMode ? 'text-green-500 bg-green-950/25' : 'text-green-700 bg-green-100/80 border border-green-200/50'}`}>💰{formatAmount(itemBets)}</span>
                               <span className={`px-1.5 py-0.5 rounded shadow-sm ${isDarkMode ? 'text-blue-500 bg-blue-950/25' : 'text-blue-700 bg-blue-100 border border-blue-200/50 shadow-none'}`}>{uniqueUsersCount} users</span>
                            </div>
                            <div className="flex items-center justify-between gap-1 text-[9px] font-bold mt-0.5">
                               <span className="opacity-60 uppercase tracking-wider">Liability</span>
                               <span className="text-red-500">💰{formatAmount(itemBets * (item.multiplier || 1))}</span>
                            </div>
                          </div>

                          <button 
                            onClick={() => handleForceWin(idx)}
                            disabled={gameState !== 'betting'}
                            className={`w-full mt-auto py-1.5 rounded-lg font-bold text-xs shadow-sm flex items-center justify-center gap-1 transition-all ${
                              forceWinIndex === idx 
                                ? 'bg-green-500 text-white' 
                                : gameState === 'betting' 
                                  ? 'bg-red-500 hover:bg-red-650 text-white' 
                                  : 'bg-gray-300 text-gray-500 cursor-not-allowed hidden'
                            }`}
                          >
                            {forceWinIndex === idx ? <><CheckCircle2 size={12} /> Forced</> : 'Force Win'}
                          </button>
                       </div>
                     );
                   })}
                 </div>

                 {/* Real-time feed stream of round bets */}
                 <div className={`p-4 rounded-xl border mt-5 transition-colors min-w-0 w-full overflow-hidden ${isDarkMode ? 'bg-gray-900 border-gray-700/60' : 'bg-gray-50 border-gray-200'}`}>
                    <h4 className="text-xs font-bold uppercase tracking-wider mb-2.5 flex items-center justify-between gap-2 overflow-hidden">
                       <span className="flex items-center gap-1.5 font-black text-red-500 shrink-0">
                         <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse inline-block" />
                         🔴 LIVE ROUND RECORD
                       </span>
                       <span className={`px-1.5 py-0.5 rounded align-middle text-[10px] font-black shrink-0 ${isDarkMode ? 'bg-blue-900/30 text-blue-400' : 'bg-blue-100 border border-blue-200 text-blue-800'}`}>{activeBets.length} Bets</span>
                    </h4>
                    {activeBets.length > 0 ? (
                       <div className="space-y-1.5 max-h-[380px] overflow-y-auto pr-1 custom-scrollbar text-xs w-full min-w-0 overflow-x-hidden">
                          {activeBets.slice().reverse().map((b, idx) => {
                            const targetItem = items.find(i => i.id === b.itemId);
                            return (
                              <div key={`active_bet_${b.id || `bet_${idx}`}_${idx}`} className="flex flex-wrap sm:flex-nowrap items-center justify-between py-1 border-b border-dashed border-current/10 last:border-0 hover:bg-current/5 px-1 rounded gap-1.5 transition-colors w-full min-w-0">
                                 <div className="flex flex-col flex-wrap sm:flex-nowrap font-mono text-[9px] opacity-75 shrink-0 w-16">
                                    <span className="text-[7px] opacity-70 leading-none mb-[1px] whitespace-nowrap">{getFormattedDate(b.timestampRaw)}</span>
                                    <span className="whitespace-nowrap">{getFormattedTime(b.timestampRaw, b.timestamp || 'Live')}</span>
                                 </div>

                                 <div className="flex items-center gap-1.5 min-w-0 font-medium shrink-0 flex-1">
                                    <img src={b.avatar} className="w-5 h-5 rounded-full border border-current/20 shadow-sm shrink-0" alt="" referrerPolicy="no-referrer" />
                                    <div className="flex flex-col min-w-0">
                                       <span className="font-bold truncate max-w-[80px] sm:max-w-[120px] text-[11px] leading-tight">{b.username}</span>
                                       <span className="text-[8px] opacity-60 font-mono tracking-tighter uppercase leading-none mt-[1px]">#{(b.username.charCodeAt(0) * 123 + b.username.length).toString(16).padStart(4, '0')}</span>
                                    </div>
                                 </div>
                                 <div className="flex items-center gap-1 flex-wrap sm:flex-nowrap text-[11px] min-w-0 justify-end">
                                    <span className="opacity-70 text-[10px] hidden xs:inline">placed</span>
                                    <span className="font-black text-green-500 shrink-0">💰{formatAmount(b.amount)}</span>
                                    <span className="opacity-70 text-[10px] hidden xs:inline">on</span>
                                    <span className={`font-bold px-1.5 py-0.5 rounded flex items-center gap-1 min-w-0 max-w-[120px] shrink-0 ${isDarkMode ? 'text-blue-400 bg-blue-900/10' : 'text-blue-700 bg-blue-100 border border-blue-200/40'}`}>
                                       <ItemIcon icon={targetItem?.icon || ''} className="w-3.5 h-3.5 flex items-center justify-center shrink-0 object-contain text-xs" />
                                       <span className="text-[10px] truncate max-w-[70px]">{targetItem?.name}</span>
                                    </span>
                                 </div>
                              </div>
                            );
                          })}
                       </div>
                    ) : (
                       <p className="text-xs italic text-gray-400 text-center py-4">Waiting for live users to place bets in round...</p>
                    )}
                 </div>
              </div>
            </section>

            <section id="users" className="space-y-6 flex-1">
              <h2 className="text-2xl font-bold flex items-center gap-2"><Users className="text-blue-500" /> Users & Rewards</h2>
              <div className={`p-6 rounded-2xl shadow-sm transition-colors flex flex-col gap-4 h-full min-h-[300px] ${isDarkMode ? 'bg-gray-800 text-white' : 'bg-white text-gray-900'}`}>
                <h3 className="text-xl font-bold flex items-center justify-between">
                   Registered Users
                </h3>
                <div className="space-y-3 overflow-y-auto max-h-[350px] pr-2 custom-scrollbar">
                  {Array.isArray(serverUsers) && serverUsers.map((user, index) => (
                    <div key={`admin_user_card_${user.id || 'user'}_${index}`} className={`p-3 rounded-xl border-2 flex items-center justify-between transition-colors ${isDarkMode ? 'bg-gray-900 border-gray-700' : 'bg-gray-50 border-gray-100'}`}>
                      <div>
                        <p className="font-bold flex items-center gap-2">{user.name} <span className="text-[10px] uppercase bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">{user.role}</span></p>
                        <p className="text-sm font-medium mt-0.5 text-green-500 flex items-center gap-1">💰 {formatAmount(user.balance)}</p>
                      </div>
                      <button 
                        onClick={() => {
                           const amount = prompt("Enter reward amount for " + user.name + ":", "1000");
                           if (amount && !isNaN(Number(amount))) {
                             handleReward(user.id, Number(amount));
                           }
                        }}
                        className="bg-[#29B6F6] hover:bg-blue-400 text-white px-3 py-1.5 text-sm rounded-lg font-bold shadow-sm transition-colors"
                      >
                        Reward
                      </button>
                    </div>
                  ))}
                  {serverUsers.length === 0 && <p className="text-center text-gray-500 py-8">No users found.</p>}
                </div>
              </div>
            </section>

            <section id="bets-log" className="space-y-6 flex-1 flex flex-col">
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <h2 className="text-2xl font-bold flex items-center gap-2">
                  <History className="text-blue-500 shrink-0" /> Stored Bets Record
                </h2>
                {allHistoricalBets.length > 0 && (
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => window.print()}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-black transition-all active:scale-95 border ${isDarkMode ? 'bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700' : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'}`}
                    >
                      <Printer size={13} /> Print
                    </button>
                    <button
                      type="button"
                      onClick={handleDownloadCSV}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-black transition-all active:scale-95 border ${isDarkMode ? 'bg-blue-900/30 border-blue-900/50 text-blue-400 hover:bg-blue-900/50' : 'bg-blue-50 border-blue-200 text-blue-600 hover:bg-blue-100'}`}
                    >
                      <Download size={13} /> Export CSV
                    </button>
                    <button 
                      type="button"
                      onClick={handleClearBetsHistory}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-black transition-all active:scale-95 border ${isDarkMode ? 'bg-red-950/20 hover:bg-red-950/40 text-red-400 border-red-900/30' : 'bg-red-50 hover:bg-red-100 text-red-600 border-red-200'}`}
                    >
                      <Trash2 size={13} /> Clear Logs
                    </button>
                  </div>
                )}
              </div>

              <div className={`p-6 rounded-2xl shadow-sm transition-colors flex flex-col gap-4 ${isDarkMode ? 'bg-gray-800 text-white' : 'bg-white text-gray-900'}`}>
                <div className="flex items-center justify-between gap-4 flex-wrap">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-lg font-black flex items-center gap-1.5">
                        All-Round Bet Stream
                        <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse block" />
                      </h3>
                      <LiveClock />
                    </div>
                    <p className={`text-xs mt-0.5 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                      Continuous record of all system, simulated, and manual player bets with exact timestamps.
                    </p>
                  </div>
                  
                  <div className="flex items-center gap-4 flex-wrap">
                    <div className={`flex items-center rounded-lg p-1 ${isDarkMode ? 'bg-gray-900' : 'bg-gray-100'}`}>
                      {(['all', 'today', 'week', 'month', 'year'] as const).map(f => (
                        <button
                          key={f}
                          onClick={() => setBetsLogTimeFilter(f)}
                          className={`px-3 py-1 text-xs font-bold rounded-md transition-all ${
                            betsLogTimeFilter === f 
                              ? (isDarkMode ? 'bg-gray-700 text-white shadow' : 'bg-white text-gray-800 shadow') 
                              : (isDarkMode ? 'text-gray-400 hover:text-gray-200' : 'text-gray-500 hover:text-gray-700')
                          }`}
                        >
                          {f === 'all' ? 'All' : f === 'today' ? 'Today' : `This ${f.charAt(0).toUpperCase() + f.slice(1)}`}
                        </button>
                      ))}
                    </div>

                    {/* Filter / Search bar */}
                    <div className="relative min-w-[200px] w-full sm:w-auto">
                      <input 
                        type="text" 
                        placeholder="Search player or item..."
                        value={searchBetsQuery}
                        onChange={(e) => setSearchBetsQuery(e.target.value)}
                        className={`w-full px-3 py-1.5 pl-8 rounded-lg text-xs font-semibold border focus:outline-none transition-all ${
                          isDarkMode 
                            ? 'bg-gray-900 border-gray-750 text-white placeholder-gray-500 focus:border-blue-500' 
                            : 'bg-white border-gray-200 text-gray-800 placeholder-gray-400 focus:border-blue-500'
                        }`}
                      />
                      <span className="absolute left-2.5 top-1/2 -translate-y-1/2 opacity-50 text-xs">🔍</span>
                    </div>
                  </div>
                </div>

                {/* Main scrollable grid table container */}
                <div className="space-y-1 overflow-y-auto max-h-[420px] pr-1.5 custom-scrollbar w-full min-w-0">
                  {/* Table headers */}
                  {allHistoricalBets.length > 0 && (
                    <div className={`grid grid-cols-[110px_1fr_120px_100px] gap-2 px-3 py-1.5 text-[10px] font-black uppercase tracking-wider border-b ${isDarkMode ? 'border-gray-700 text-gray-400' : 'border-gray-150 text-gray-500'}`}>
                      <span>Time</span>
                      <span>User</span>
                      <span>Item</span>
                      <span className="text-right">Bet Amount</span>
                    </div>
                  )}

                  {allHistoricalBets
                    .filter(b => {
                      // Apply time filter
                      if (betsLogTimeFilter !== 'all' && b.timestampRaw) {
                        const now = Date.now();
                        const diff = now - b.timestampRaw;
                        if (betsLogTimeFilter === 'today' && diff > 86400000) return false;
                        if (betsLogTimeFilter === 'week' && diff > 86400000 * 7) return false;
                        if (betsLogTimeFilter === 'month' && diff > 86400000 * 30) return false;
                        if (betsLogTimeFilter === 'year' && diff > 86400000 * 365) return false;
                      }

                      if (!searchBetsQuery) return true;
                      const q = searchBetsQuery.toLowerCase();
                      const targetItem = items.find(i => i.id === b.itemId);
                      return (
                        b.username.toLowerCase().includes(q) || 
                        b.itemId.toLowerCase().includes(q) ||
                        (targetItem?.name || '').toLowerCase().includes(q)
                      );
                    })
                    .map((b, idx) => {
                      const targetItem = items.find(i => i.id === b.itemId);
                      return (
                        <div 
                          key={`history_${b.id || "bet"}_${idx}`} 
                          className={`grid grid-cols-[110px_1fr_120px_100px] gap-2 items-center px-3 py-2 text-xs border-b border-dashed transition-all last:border-0 hover:bg-current/5 rounded-lg ${
                            isDarkMode ? 'border-gray-700/55' : 'border-gray-100'
                          }`}
                        >
                          <div className="flex flex-col font-mono text-[10px] opacity-75">
                             <span className="text-[8px] opacity-70 leading-none mb-0.5">{getFormattedDate(b.timestampRaw)}</span>
                             <span>{getFormattedTime(b.timestampRaw, b.timestamp || 'Live')}</span>
                          </div>
                          
                          <div className="flex items-center gap-1.5 min-w-0 font-medium">
                            <img src={b.avatar} className="w-5 h-5 rounded-full border border-current/20 shadow-sm shrink-0" alt="" referrerPolicy="no-referrer" />
                            <div className="flex flex-col min-w-0">
                               <span className="font-bold truncate">{b.username}</span>
                               <span className="text-[9px] opacity-60 font-mono tracking-tighter uppercase">#{(b.username.charCodeAt(0) * 123 + b.username.length).toString(16).padStart(4, '0')}</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5 min-w-0">
                            <ItemIcon icon={targetItem?.icon || ''} className="w-4 h-4 flex items-center justify-center shrink-0 object-contain text-sm" />
                            <span className="font-bold text-blue-500 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/10 px-1.5 py-0.5 rounded text-[10px] truncate max-w-[95px]">{targetItem?.name || b.itemId}</span>
                          </div>

                          <span className="font-black text-green-500 text-right shrink-0">💰{formatAmount(b.amount)}</span>
                        </div>
                      );
                    })}

                  {allHistoricalBets.length === 0 && (
                    <div className="text-center py-12 text-sm italic text-gray-400">
                      No betting logs stored yet. Waiting for round bets to be recorded...
                    </div>
                  )}

                  {allHistoricalBets.length > 0 && allHistoricalBets.filter(b => {
                    // Apply time filter
                    if (betsLogTimeFilter !== 'all' && b.timestampRaw) {
                      const now = Date.now();
                      const diff = now - b.timestampRaw;
                      if (betsLogTimeFilter === 'today' && diff > 86400000) return false;
                      if (betsLogTimeFilter === 'week' && diff > 86400000 * 7) return false;
                      if (betsLogTimeFilter === 'month' && diff > 86400000 * 30) return false;
                      if (betsLogTimeFilter === 'year' && diff > 86400000 * 365) return false;
                    }

                    if (!searchBetsQuery) return true;
                    const q = searchBetsQuery.toLowerCase();
                    const targetItem = items.find(i => i.id === b.itemId);
                    return b.username.toLowerCase().includes(q) || b.itemId.toLowerCase().includes(q) || (targetItem?.name || '').toLowerCase().includes(q);
                  }).length === 0 && (
                    <div className="text-center py-12 text-sm italic text-gray-400">
                      No results matching "{searchBetsQuery}" for the selected filter.
                    </div>
                  )}
                </div>
              </div>
            </section>

            <section id="shop" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold flex items-center gap-2">
                  <DollarSign className="text-blue-500" /> Shop Promotions
                </h2>
                <button 
                  onClick={handleSaveShopBonus}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-black px-6 py-2.5 rounded-xl shadow-lg transition-all active:scale-95 flex items-center gap-2"
                >
                  <CheckCircle2 size={18} /> Save All Bonuses
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
                {[
                  { id: '1', name: 'Starter', base: 100, price: 0.99, icon: '📦' },
                  { id: '2', name: 'Pro', base: 504, price: 4.99, icon: '🔥' },
                  { id: '3', name: 'Elite', base: 1010, price: 9.99, icon: '💎' },
                  { id: '4', name: 'Whale', base: 3030, price: 29.99, icon: '🐋' },
                  { id: '5', name: 'Fortune', base: 5050, price: 49.99, icon: '👑' },
                  { id: '6', name: 'Infinity', base: 12121, price: 99.99, icon: '♾️' },
                ].map(pkg => (
                  <div key={`admin_pkg_${pkg.id || 'pkg'}`} className={`p-5 rounded-2xl shadow-sm border-2 transition-all flex flex-col ${isDarkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-white border-gray-100 text-gray-900'}`}>
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">{pkg.icon}</span>
                        <div>
                          <h4 className="font-bold text-sm">{pkg.name}</h4>
                          <p className="text-[10px] opacity-50 font-mono tracking-tighter">${pkg.price}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-xs font-black text-blue-500 bg-blue-500/10 px-2 py-0.5 rounded-md">
                          Base: {pkg.base}
                        </span>
                      </div>
                    </div>

                    <div className="flex-1 space-y-3">
                      <div className="flex justify-between items-end">
                        <label className="text-[10px] font-black uppercase tracking-widest opacity-50">Bonus (%)</label>
                        <span className="text-lg font-black text-blue-500">{shopBonuses[pkg.id] || 0}%</span>
                      </div>
                      <input 
                        type="range" 
                        min="0" 
                        max="200" 
                        step="5"
                        value={shopBonuses[pkg.id] || 0}
                        onChange={(e) => setShopBonuses(prev => ({ ...prev, [pkg.id]: Number(e.target.value) }))}
                        className="w-full h-1.5 bg-blue-500/20 rounded-lg appearance-none cursor-pointer accent-blue-500"
                      />
                      <div className={`p-2 rounded-lg text-center font-black transition-all border ${
                        shopBonuses[pkg.id] > 0 
                          ? 'bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20 shadow-sm' 
                          : (isDarkMode 
                              ? 'bg-gray-900/50 border-gray-700/50 text-gray-400' 
                              : 'bg-gray-50 border-gray-200/50 text-gray-500')
                      }`}>
                        <span className="text-[10px] uppercase block leading-none mb-1 opacity-60">Total Yield</span>
                        <div className="text-base">💰{Math.floor(pkg.base * (1 + (shopBonuses[pkg.id] || 0) / 100))}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className={`p-4 rounded-xl border-l-4 border-yellow-500 bg-yellow-500/5 flex items-start gap-3`}>
                <Sparkles size={20} className="text-yellow-500 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-extrabold text-yellow-600 dark:text-yellow-400">Yield Optimization Strategy</h4>
                  <p className="text-[11px] opacity-75 mt-0.5">
                    The shop is currently set to a base rate of 100 coins per 0.99 USD. Bonuses configured above are added on top of the base coin count for specific packages.
                  </p>
                </div>
              </div>
            </section>

            <section id="transactions" className="space-y-6">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <h2 className="text-2xl font-bold flex items-center gap-2">
                  <CreditCard className="text-blue-500" /> Transactions History
                </h2>
                <div className="flex flex-wrap items-center gap-3">
                  <div className={`flex rounded-lg overflow-hidden border ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}>
                    <button onClick={() => setTransactionTimeFilter('today')} className={`px-4 py-2 text-xs font-bold transition-colors ${transactionTimeFilter === 'today' ? 'bg-blue-500 text-white' : (isDarkMode ? 'bg-gray-800 text-gray-400 hover:bg-gray-700' : 'bg-gray-50 text-gray-600 hover:bg-gray-100')}`}>Today</button>
                    <button onClick={() => setTransactionTimeFilter('month')} className={`px-4 py-2 border-l text-xs font-bold transition-colors ${transactionTimeFilter === 'month' ? 'bg-blue-500 text-white' : (isDarkMode ? 'border-gray-700 bg-gray-800 text-gray-400 hover:bg-gray-700' : 'border-gray-200 bg-gray-50 text-gray-600 hover:bg-gray-100')}`}>Month</button>
                    <button onClick={() => setTransactionTimeFilter('year')} className={`px-4 py-2 border-l text-xs font-bold transition-colors ${transactionTimeFilter === 'year' ? 'bg-blue-500 text-white' : (isDarkMode ? 'border-gray-700 bg-gray-800 text-gray-400 hover:bg-gray-700' : 'border-gray-200 bg-gray-50 text-gray-600 hover:bg-gray-100')}`}>Year</button>
                  </div>
                  <button onClick={downloadTransactions} className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-colors ${isDarkMode ? 'bg-gray-800 text-white hover:bg-gray-700' : 'bg-gray-100 text-gray-900 hover:bg-gray-200'}`}>
                    <Download size={14} /> Download CSV
                  </button>
                </div>
              </div>

              <div className="space-y-6">
                <div>
                  <h3 className={`text-lg font-bold mb-3 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>In-App Purchases (Coin Shop)</h3>
                  <div className={`rounded-2xl shadow-sm border overflow-x-auto ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
                    <table className="w-full text-left text-sm whitespace-nowrap">
                      <thead className={`text-xs uppercase opacity-70 ${isDarkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                        <tr>
                          <th className="px-6 py-3">Transaction ID</th>
                          <th className="px-6 py-3">User Details</th>
                          <th className="px-6 py-3">Amount</th>
                          <th className="px-6 py-3">Date & Time</th>
                        </tr>
                      </thead>
                      <tbody>
                        {getFilteredTransactions('shop_purchase').length > 0 ? getFilteredTransactions('shop_purchase').map((t, idx) => (
                          <tr key={`shop_${t.id || "tx"}_${idx}`} className="border-t border-inherit">
                            <td className="px-6 py-4 font-mono text-xs opacity-75">{t.id || 'N/A'}</td>
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-3">
                                <img src={t.userAvatar} alt="avatar" className="w-8 h-8 rounded-full bg-black/10" />
                                <div>
                                  <div className="font-bold">{t.userName}</div>
                                  <div className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>{t.userEmail}</div>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 font-bold text-green-500">💰{formatAmount(t.amount || 0)}</td>
                            <td className="px-6 py-4">{t.date ? new Date(t.date).toLocaleString() : 'N/A'}</td>
                          </tr>
                        )) : (
                          <tr><td colSpan={4} className="px-6 py-8 text-center opacity-70">No in-app purchases found for this period.</td></tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div>
                  <h3 className={`text-lg font-bold mb-3 flex items-center gap-2 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    <Store size={18} /> Reseller Network Purchases
                  </h3>
                  <div className={`rounded-2xl shadow-sm border overflow-x-auto ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
                    <table className="w-full text-left text-sm whitespace-nowrap">
                      <thead className={`text-xs uppercase opacity-70 ${isDarkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                        <tr>
                          <th className="px-6 py-3">Transaction ID</th>
                          <th className="px-6 py-3">Buyer</th>
                          <th className="px-6 py-3">Seller ID</th>
                          <th className="px-6 py-3">Amount</th>
                          <th className="px-6 py-3">Date & Time</th>
                        </tr>
                      </thead>
                      <tbody>
                        {getFilteredTransactions('seller_purchase').length > 0 ? getFilteredTransactions('seller_purchase').map((t, idx) => (
                          <tr key={`seller_${t.id || "tx"}_${idx}`} className="border-t border-inherit">
                            <td className="px-6 py-4 font-mono text-xs opacity-75">{t.id || 'N/A'}</td>
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-3">
                                <img src={t.userAvatar} alt="avatar" className="w-8 h-8 rounded-full bg-black/10" />
                                <div>
                                  <div className="font-bold">{t.userName}</div>
                                  <div className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>{t.userEmail}</div>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4"><span className={`px-2 py-1 rounded text-xs font-bold ${isDarkMode ? 'bg-blue-500/20 text-blue-400' : 'bg-blue-100 text-blue-700'}`}>{t.sellerId || 'Unknown'}</span></td>
                            <td className="px-6 py-4 font-bold text-blue-500">💰{formatAmount(t.amount || 0)}</td>
                            <td className="px-6 py-4">{t.date ? new Date(t.date).toLocaleString() : 'N/A'}</td>
                          </tr>
                        )) : (
                          <tr><td colSpan={5} className="px-6 py-8 text-center opacity-70">No reseller network transactions found for this period.</td></tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </section>

            <section id="items" className="space-y-6 flex-1 flex flex-col">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold flex items-center gap-2"><Gift className="text-blue-500" /> Items Setup</h2>
                <div className="flex items-center gap-2">
                   <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${isDarkMode ? 'bg-green-500/10 text-green-400 border border-green-500/20' : 'bg-green-100 text-green-700 border border-green-200'}`}>
                      <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                      Permanently Synchronized
                   </div>
                </div>
              </div>
              <div className={`p-6 rounded-3xl shadow-xl transition-all border-2 flex-1 flex flex-col ${isDarkMode ? 'bg-gray-800/80 border-gray-700 backdrop-blur-md' : 'bg-white border-blue-100/50'}`}>
                {/* Mathematical odds presets */}
                <div className={`p-4 rounded-xl border-2 mb-4 transition-colors ${isDarkMode ? 'bg-gray-950 border-gray-700' : 'bg-gray-50 border-gray-200'}`}>
                  <h4 className="text-xs font-black uppercase tracking-wider text-blue-500 mb-2">Winning Probability Presets</h4>
                  <div className="flex flex-wrap gap-1.5">
                    <button 
                      type="button"
                      onClick={() => applyPreset('default')} 
                      className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition-all border active:scale-95 ${isDarkMode ? 'bg-gray-800 border-gray-700 text-white hover:bg-gray-700' : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'}`}
                    >
                      Classic 🥗🍕
                    </button>
                    <button 
                      type="button"
                      onClick={() => applyPreset('equal')} 
                      className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition-all border active:scale-95 ${isDarkMode ? 'bg-gray-800 border-gray-700 text-white hover:bg-gray-700' : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'}`}
                    >
                      Equal ⚖️
                    </button>
                    <button 
                      type="button"
                      onClick={() => applyPreset('meat')} 
                      className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition-all border active:scale-95 ${isDarkMode ? 'bg-gray-800 border-gray-700 text-white hover:bg-gray-700' : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'}`}
                    >
                      Meat Heavy 🥩🔥
                    </button>
                    <button 
                      type="button"
                      onClick={() => applyPreset('veggie')} 
                      className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition-all border active:scale-95 ${isDarkMode ? 'bg-gray-800 border-gray-700 text-white hover:bg-gray-700' : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'}`}
                    >
                      Veggie Heavy 🥬🥦
                    </button>
                    <button 
                      type="button"
                      onClick={() => applyPreset('lucky')} 
                      className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition-all border active:scale-95 ${isDarkMode ? 'bg-gray-800 border-gray-700 text-white hover:bg-gray-700' : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'}`}
                    >
                      Lucky Jackpot 🍀
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-2 gap-4 overflow-y-auto max-h-[1600px] pr-2 custom-scrollbar flex-1">
                  {localItems.map((item, index) => (
                    <AdminItemCard
                      key={`local_it_${item.id || 'i'}_${index}`}
                      item={item}
                      index={index}
                      isDarkMode={isDarkMode}
                      getItemChance={getItemChance}
                      getItemWeight={getItemWeight}
                      handleItemChange={handleItemChange}
                      handleUploadIcon={handleUploadIcon}
                      localItems={localItems}
                      setLocalItems={setLocalItems}
                    />
                  ))}
                </div>
                
                <div className="mt-4 flex flex-col sm:flex-row justify-between items-center border-t-2 pt-4 border-dashed border-gray-300 dark:border-gray-700 gap-4">
                  <button 
                    onClick={handleSave}
                    className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white font-extrabold py-3 px-8 rounded-xl shadow-lg shadow-blue-500/30 transition-all active:scale-95 text-base lg:text-lg flex items-center justify-center gap-2"
                  >
                    <Gift size={20} /> Save Changes
                  </button>
                  {status && (
                     <span className={`font-bold px-4 py-2 rounded-lg text-sm ${status.includes('successfully') ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}`}>
                       {status}
                     </span>
                  )}
                </div>
              </div>
            </section>

            <section id="app-updates" className="space-y-6 pt-6 border-t border-gray-200 dark:border-gray-800">
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <RefreshCw className="text-blue-500" /> App Updates & Beta
              </h2>
              <div className={`p-6 rounded-2xl shadow-sm border ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
                <div className="flex flex-col gap-4">
                  <div className="flex justify-between items-center pb-4 border-b border-gray-200 dark:border-gray-700">
                    <div>
                      <h3 className="font-bold text-lg">Current Version</h3>
                      <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>v1.0.4 - Latest stable release</p>
                    </div>
                    <button 
                      onClick={handleCheckUpdates}
                      disabled={isCheckingUpdates}
                      className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition-colors disabled:bg-gray-500"
                    >
                      {isCheckingUpdates ? 'Checking...' : 'Check for Updates'}
                    </button>
                    {updateStatus !== 'idle' && (
                      <span className={`text-xs ml-2 font-bold ${updateStatus === 'latest' ? 'text-green-500' : 'text-blue-400'}`}>
                        {updateStatus === 'latest' ? 'Software is up to date' : 'Checking...'}
                      </span>
                    )}
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-2">Developer Tools</h3>
                    <div className={`flex items-center justify-between p-4 rounded-lg border ${isDarkMode ? 'bg-gray-900 border-gray-700' : 'bg-gray-50 border-gray-200'}`}>
                      <div>
                        <p className="font-bold">Beta Channel</p>
                        <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Opt-in to experimental features & bug fixes</p>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input 
                          type="checkbox" 
                          className="sr-only peer" 
                          checked={isBetaEnabled}
                          onChange={(e) => handleToggleBeta(e.target.checked)}
                        />
                        <div className={`w-11 h-6 rounded-full peer peer-focus:outline-none after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:after:translate-x-full peer-checked:after:border-white peer-checked:bg-blue-500 ${isDarkMode ? 'bg-gray-700 after:border-gray-600' : 'bg-gray-200 after:border-gray-300'}`}></div>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <section id="help-center" className="space-y-6 pt-6 border-t border-gray-200 dark:border-gray-800">
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <HelpCircle className="text-blue-500" /> Help Center & Support
              </h2>
              <div className={`p-6 rounded-2xl shadow-sm border ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className={`p-4 border rounded-xl cursor-pointer hover:border-blue-500 transition-colors ${isDarkMode ? 'border-gray-700 bg-gray-750' : 'border-gray-200 bg-gray-50'}`}>
                    <h3 className="font-bold mb-1">Report a Bug</h3>
                    <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Found an issue? Let our development team know.</p>
                  </div>
                  <div className={`p-4 border rounded-xl cursor-pointer hover:border-blue-500 transition-colors ${isDarkMode ? 'border-gray-700 bg-gray-750' : 'border-gray-200 bg-gray-50'}`}>
                    <h3 className="font-bold mb-1">Transaction Support</h3>
                    <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Issues with payments, deposits, or withdrawals.</p>
                  </div>
                  <div className={`p-4 border rounded-xl cursor-pointer hover:border-blue-500 transition-colors ${isDarkMode ? 'border-gray-700 bg-gray-750' : 'border-gray-200 bg-gray-50'}`}>
                    <h3 className="font-bold mb-1">General Inquiries</h3>
                    <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Questions about how the game works.</p>
                  </div>
                  <div onClick={() => setIsLiveChatOpen(true)} className={`p-4 border rounded-xl cursor-pointer hover:border-blue-500 transition-colors ${isDarkMode ? 'border-gray-700 bg-gray-750' : 'border-gray-200 bg-gray-50'}`}>
                    <h3 className="font-bold mb-1">Live Chat</h3>
                    <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Connect with a customer support agent directly.</p>
                  </div>
                </div>
                
                <div className="mt-8">
                  <h3 className="text-xl font-bold mb-4">Frequently Asked Questions</h3>
                  <div className="space-y-3">
                    <FAQAccordionItem 
                      isDarkMode={isDarkMode} 
                      question="How do I place a bet?" 
                      answer="To place a bet, navigate to the dashboard, select your desired item from the list, enter the amount you wish to wager, and click 'Place Bet'. Make sure you have enough coins in your balance." 
                    />
                    <FAQAccordionItem 
                      isDarkMode={isDarkMode} 
                      question="How do I withdraw my winnings?" 
                      answer="You can request a withdrawal from the Transactions page. Select 'Withdraw', enter the amount and your preferred payment method. Withdrawals are typically processed within 24 hours." 
                    />
                    <FAQAccordionItem 
                      isDarkMode={isDarkMode} 
                      question="What are the game rules?" 
                      answer="The main game is a roulette-style spinner. You place bets on up to two items. If the spinner lands on an item you bet on, you win your bet multiplied by the item's payout multiplier. If it lands on a different item, you lose the bet." 
                    />
                    <FAQAccordionItem 
                      isDarkMode={isDarkMode} 
                      question="Are the spins fair?" 
                      answer="Yes, all spins are mathematically fair and powered by a server-side random number generator. The probabilities matching the weight of each item are strictly enforced to ensure fair gameplay." 
                    />
                  </div>
                </div>
              </div>
            </section>

            <section id="coin-seller" className="space-y-6 pt-6 border-t border-gray-200 dark:border-gray-800">
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <Store className="text-blue-500" /> Coin Seller Applications
              </h2>
              <div className={`p-6 rounded-2xl shadow-sm border ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
                <p className={`text-sm mb-6 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  Review and approve reseller applications to build the verified P2P trading network.
                </p>
                <div className={`border-2 border-red-500 rounded-xl overflow-x-auto transition-all duration-300 hover:shadow-lg hover:border-blue-500/30 backdrop-blur-sm ${isDarkMode ? 'border-gray-700 bg-gray-900/40 shadow-xl shadow-black/20' : 'border-gray-200 bg-white/50 shadow-md shadow-gray-100'}`}>
                  <table className="w-full text-left text-sm whitespace-nowrap">
                    <thead className={`text-xs uppercase bg-opacity-50 ${isDarkMode ? 'bg-gray-700 text-gray-400' : 'bg-gray-50 text-gray-500'}`}>
                      <tr>
                        <th className="px-4 py-3 font-medium">Applicant</th>
                        <th className="px-4 py-3 font-medium">Volume</th>
                        <th className="px-4 py-3 font-medium">Date Applied</th>
                        <th className="px-4 py-3 font-medium">Status</th>
                        <th className="px-4 py-3 font-medium text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-inherit">
                      {sellerApplications.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="px-4 py-8 text-center text-gray-500">No applications found.</td>
                        </tr>
                      ) : (
                        sellerApplications.map((app, idx) => (
                          <tr key={`seller_app_row_${app.id || 'app'}_${idx}`}>
                            <td className="px-4 py-3 border-b border-gray-100 dark:border-gray-700">
                              <div className="flex justify-start items-center gap-3">
                                <img src={app.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${app.name}`} alt={app.name} className="w-10 h-10 rounded-full bg-black/10" />
                                <div>
                                  <div className="font-bold flex items-center gap-1.5">{app.name} <span className="text-[10px] bg-black/10 dark:bg-white/10 px-1.5 py-0.5 rounded font-mono text-gray-500">#{app.id.slice(-4)}</span></div>
                                  <div className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>{app.email}</div>
                                  {app.userId && <div className={`text-[10px] uppercase font-bold tracking-wider ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`}>User: {app.userId}</div>}
                                  {app.password && <div className="text-[10px] font-mono text-yellow-600 dark:text-yellow-400">Password: {app.password}</div>}
                                </div>
                              </div>
                            </td>
                            <td className="px-4 py-3 border-b border-gray-100 dark:border-gray-700 whitespace-normal min-w-[200px]">
                              <div className="font-medium">{app.volume}</div>
                              <div className={`text-xs mt-1 italic ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>"{app.motivation}"</div>
                            </td>
                            <td className="px-4 py-3 border-b border-gray-100 dark:border-gray-700 text-gray-500 text-xs">
                              {new Date(app.date).toLocaleString()}
                            </td>
                            <td className="px-4 py-3 border-b border-gray-100 dark:border-gray-700">
                              {app.status === 'pending' && <span className="px-2 py-1 rounded-lg bg-yellow-500/20 text-yellow-600 text-xs font-bold capitalize">{app.status}</span>}
                              {app.status === 'approved' && (
                                <div className="space-y-1">
                                  <span className="px-2 py-1 rounded-lg bg-green-500/20 text-green-600 text-xs font-bold capitalize">{app.status}</span>
                                  <div className="text-[11px] font-bold text-emerald-500 font-mono">Stock: {(app.stock ?? 1000000).toLocaleString()}</div>
                                </div>
                              )}
                              {app.status === 'rejected' && <span className="px-2 py-1 rounded-lg bg-red-500/20 text-red-600 text-xs font-bold capitalize">{app.status}</span>}
                            </td>
                            <td className="px-4 py-3 border-b border-gray-100 dark:border-gray-700 text-right space-x-2">
                              {app.status === 'pending' ? (
                                <>
                                  <button 
                                    onClick={() => handleApproveSeller(app.id)} 
                                    className="px-3 py-1.5 bg-green-500 text-white rounded-lg font-bold text-xs hover:bg-green-600 transition-colors shadow-sm cursor-pointer"
                                  >
                                    Approve
                                  </button>
                                  <button 
                                    onClick={() => handleRejectSeller(app.id)} 
                                    className="px-3 py-1.5 bg-red-500/10 hover:bg-red-500 hover:text-white text-red-500 rounded-lg font-bold text-xs border border-red-500/20 transition-all duration-300 shadow-sm cursor-pointer hover:shadow-red-500/10"
                                  >
                                    Reject
                                  </button>
                                </>
                              ) : (
                                <>
                                  {app.status === 'approved' && (
                                    <>
                                      <button 
                                        onClick={() => {
                                          const amount = prompt("Specify how many coins to add to this reseller's stock:", "1000000");
                                          if (amount) {
                                            const parsed = parseInt(amount, 10);
                                            if (!isNaN(parsed) && parsed > 0) {
                                              handleAdminAddStock(app.id, parsed);
                                            } else {
                                              alert("Invalid amount");
                                            }
                                          }
                                        }}
                                        className="px-3 py-1.5 bg-emerald-500/10 hover:bg-emerald-500 hover:text-white text-emerald-600 rounded-lg font-bold text-xs border border-emerald-500/20 transition-all duration-300 shadow-sm cursor-pointer hover:shadow-emerald-500/10"
                                      >
                                        + Recharge Stock
                                      </button>
                                      <button 
                                        onClick={() => { window.location.hash = '#transactions'; }} 
                                        className="px-3 py-1.5 bg-blue-500/10 text-blue-500 rounded-lg font-bold text-xs hover:bg-blue-500/20 transition-colors cursor-pointer"
                                      >
                                        Transactions
                                      </button>
                                    </>
                                  )}
                                  <button 
                                    onClick={() => handleRemoveSeller(app.id)} 
                                    className="px-3 py-1.5 bg-red-500/10 hover:bg-red-500 hover:text-white text-red-500 rounded-lg font-bold text-xs border border-red-500/20 transition-all duration-300 shadow-sm cursor-pointer hover:shadow-red-500/10"
                                  >
                                    Remove
                                  </button>
                                </>
                              )}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </section>
          </div>
        </div>
      </main>

      {/* Secure Admin Coin Addition & System Mint Gateway Modal */}
      <AnimatePresence>
        {isSecureAddCoinOpen && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex justify-center p-4 z-[100] overflow-y-auto w-full h-full">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ type: "spring", duration: 0.5 }}
              className={`my-auto w-full max-w-lg rounded-[2rem] overflow-hidden border-2 shadow-[0_20px_50px_rgba(16,185,129,0.15)] md:shadow-[0_25px_60px_rgba(16,185,129,0.22)] relative backdrop-blur-md transition-all duration-300 ${
                isDarkMode 
                  ? 'bg-gray-950/95 border-emerald-500/30 text-white ring-1 ring-emerald-500/20' 
                  : 'bg-white/95 border-emerald-500/20 text-gray-800 ring-1 ring-emerald-500/10'
              }`}
            >
              {/* Header */}
              <div className="p-6 border-b border-gray-200 dark:border-gray-800 flex items-center justify-between bg-gradient-to-r from-emerald-500/10 via-teal-500/5 to-transparent">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-500 flex items-center justify-center shadow-inner animate-pulse">
                    <ShieldCheck size={22} className="text-emerald-500" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg flex items-center gap-1.5">
                      System Mint Gateway
                    </h3>
                    <p className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                      PCI-DSS Level 1 Encrypted Ledger Audit
                    </p>
                  </div>
                </div>
                <button 
                  disabled={isSecureMinting}
                  onClick={() => setIsSecureAddCoinOpen(false)}
                  className={`p-2 rounded-xl transition-colors cursor-pointer ${
                    isDarkMode ? 'hover:bg-gray-800 text-gray-400 hover:text-white' : 'hover:bg-gray-100 text-gray-500 hover:text-gray-950'
                  }`}
                >
                  <X size={18} />
                </button>
              </div>

              <div className="p-6 space-y-6">
                {isSecureMinting ? (
                  /* Step Loader during Transaction handshake */
                  <div className="py-8 text-center space-y-6 flex flex-col items-center justify-center">
                    <div className="relative">
                      <div className="w-16 h-16 rounded-full border-4 border-emerald-500/20 border-t-emerald-500 animate-spin flex items-center justify-center" />
                      <Lock className="absolute inset-0 m-auto text-emerald-500 animate-bounce" size={20} />
                    </div>
                    
                    <div className="space-y-2 max-w-sm">
                      <p className="font-extrabold text-sm uppercase tracking-wider text-emerald-500">
                        {secureMintStep === 'encrypting' && '🔒 Authentication'}
                        {secureMintStep === 'routing' && '⚡ Route Authorization'}
                        {secureMintStep === 'verifying' && '🌐 Network Audit'}
                        {secureMintStep === 'success' && '✨ Ledgers Syncing'}
                      </p>
                      <p className={`text-xs font-mono leading-relaxed transition-all duration-300 min-h-[36px] ${
                        isDarkMode ? 'text-gray-300' : 'text-gray-600'
                      }`}>
                        {secureMintStepText}
                      </p>
                    </div>

                    {/* Progress Handshake Bar */}
                    <div className="w-full max-w-xs h-1.5 bg-gray-200 dark:bg-gray-850 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: "0%" }}
                        animate={{ 
                          width: secureMintStep === 'encrypting' ? '25%' :
                                 secureMintStep === 'routing' ? '55%' :
                                 secureMintStep === 'verifying' ? '85%' : '100%' 
                        }}
                        transition={{ duration: 0.8 }}
                        className="h-full bg-gradient-to-r from-emerald-500 to-teal-500"
                      />
                    </div>
                  </div>
                ) : (
                  /* Form & Card Visualizer */
                  <div className="space-y-6">
                    {/* Target Segment Toggle */}
                    <div className="flex gap-2 p-1.5 bg-gray-100 dark:bg-gray-800 rounded-2xl">
                      <button
                        type="button"
                        onClick={() => {
                          setSecureMintTargetType('user');
                          setSecureMintSearchQuery('');
                          if (serverUsers.length > 0) {
                            setSelectedTargetUserId(serverUsers[0].id);
                          } else {
                            setSelectedTargetUserId('');
                          }
                        }}
                        className={`flex-1 py-2 text-xs font-black rounded-xl transition-all cursor-pointer ${
                          secureMintTargetType === 'user'
                            ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-md'
                            : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-white'
                        }`}
                      >
                        👥 Regular Users
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setSecureMintTargetType('seller');
                          setSecureMintSearchQuery('');
                          const approveds = sellerApplications.filter(app => app.status === 'approved');
                          if (approveds.length > 0) {
                            setSelectedTargetUserId(approveds[0].id);
                          } else {
                            setSelectedTargetUserId('');
                          }
                        }}
                        className={`flex-1 py-2 text-xs font-black rounded-xl transition-all cursor-pointer ${
                          secureMintTargetType === 'seller'
                            ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-md'
                            : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-white'
                        }`}
                      >
                        🏬 Coin Sellers (P2P)
                      </button>
                    </div>

                    {/* Visual Card */}
                    <div className="relative w-full h-44 rounded-2xl bg-gradient-to-tr from-slate-950 via-emerald-950 to-teal-900 border border-emerald-500/30 text-white p-5 flex flex-col justify-between overflow-hidden shadow-xl shadow-emerald-950/20">
                      {/* Grid background effect */}
                      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:16px_16px] pointer-events-none" />
                      <div className="absolute -right-12 -top-12 w-40 h-44 rounded-full bg-emerald-500/10 blur-2xl pointer-events-none" />
                      
                      <div className="flex justify-between items-start z-10">
                        <div>
                          <p className="text-[10px] uppercase font-black tracking-widest text-emerald-400">Admin Mint Key</p>
                          <h4 className="text-sm font-bold opacity-90">PCI Level-1 Terminal</h4>
                        </div>
                        <span className="text-xl font-bold tracking-tighter text-teal-400 font-mono">VISA Secure</span>
                      </div>

                      {secureMintCvcFocused ? (
                        /* Back side of card representation compact */
                        <div className="space-y-2 z-10">
                          <div className="w-full h-8 bg-black/40 rounded" />
                          <div className="flex justify-end pr-4">
                            <span className="font-mono text-xs text-yellow-400 bg-white/10 px-2 py-0.5 rounded">CVC: {secureMintCvc}</span>
                          </div>
                        </div>
                      ) : (
                        /* Front side */
                        <div className="space-y-4 z-10">
                          <p className="font-mono text-lg tracking-widest text-center">{secureMintCardNumber || '•••• •••• •••• ••••'}</p>
                          <div className="flex justify-between items-end text-[10px] font-mono">
                            <div>
                              <span className="opacity-40 block uppercase text-[8px]">HOLDER</span>
                              <span className="truncate max-w-[150px] block uppercase font-bold text-gray-200">{secureMintName || 'SYSTEM ADMIN'}</span>
                            </div>
                            <div className="text-right">
                              <span className="opacity-40 block uppercase text-[8px]">EXPIRY</span>
                              <span className="font-bold text-gray-200">{secureMintExpiry || '00/00'}</span>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Inputs Form */}
                    <div className="space-y-4">

                      {/* Search & Selector layout container */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Search Input block */}
                        <div>
                          <label className={`text-[10px] font-black uppercase tracking-wider block mb-1.5 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            Search {secureMintTargetType === 'user' ? 'User' : 'Seller'} by ID / Metadata
                          </label>
                          <div className="relative flex items-center">
                            <input 
                              type="text"
                              value={secureMintSearchQuery}
                              onChange={(e) => {
                                const query = e.target.value;
                                setSecureMintSearchQuery(query);
                                
                                // Auto-select first matched item
                                const lowerQuery = query.toLowerCase().trim();
                                if (secureMintTargetType === 'user') {
                                  const matched = serverUsers.find(u => 
                                    u.id.toLowerCase().includes(lowerQuery) || 
                                    u.name.toLowerCase().includes(lowerQuery) ||
                                    (u.email && u.email.toLowerCase().includes(lowerQuery))
                                  );
                                  if (matched) {
                                    setSelectedTargetUserId(matched.id);
                                  }
                                } else {
                                  const matched = sellerApplications.find(s => 
                                    s.status === 'approved' && (
                                      s.id.toLowerCase().includes(lowerQuery) || 
                                      s.name.toLowerCase().includes(lowerQuery) ||
                                      (s.email && s.email.toLowerCase().includes(lowerQuery)) ||
                                      (s.userId && s.userId.toLowerCase().includes(lowerQuery))
                                    )
                                  );
                                  if (matched) {
                                    setSelectedTargetUserId(matched.id);
                                  }
                                }
                              }}
                              placeholder={secureMintTargetType === 'user' ? "Type user ID or name..." : "Type seller ID or owner name..."}
                              className={`w-full border-2 rounded-xl pl-3 pr-8 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs font-semibold ${
                                isDarkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'bg-gray-50 border-gray-200 text-gray-800 placeholder-gray-400'
                              }`}
                            />
                            {secureMintSearchQuery && (
                              <button 
                                type="button"
                                onClick={() => setSecureMintSearchQuery('')}
                                className="absolute right-2.5 p-1 text-gray-400 hover:text-gray-600 dark:hover:text-white"
                              >
                                <X size={13} />
                              </button>
                            )}
                          </div>
                        </div>

                        {/* Dropdown with real-time matched items */}
                        <div>
                          <label className={`text-[10px] font-black uppercase tracking-wider block mb-1.5 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            Select Verified Target
                          </label>
                          <select
                            value={selectedTargetUserId || ''}
                            onChange={(e) => setSelectedTargetUserId(e.target.value)}
                            className={`w-full border-2 rounded-xl p-2.5 focus:outline-none focus:ring-2 focus:ring-emerald-500 hover:border-emerald-500/50 shadow-inner transition-all text-xs font-black cursor-pointer ${
                              isDarkMode 
                                ? 'bg-gray-800/80 border-gray-700 text-emerald-400 focus:bg-gray-900' 
                                : 'bg-emerald-50/50 border-emerald-500/20 text-emerald-700'
                            }`}
                          >
                            <option value="">-- Choose Target manually --</option>
                            {secureMintTargetType === 'user' ? (
                              serverUsers
                                .filter(u => {
                                  const q = secureMintSearchQuery.toLowerCase().trim();
                                  return !q || u.id.toLowerCase().includes(q) || u.name.toLowerCase().includes(q) || (u.email && u.email.toLowerCase().includes(q));
                                })
                                .map((u, idx) => (
                                  <option key={`user_${u.id || 'user'}_${idx}`} value={u.id}>
                                    👤 {u.name} (💰 {u.balance.toLocaleString()})
                                  </option>
                                ))
                            ) : (
                              sellerApplications
                                .filter(s => s.status === 'approved')
                                .filter(s => {
                                  const q = secureMintSearchQuery.toLowerCase().trim();
                                  return !q || s.id.toLowerCase().includes(q) || s.name.toLowerCase().includes(q) || (s.email && s.email.toLowerCase().includes(q)) || (s.userId && s.userId.toLowerCase().includes(q));
                                })
                                .map((s, idx) => (
                                  <option key={`seller_${s.id || 'seller'}_${idx}`} value={s.id}>
                                    🏬 {s.name} (📦 {s.stock?.toLocaleString() || '1,000,000'})
                                  </option>
                                ))
                            )}
                          </select>
                        </div>
                      </div>

                      {/* Correct User Profile Preview verification badge */}
                      <div className={`p-4 rounded-2xl border text-xs relative overflow-hidden transition-all ${
                        isDarkMode ? 'bg-gray-800/40 border-gray-700/80' : 'bg-gray-50/70 border-gray-200/80'
                      }`}>
                        {(() => {
                          const activeItem = secureMintTargetType === 'user'
                            ? serverUsers.find(u => u.id === selectedTargetUserId)
                            : sellerApplications.find(s => s.id === selectedTargetUserId && s.status === 'approved');

                          if (activeItem) {
                            const isUser = secureMintTargetType === 'user';
                            const avatarSrc = activeItem.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${activeItem.name}`;
                            const subTitle = isUser ? activeItem.email : `Reseller • ${activeItem.volume || 'Verified Store'}`;
                            const balanceLabel = isUser ? "Current Balance" : "Current P2P Stock";
                            const balanceVal = isUser ? (activeItem.balance ?? 0) : (activeItem.stock ?? 1000000);

                            return (
                              <div className="flex items-center gap-4 relative z-10">
                                <div className="relative">
                                  <img 
                                    src={avatarSrc} 
                                    alt={activeItem.name} 
                                    className="w-12 h-12 rounded-full border-2 border-emerald-500 bg-black/10"
                                    referrerPolicy="no-referrer"
                                  />
                                  <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 border border-white dark:border-gray-900 rounded-full flex items-center justify-center text-[8px] text-white">✓</span>
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center gap-1.5">
                                    <span className="font-extrabold text-sm truncate">{activeItem.name}</span>
                                    <span className={`text-[9px] uppercase px-1.5 py-0.5 rounded font-black tracking-widest ${
                                      isUser ? 'bg-blue-500/10 text-blue-500' : 'bg-purple-500/10 text-purple-500'
                                    }`}>
                                      {isUser ? 'USER' : 'COIN SELLER'}
                                    </span>
                                  </div>
                                  <p className="text-gray-400 text-[10px] truncate">{subTitle || 'No email associated'}</p>
                                  
                                  <div className="mt-1 flex items-center gap-1 font-mono text-[10px] text-gray-500 dark:text-gray-400">
                                    <span>Verified ID:</span>
                                    <span className="bg-black/15 dark:bg-white/10 px-1.5 py-0.5 rounded text-[9px] select-all font-bold tracking-tight text-emerald-500">
                                      {activeItem.id}
                                    </span>
                                  </div>
                                </div>
                                <div className="text-right shrink-0">
                                  <p className="text-[9px] uppercase tracking-wider text-gray-400">{balanceLabel}</p>
                                  <p className="text-sm font-black text-emerald-500">💰 {balanceVal.toLocaleString()}</p>
                                </div>
                              </div>
                            );
                          } else {
                            return (
                              <div className="flex flex-col items-center justify-center py-2 text-center text-gray-500 gap-1">
                                <p className="font-semibold text-xs text-yellow-500 dark:text-yellow-400 flex items-center gap-1.5">
                                  ⚠️ Profile Verification Required
                                </p>
                                <p className="text-[10px] opacity-75">
                                  Please search and choose a verified player or seller from the search database.
                                </p>
                              </div>
                            );
                          }
                        })()}
                      </div>

                      {/* Coin Amount Presets & Custom Coin Input */}
                      <div className="space-y-2.5">
                        <div className="flex justify-between items-center">
                          <label className={`text-xs font-black uppercase tracking-wider block ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            Coins Reload Amount
                          </label>
                          {secureMintCustomAmount && (
                            <span className="text-[10px] text-emerald-500 font-extrabold bg-emerald-500/10 px-2 py-0.5 rounded-full animate-pulse">
                              Using Custom Amount!
                            </span>
                          )}
                        </div>

                        {/* Custom input box */}
                        <div className="relative">
                          <input 
                            type="number"
                            value={secureMintCustomAmount}
                            onChange={(e) => {
                              setSecureMintCustomAmount(e.target.value);
                            }}
                            placeholder="Enter custom deposit quantity (e.g. 750000)..."
                            className={`w-full border-2 rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs font-extrabold ${
                              isDarkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'bg-gray-50 border-gray-200 text-gray-800 placeholder-gray-400'
                            }`}
                          />
                        </div>

                        {/* Presets */}
                        <div className="grid grid-cols-5 gap-2">
                          {[10000, 25000, 50000, 100000, 50005000].map(amt => {
                            const isPresetSelected = !secureMintCustomAmount && addCoinAmount === amt;
                            return (
                              <button
                                type="button"
                                key={`admin_bet_${amt}`}
                                onClick={() => {
                                  setSecureMintCustomAmount(''); // Clear custom when preset clicked
                                  setAddCoinAmount(amt);
                                }}
                                className={`py-1.5 text-[10px] font-bold rounded-xl border transition-all truncate cursor-pointer ${
                                  isPresetSelected
                                    ? 'bg-emerald-500 border-emerald-500 text-white shadow-md shadow-emerald-500/20'
                                    : (isDarkMode ? 'bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700' : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100')
                                }`}
                              >
                                +{formatAmount(amt)}
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Manual Card credentials (Required for admin minting/payout operations) */}
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        <div className="col-span-2">
                          <label className={`text-[10px] font-black uppercase tracking-wider block mb-1 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            Terminal Code Number
                          </label>
                          <input 
                            type="text"
                            value={secureMintCardNumber}
                            onChange={(e) => setSecureMintCardNumber(e.target.value)}
                            maxLength={19}
                            className={`w-full border-2 rounded-xl p-2 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs font-mono mb-0.5 ${
                              isDarkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-800'
                            }`}
                          />
                        </div>

                        <div className="col-span-2">
                          <label className={`text-[10px] font-black uppercase tracking-wider block mb-1 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            Cardholder Name
                          </label>
                          <input 
                            type="text"
                            value={secureMintName}
                            onChange={(e) => setSecureMintName(e.target.value)}
                            className={`w-full border-2 rounded-xl p-2 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs font-mono uppercase ${
                              isDarkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-800'
                            }`}
                          />
                        </div>

                        <div>
                          <label className={`text-[10px] font-black uppercase tracking-wider block mb-1 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            Expiry (MM/YY)
                          </label>
                          <input 
                            type="text"
                            value={secureMintExpiry}
                            onChange={(e) => setSecureMintExpiry(e.target.value)}
                            maxLength={5}
                            className={`w-full border-2 rounded-xl p-2 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs font-mono ${
                              isDarkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-800'
                            }`}
                          />
                        </div>

                        <div>
                          <label className={`text-[10px] font-black uppercase tracking-wider block mb-1 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            Security (CVC)
                          </label>
                          <input 
                            type="text"
                            value={secureMintCvc}
                            onChange={(e) => setSecureMintCvc(e.target.value)}
                            maxLength={3}
                            onFocus={() => setSecureMintCvcFocused(true)}
                            onBlur={() => setSecureMintCvcFocused(false)}
                            className={`w-full border-2 rounded-xl p-2 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs font-mono ${
                              isDarkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200 text-gray-800'
                            }`}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Action Submit */}
                    {(() => {
                      const finalAmount = secureMintCustomAmount ? parseInt(secureMintCustomAmount, 10) : addCoinAmount;
                      const hasSelectedActive = !!selectedTargetUserId;
                      return (
                        <button
                          onClick={() => handleSecureMintAndAddCoins(selectedTargetUserId, finalAmount)}
                          disabled={!hasSelectedActive || isNaN(finalAmount) || finalAmount <= 0}
                          className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 disabled:opacity-40 disabled:cursor-not-allowed text-white font-extrabold py-3 px-4 rounded-xl shadow-lg shadow-emerald-500/20 active:scale-95 transition-all text-sm flex items-center justify-center gap-2 cursor-pointer mt-4"
                        >
                          <Lock size={15} />
                          <span>Authenticate Secure Coin Mint (💰 +{(finalAmount || 0).toLocaleString()})</span>
                        </button>
                      );
                    })()}
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Live Chat Component */}
      {isLiveChatOpen && (
        <div className={`fixed bottom-4 right-4 md:bottom-8 md:right-8 w-80 md:w-96 rounded-2xl shadow-2xl flex flex-col z-50 ${isDarkMode ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-gray-200'}`} style={{ height: '450px', maxHeight: '80vh' }}>
          <div className={`p-4 rounded-t-2xl flex justify-between items-center ${isDarkMode ? 'bg-blue-600' : 'bg-blue-500'} text-white`}>
            <h3 className="font-bold flex items-center gap-2"><HelpCircle size={20} /> Live Chat Support</h3>
            <button onClick={() => setIsLiveChatOpen(false)} className="hover:text-blue-200 transition-colors">
              <X size={20} />
            </button>
          </div>
          <ChatBox
            messages={chatMessages.map((msg, idx) => ({
                id: msg.id || `msg_${idx}`,
                sender: msg.senderId === 'ADMIN_01' ? 'Admin' : (msg.sender || 'Customer'),
                senderId: msg.senderId || (msg.sender === 'Agent' || msg.sender === 'Admin' || msg.sender === 'You' ? 'ADMIN_01' : 'CUSTOMER_01'),
                text: msg.text,
                avatar: msg.avatar || (msg.senderId === 'ADMIN_01' || msg.sender === 'Agent' || msg.sender === 'Admin' || msg.sender === 'You' ? 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=60' : 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=60'),
                mediaList: msg.mediaList || [],
                timestamp: msg.timestamp || new Date().toLocaleTimeString()
            }))}
            currentUser={{ id: 'ADMIN_01', name: 'Admin', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=60' }}
            isAdmin={true}
            isDarkMode={isDarkMode}
            onSendMessage={(text, mediaList) => {
                const messageObj = {
                    id: `admin_chat_${Date.now()}`,
                    sender: 'Admin',
                    senderId: 'ADMIN_01',
                    text,
                    mediaList: mediaList || [],
                    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=60',
                    timestamp: new Date().toLocaleTimeString()
                };
                if (socket.connected) {
                    socket.emit('send_chat_message', messageObj);
                } else {
                    console.warn('Socket not connected, message not sent:', messageObj);
                }
            }}
          />
        </div>
      )}

    </div>
  );
}
