import { initializeApp } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider, onAuthStateChanged, User, signOut } from 'firebase/auth';
import { getFirestore, doc, setDoc, getDoc, collection, addDoc, getDocs, query, orderBy, limit, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase App
const app = initializeApp(firebaseConfig);

// Initialize Cloud Firestore and Auth instances
export const db = getFirestore(app, (firebaseConfig as any).firestoreDatabaseId);
export const auth = getAuth(app);

// Configure Google OAuth Provider with valid scopes
export const googleProvider = new GoogleAuthProvider();

// Scopes we have successfully authorized in OAuth Setup:
// 1. Google Tasks: https://www.googleapis.com/auth/tasks
// 2. Google Meet: https://www.googleapis.com/auth/meetings.space.created
// 3. Google Sheets: https://www.googleapis.com/auth/spreadsheets
// 4. Google Slides: https://www.googleapis.com/auth/presentations
// 5. Google Forms: https://www.googleapis.com/auth/forms.body

googleProvider.addScope('https://www.googleapis.com/auth/tasks');
googleProvider.addScope('https://www.googleapis.com/auth/meetings.space.created');
googleProvider.addScope('https://www.googleapis.com/auth/spreadsheets');
googleProvider.addScope('https://www.googleapis.com/auth/presentations');
googleProvider.addScope('https://www.googleapis.com/auth/forms.body');

// Client-side Token Caching
let cachedAccessToken: string | null = null;
let isSigningIn = false;

// Initialize Auth listener
export const initAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      } else if (!isSigningIn) {
        // Attempt to fetch from state or resolve
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

// Sign in with Google Popup
export const googleSignIn = async (): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, googleProvider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Failed to get Google Access Token');
    }

    cachedAccessToken = credential.accessToken;
    
    // Save/Sync player profile to Firestore on login
    await syncUserToFirestore(result.user);

    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    if (error?.code !== 'auth/popup-closed-by-user') {
      console.error('Cloud Sign-In failed:', error);
    }
    throw error;
  } finally {
    isSigningIn = false;
  }
};

// Log out user
export const logoutUser = async () => {
  await signOut(auth);
  cachedAccessToken = null;
};

// Firestore operation helper with compliance error handling
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
    },
    operationType,
    path
  };
  console.error('Firestore Security/Operation Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// -------------------------------------------------------------
// USER/PLAYER PROFILE FIRESTORE SYNCHRONIZATION
// -------------------------------------------------------------
export const syncUserToFirestore = async (user: User, manualBalance?: number) => {
  const userRef = doc(db, 'players', user.uid);
  try {
    const existingSnap = await getDoc(userRef);
    let finalBalance = manualBalance ?? 10000; // default starting balance
    
    if (existingSnap.exists()) {
      const data = existingSnap.data();
      if (manualBalance !== undefined) {
        finalBalance = manualBalance;
      } else {
        finalBalance = data.balance ?? 10000;
      }
    }

    await setDoc(userRef, {
      id: user.uid,
      name: user.displayName || user.email || 'Lucky Player',
      avatar: user.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.uid}`,
      balance: finalBalance,
      updatedAt: new Date().toISOString()
    }, { merge: true });

  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `players/${user.uid}`);
  }
};

export const getPlayerBalance = async (uid: string): Promise<number> => {
  try {
    const docSnap = await getDoc(doc(db, 'players', uid));
    if (docSnap.exists()) {
      return docSnap.data().balance ?? 0;
    }
    return 10000;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `players/${uid}`);
    return 10000;
  }
};

export const updatePlayerBalanceOnFirestore = async (uid: string, newBalance: number) => {
  try {
    await setDoc(doc(db, 'players', uid), {
      balance: newBalance,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `players/${uid}`);
  }
};

// Log Transaction
export const logTransactionToFirestore = async (tx: {
  senderId: string;
  senderName: string;
  receiverId: string;
  receiverName: string;
  amount: number;
  type: string;
}) => {
  const id = `tx_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
  try {
    await setDoc(doc(db, 'transactions', id), {
      id,
      ...tx,
      createdAt: new Date().toISOString()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `transactions/${id}`);
  }
};

// -------------------------------------------------------------
// GOOGLE WORKSPACE API REST WRAPPERS
// -------------------------------------------------------------

// Create and export a Google Sheets ledger
export const createGoogleSheetLedger = async (accessToken: string, transactionsList: any[]): Promise<string> => {
  if (!accessToken) throw new Error('Google OAuth access token is required.');

  // 1. Create a blank Spreadsheet
  const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      properties: {
        title: `Greedy Casino - Account Ledger (${new Date().toLocaleDateString()})`
      }
    })
  });

  if (!createRes.ok) {
    const err = await createRes.text();
    throw new Error(`Failed to create spreadsheet: ${err}`);
  }

  const sheetData = await createRes.json();
  const spreadsheetId = sheetData.spreadsheetId;
  const spreadsheetUrl = sheetData.spreadsheetUrl;

  // 2. Prepare spreadsheet data (header followed by rows)
  const rows = [
    ['Timestamp', 'Sender Name', 'Receiver Name', 'Coins Transferred', 'Type'],
    ...transactionsList.map(t => [
      t.createdAt ? new Date(t.createdAt).toLocaleString() : new Date().toLocaleString(),
      t.senderName || t.senderId,
      t.receiverName || t.receiverId,
      t.amount,
      t.type
    ])
  ];

  // 3. Append records
  const appendRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Sheet1!A1:E${rows.length}:append?valueInputOption=USER_ENTERED`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      values: rows
    })
  });

  if (!appendRes.ok) {
    console.error('Failed appending sheet records', await appendRes.text());
  }

  return spreadsheetUrl;
};

// Create a Google Task
export const addGoogleTaskMilestone = async (accessToken: string, taskTitle: string, notes?: string) => {
  if (!accessToken) throw new Error('Google OAuth access token is required.');

  // First, get the default tasklist ID
  const tasksRes = await fetch('https://tasks.googleapis.com/v1/users/@default/lists', {
    headers: { 'Authorization': `Bearer ${accessToken}` }
  });

  if (!tasksRes.ok) {
    throw new Error(`Failed to load tasklists: ${await tasksRes.text()}`);
  }

  const listData = await tasksRes.json();
  const tasklistId = listData.items?.[0]?.id || '@default';

  // Add the task
  const createRes = await fetch(`https://tasks.googleapis.com/v1/lists/${tasklistId}/tasks`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      title: taskTitle,
      notes: notes || 'Created automatically from your Greedy Casino applet.',
      due: new Date(Date.now() + 86400000).toISOString() // default due tomorrow
    })
  });

  if (!createRes.ok) {
    throw new Error(`Failed to create Task: ${await createRes.text()}`);
  }

  return await createRes.json();
};

// Create a Google Meet meeting space in 1-Click
export const createGoogleMeetSpace = async (accessToken: string): Promise<string> => {
  if (!accessToken) throw new Error('Google OAuth access token is required.');

  const res = await fetch('https://meet.googleapis.com/v1/spaces', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      config: {
        accessType: 'OPEN'
      }
    })
  });

  if (!res.ok) {
    throw new Error(`Failed to create Google Meet space: ${await res.text()}`);
  }

  const data = await res.json();
  return data.meetingUri || `https://meet.google.com/${data.meetingCode || ''}`;
};

// Create Google Web Forms presentation template
export const createFeedbackGoogleForm = async (accessToken: string, email: string): Promise<string> => {
  if (!accessToken) throw new Error('Google OAuth access token is required.');

  const res = await fetch('https://forms.googleapis.com/v1/forms', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      info: {
        title: 'Greedy Casino - User Feedback & Support',
        documentTitle: `Feedback Form (${email})`
      }
    })
  });

  if (!res.ok) {
    throw new Error(`Failed to construct Google Form: ${await res.text()}`);
  }

  const data = await res.json();
  return data.responderUri || `https://docs.google.com/forms/d/${data.formId}/viewform`;
};

// Highlight current VIP milestone into a Google Slides presentation
export const createVipStatusGoogleSlide = async (accessToken: string, playerName: string, balance: number): Promise<string> => {
  if (!accessToken) throw new Error('Google OAuth access token is required.');

  const res = await fetch('https://slides.googleapis.com/v1/presentations', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      title: `${playerName}'s Greedy Casino VIP Report`
    })
  });

  if (!res.ok) {
    throw new Error(`Failed to create Google Slides presentation: ${await res.text()}`);
  }

  const data = await res.json();
  return `https://docs.google.com/presentation/d/${data.presentationId}/edit`;
};

// Connection Test
export async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test_connection', 'ping'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('offline')) {
      console.warn("Client offline or firestore db not fully initialized yet.");
    }
  }
}
testConnection();
