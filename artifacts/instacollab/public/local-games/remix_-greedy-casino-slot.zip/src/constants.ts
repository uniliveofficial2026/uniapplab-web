import { GameItem } from './types';

export const ITEMS: GameItem[] = [
  { id: 'hotdog', name: 'Hot Dog', multiplier: 10, icon: '🌭' },
  { id: 'skewer', name: 'Skewer', multiplier: 15, icon: '🍢' },
  { id: 'ham', name: 'Ham', multiplier: 25, icon: '🍖' },
  { id: 'steak', name: 'Steak', multiplier: 45, icon: '🥩' },
  { id: 'carrot', name: 'Carrot', multiplier: 5, icon: '🥕' },
  { id: 'corn', name: 'Corn', multiplier: 5, icon: '🌽' },
  { id: 'cabbage', name: 'Cabbage', multiplier: 5, icon: '🥬' },
  { id: 'tomato', name: 'Tomato', multiplier: 5, icon: '🍅' },
  { id: 'salad', name: 'Salad', multiplier: 50, icon: '🥗' },
  { id: 'pizza', name: 'Pizza', multiplier: 100, icon: '🍕' },
];

export const BET_AMOUNTS = [10, 50, 100, 1000, 10000];
export const BETTING_TIME = 15;
export const SPINNING_TIME = 5;
export const RESULT_TIME = 3;
