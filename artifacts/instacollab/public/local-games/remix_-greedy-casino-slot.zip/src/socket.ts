import { io } from 'socket.io-client';

// Use polling-first protocol to bypass restrictive sandbox proxy/ingress WebSocket handshake drops
export const socket = io({
  transports: ['polling'],
  reconnectionAttempts: 15,
  reconnectionDelay: 1500,
  autoConnect: true,
});
