export type ItemId = string;

export interface GameItem {
  id: ItemId;
  name: string;
  multiplier: number;
  icon: string;
  weight?: number;
}

export type GameState = 'betting' | 'spinning' | 'result';

export type Bets = Record<ItemId, number>;

export interface HistoryItem {
  uid: string;
  id: ItemId;
  round: number;
  multiplier: number;
  timestamp: string;
}
