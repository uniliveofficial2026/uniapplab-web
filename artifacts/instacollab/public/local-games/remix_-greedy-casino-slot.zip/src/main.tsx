import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App.tsx';
import './index.css';

// Safety layer to catch known benign errors in the Cloud Run / AI Studio environment
if (typeof window !== 'undefined') {
  // Use useCapture = true to intercept errors before any development overlay or telemetry systems see them
  window.addEventListener('unhandledrejection', (event) => {
    const reason = event.reason;
    const reasonStr = reason ? String(reason.message || reason.description || reason) : '';
    const norm = reasonStr.toLowerCase();
    
    // Catch-all check for websocket, transport, sock.js, engine.io, socket.io or HMR unhandled errors
    const isWebSocketError = 
      norm.includes('websocket') || 
      norm.includes('hmr') ||
      norm.includes('closed without opened') ||
      norm.includes('socket') ||
      norm.includes('transport') ||
      norm.includes('polling') ||
      (reason && (
        String(reason).includes('WebSocket') ||
        (reason.target && reason.target.constructor && reason.target.constructor.name === 'WebSocket')
      ));

    if (isWebSocketError) {
      // Silently catch and suppress the error
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
    }
  }, true);

  window.addEventListener('error', (event) => {
    const msg = (event.message || '').toLowerCase();
    const errStr = (event.error ? String(event.error.message || event.error) : '').toLowerCase();
    
    const isWebSocketError =
      msg.includes('websocket') || 
      msg.includes('hmr') ||
      msg.includes('closed without opened') ||
      msg.includes('socket') ||
      msg.includes('transport') ||
      errStr.includes('websocket') ||
      errStr.includes('closed without opened') ||
      errStr.includes('socket') ||
      errStr.includes('transport');

    if (isWebSocketError) {
      // Silently catch and suppress the error
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
    }
  }, true);

  // Directly assign backup handlers
  window.onunhandledrejection = (event) => {
    const reasonStr = event.reason ? String(event.reason.message || event.reason) : '';
    if (
      reasonStr.toLowerCase().includes('websocket') || 
      reasonStr.toLowerCase().includes('closed without opened') ||
      reasonStr.toLowerCase().includes('transport')
    ) {
      event.preventDefault();
      return true;
    }
  };

  // Patch console.error to suppress the Vite WebSocket error
  const originalConsoleError = console.error;
  console.error = (...args) => {
    const errText = args.join(' ').toLowerCase();
    if (
      errText.includes('[vite] failed to connect to websocket') ||
      errText.includes('websocket closed without opened') ||
      errText.includes('websocket') ||
      errText.includes('transport')
    ) {
      return;
    }
    originalConsoleError.apply(console, args);
  };
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    {(() => {
      const pathname = typeof window !== 'undefined' ? window.location.pathname : '/';
      const candidates = ['/games/greedy-slot', '/greedy-slot'];
      const base = candidates.find((p) => pathname === p || pathname.startsWith(`${p}/`)) || '';
      return (
        <BrowserRouter basename={base}>
          <App />
        </BrowserRouter>
      );
    })()}
  </StrictMode>,
);

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.getRegistrations().then((regs) => {
      // Drop stale PWA caches that were pinning the broken wheel layout.
      regs.forEach((reg) => {
        reg.update();
      });
    });
    if (window.caches?.keys) {
      caches.keys().then((keys) => {
        keys
          .filter((k) => k.startsWith('greedy-slot-pwa-') && k !== 'greedy-slot-pwa-v5')
          .forEach((k) => caches.delete(k));
      });
    }
    const pathname = window.location.pathname;
    const candidates = ['/games/greedy-slot', '/greedy-slot'];
    const base = candidates.find((p) => pathname === p || pathname.startsWith(`${p}/`)) || '';
    const swPath = base ? `${base}/service-worker.js` : '/service-worker.js';
    navigator.serviceWorker.register(swPath).catch((err) => {
      console.info('Service worker registration failed:', err);
    });
  });
}

