import React, { useState, useEffect, ErrorInfo, ReactNode } from 'react';
import { Routes, Route } from 'react-router-dom';
import Game from './Game';
import AdminPanel from './AdminPanel';
import { GameItem } from './types';
import { ITEMS as DEFAULT_ITEMS } from './constants';
import { socket } from './socket';
import { OrientationGate } from './components/OrientationGate';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }
  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("ErrorBoundary caught an error", error, errorInfo);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="p-10 min-h-screen bg-red-50 flex flex-col items-center justify-center text-center">
          <div className="bg-white p-8 rounded-2xl shadow-xl max-w-lg w-full">
            <h2 className="text-2xl font-bold text-red-600 mb-4">Application Error</h2>
            <p className="text-gray-600 mb-6">Something went wrong in the application. We've caught the error and reported it.</p>
            <div className="bg-gray-100 p-4 rounded-lg text-left text-xs font-mono mb-6 overflow-auto max-h-40">
              {this.state.error?.toString()}
            </div>
            <button 
              onClick={() => window.location.assign('/')}
              className="px-6 py-3 bg-blue-600 text-white rounded-xl font-bold transition-transform active:scale-95 shadow-lg shadow-blue-500/25"
            >
              Back to Home
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  const [items, setItems] = useState<GameItem[]>(() => {
    try {
      const saved = localStorage.getItem('game_items_v2');
      return saved ? JSON.parse(saved) : DEFAULT_ITEMS;
    } catch(e) {
      return DEFAULT_ITEMS;
    }
  });

  useEffect(() => {
    fetch('/api/items')
      .then(res => {
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
        return res.json();
      })
      .then(data => {
        setItems(data);
        localStorage.setItem('game_items_v2', JSON.stringify(data));
      })
      .catch(err => console.error("Could not fetch items", err));

    socket.on('items_updated', (newItems) => {
      setItems(newItems);
      localStorage.setItem('game_items_v2', JSON.stringify(newItems));
    });

    return () => {
      socket.off('items_updated');
    };
  }, []);

  return (
    <ErrorBoundary>
      <OrientationGate />
      <Routes>
        <Route path="/" element={<Game items={items} />} />
        <Route path="/admin" element={<AdminPanel items={items} setItems={setItems} />} />
        <Route path="*" element={<Game items={items} />} />
      </Routes>
    </ErrorBoundary>
  );
}
