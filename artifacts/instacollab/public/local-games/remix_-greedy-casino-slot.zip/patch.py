import os

with open('src/Game.tsx', 'r') as f:
    code = f.read()

anchor = '      <PipPortal active={isPipActive} onClose={() => setIsPipActive(false)} width={400} height={700}>'
idx = code.find(anchor)

if idx != -1:
    replacement = '''      <PipPortal active={isPipActive} onClose={() => setIsPipActive(false)} width={400} height={700}>
        <div className="w-full h-full relative overflow-hidden flex flex-col m-0 p-0">
          {gameContent}
        </div>
      </PipPortal>
    </>
  ) : gameContent;

  return (
    <div className={`w-full min-h-[100dvh] h-full flex flex-col md:max-w-md mx-auto relative md:border-x shadow-2xl transition-colors duration-300 ${isDarkMode ? "bg-gray-900 border-gray-800" : "bg-[#D1CFC7] border-gray-300"}`}>
      {gameContentWrapper}
    </div>
  );
}
'''
    code = code[:idx] + replacement
    with open('src/Game.tsx', 'w') as f:
        f.write(code)
    print("Fixed successfully")
else:
    print("Anchor not found")
