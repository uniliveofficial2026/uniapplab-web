import re
import os

with open('src/Game.tsx', 'r') as f:
    content = f.read()

# I want to remove responsive classes from the `gameContent` variable only.
# gameContent starts at `const gameContent = (` and ends at the PipPortal logic.
# Wait, let's just target the specific lines that scale things up.

# Replace lg:scale-[4.8] etc
content = re.sub(r'\s+(sm|md|lg|xl|2xl):[a-zA-Z0-9_\[\].:-]+', '', content)

with open('src/Game.tsx', 'w') as f:
    f.write(content)

