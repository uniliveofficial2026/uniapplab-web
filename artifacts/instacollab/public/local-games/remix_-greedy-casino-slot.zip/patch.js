const fs = require('fs');
let code = fs.readFileSync('src/Game.tsx', 'utf8');

const anchor = '      <PipPortal active={isPipActive} onClose={() => setIsPipActive(false)} width={400} height={700}>';
const idx = code.indexOf(anchor);

if (idx !== -1) {
  const replacement = `      <PipPortal active={isPipActive} onClose={() => setIsPipActive(false)} width={400} height={700}>
        <div className="w-full h-full relative overflow-hidden flex flex-col m-0 p-0">
          {gameContent}
        </div>
      </PipPortal>
    </>
  ) : gameContent;

  return (
    <div className={\`w-full min-h-[100dvh] h-full flex flex-col md:max-w-md mx-auto relative md:border-x shadow-2xl transition-colors duration-300 \${isDarkMode ? "bg-gray-900 border-gray-800" : "bg-[#D1CFC7] border-gray-300"}\`}>
      {gameContentWrapper}
    </div>
  );
}
`;
  code = code.substring(0, idx) + replacement;
  fs.writeFileSync('src/Game.tsx', code);
  console.log("Fixed successfully");
} else {
  console.log("Anchor not found");
}
